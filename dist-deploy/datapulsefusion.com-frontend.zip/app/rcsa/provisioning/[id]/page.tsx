import { ProvisioningAssessmentDetailsPage } from '@/components/pages/provisioning-assessment-details'

export default async function AssessmentDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return <ProvisioningAssessmentDetailsPage assessmentId={id} />
}
