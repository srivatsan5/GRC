'use client'

import React from 'react'
import Link from 'next/link'
import { motion } from 'framer-motion'
import {
  Shield,
  ArrowRight,
  Activity,
  Zap,
  Eye,
  BarChart3,
  ChevronRight,
  ShieldCheck,
  AlertTriangle,
  Clock,
  LayoutDashboard
} from 'lucide-react'
import { useQuery } from '@tanstack/react-query'
import { oracleService } from '@/lib/oracleService'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { PericopeLayout } from '@/components/pericope-layout'

const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6, ease: 'easeOut' }
}

const staggerContainer = {
  animate: {
    transition: {
      staggerChildren: 0.1
    }
  }
}

export default function HomePage() {
  const { data: summaryData, isLoading } = useQuery({
    queryKey: ['dashboard', 'summary'],
    queryFn: oracleService.getDashboardSummary
  })

  const summary = summaryData?.[0] || { total_risks: 0, total_controls: 0, total_monitoring: 0 }

  const modules = [
    {
      title: 'RCSA WORKFLOW',
      desc: 'Comprehensive Risk & Control Self-Assessment lifecycle.',
      icon: Shield,
      href: '/rcsa',
      color: 'blue',
      items: ['Assessment Setup', 'Identification', 'Mitigation', 'Monitoring']
    },
    {
      title: 'RISK EXPLORER',
      desc: 'Deep-dive analysis into Inherent and Residual risk landscapes.',
      icon: Eye,
      href: '/assessments/residual',
      color: 'azure',
      items: ['Inherent Analysis', 'Residual Mapping', 'Risk Heatmaps']
    },
    {
      title: 'KRI INTELLIGENCE',
      desc: 'Key Risk Indicator tracking with thresholds, trends, and breach alerts.',
      icon: Activity,
      href: '/kri',
      color: 'indigo',
      items: ['KRI Matrix', 'Threshold Configuration', 'Breach Alerts']
    },
    {
      title: 'RISK ANALYTICS',
      desc: 'Executive-ready reports, exports, and historical metrics.',
      icon: BarChart3,
      href: '/reports',
      color: 'royal',
      items: ['Performance Reports', 'Audit Trail', 'Export Center']
    }
  ]

  return (
    <PericopeLayout>
      <div className="min-h-screen py-10 space-y-20 max-w-7xl mx-auto px-4">

        {/* Hero Section */}
        <motion.section
          initial="initial"
          animate="animate"
          variants={staggerContainer}
          className="relative rounded-[3rem] overflow-hidden bg-blue-600 p-12 lg:p-20 text-white shadow-2xl shadow-blue-500/20"
        >
          <div className="absolute top-0 right-0 w-1/2 h-full opacity-10 pointer-events-none">
            <div className="absolute top-[-10%] right-[-10%] w-[120%] h-[120%] bg-[radial-gradient(circle_at_center,_#fff_1px,_transparent_1px)] bg-[length:40px_40px] rotate-12" />
          </div>

          <div className="relative z-10 space-y-8 max-w-3xl">
            <motion.div variants={fadeInUp} className="inline-flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full border border-white/20">
              <Zap className="w-4 h-4 text-white" />
              <span className="text-[10px] font-black uppercase tracking-widest">COSO ERM 2017 · ISO 31000 Aligned</span>
            </motion.div>

            <motion.h1 variants={fadeInUp} className="text-5xl lg:text-7xl font-display font-black tracking-tight leading-[0.9]">
              Pericope ERM<br />
              <span className="text-white/60 italic">Enterprise Risk Management.</span>
            </motion.h1>

            <motion.p variants={fadeInUp} className="text-lg lg:text-xl text-white/70 font-medium max-w-xl">
              Identify, assess, mitigate, and monitor enterprise risk end-to-end.
              Integrated control library, KRI intelligence, and audit-grade reporting.
            </motion.p>

            <motion.div variants={fadeInUp} className="flex flex-wrap gap-4 pt-4">
              <Link href="/rcsa">
                <Button className="bg-white text-blue-600 hover:bg-white/90 h-14 px-8 rounded-2xl font-black uppercase tracking-widest text-xs transition-all shadow-xl shadow-white/10 group">
                  Start RCSA Cycle
                  <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                </Button>
              </Link>
              <Link href="/dashboard">
                <Button variant="outline" className="border-white/30 text-white hover:bg-white/10 h-14 px-8 rounded-2xl font-black uppercase tracking-widest text-xs transition-all">
                  <LayoutDashboard className="w-4 h-4 mr-2" />
                  Executive Dashboard
                </Button>
              </Link>
            </motion.div>
          </div>
        </motion.section>

        {/* Real-time Status */}
        <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            { label: 'Active Risks', value: summary.total_risks, icon: AlertTriangle, color: 'text-blue-600' },
            { label: 'Control Effectiveness', value: summary.total_controls ? '94.2%' : 'No Data', icon: ShieldCheck, color: 'text-emerald-500' },
            { label: 'SLA Adherence', value: '98.5%', icon: Clock, color: 'text-blue-400' },
            { label: 'Active Monitoring Actions', value: summary.total_monitoring, icon: Activity, color: 'text-indigo-500' },
          ].map((stat, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: i * 0.1 }}
            >
              <Card className="p-6 border-blue-50 bg-white hover:border-blue-200 transition-all group cursor-default">
                <div className="flex justify-between items-start">
                  <div className="space-y-1">
                    <p className="text-[10px] font-black text-blue-300 uppercase tracking-widest">{stat.label}</p>
                    <p className="text-3xl font-display font-black text-blue-900 tabular-nums">
                      {isLoading ? '---' : stat.value}
                    </p>
                  </div>
                  <div className={`p-3 rounded-xl bg-blue-50 ${stat.color} group-hover:scale-110 transition-transform`}>
                    <stat.icon className="w-5 h-5" />
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </section>

        {/* Module Exploration */}
        <section className="space-y-10">
          <div className="text-center space-y-4 max-w-2xl mx-auto">
            <h2 className="text-3xl font-display font-black text-blue-900 tracking-tight">Platform Modules</h2>
            <p className="text-blue-400 font-medium">Navigate the integrated GRC modules across the Pericope platform.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {modules.map((mod, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 + (i * 0.1) }}
              >
                <Link href={mod.href}>
                  <Card className="p-8 h-full border-blue-50 bg-white hover:shadow-2xl hover:shadow-blue-500/5 hover:-translate-y-1 transition-all group">
                    <div className="flex flex-col h-full space-y-6">
                      <div className="flex items-center justify-between">
                        <div className="w-14 h-14 bg-blue-50 rounded-2xl flex items-center justify-center text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition-all duration-300">
                          <mod.icon className="w-7 h-7" />
                        </div>
                        <ChevronRight className="w-5 h-5 text-blue-200 group-hover:text-blue-600 transition-colors" />
                      </div>

                      <div className="space-y-2">
                        <h3 className="text-xl font-black text-blue-900 leading-none">{mod.title}</h3>
                        <p className="text-sm text-blue-400 font-medium line-clamp-2">{mod.desc}</p>
                      </div>

                      <div className="flex flex-wrap gap-2 pt-2">
                        {mod.items.map((item, j) => (
                          <Badge key={j} variant="secondary" className="bg-blue-50 text-blue-600 hover:bg-blue-100 border-none px-3 py-1 font-bold text-[10px]">
                            {item}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </Card>
                </Link>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Quick Access Footer */}
        <section className="bg-blue-50/50 rounded-[2.5rem] p-12 text-center space-y-6 border border-blue-100/50">
          <h2 className="text-2xl font-black text-blue-800 tracking-tight">Ready to strengthen your risk posture?</h2>
          <div className="flex justify-center gap-4">
             <Link href="/rcsa/provisioning">
               <Button className="h-12 px-8 bg-blue-600 text-white rounded-xl font-bold text-xs uppercase tracking-widest shadow-lg shadow-blue-500/20">
                 New Assessment
               </Button>
             </Link>
             <Link href="/settings">
               <Button variant="ghost" className="h-12 px-8 text-blue-600 font-bold text-xs uppercase tracking-widest hover:bg-blue-100/50">
                 System Settings
               </Button>
             </Link>
          </div>
        </section>

      </div>
    </PericopeLayout>
  )
}
