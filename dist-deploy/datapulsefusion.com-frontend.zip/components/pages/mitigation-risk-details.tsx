'use client'

import React, { useMemo, useState } from 'react'
import { useRouter } from 'next/navigation'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import {
  ArrowLeft,
  Shield,
  ShieldCheck,
  ShieldAlert,
  AlertTriangle,
  Activity,
  Target,
  Users,
  Calendar,
  FileText,
  TrendingDown,
  TrendingUp,
  CheckCircle2,
  Clock,
  Plus,
  Loader2,
  ChevronRight,
  BarChart3,
  Zap,
  Layers,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { motion } from 'framer-motion'
import { FadeIn } from '@/components/ui/fade-in'
import { oracleService } from '@/lib/oracleService'
import { cn } from '@/lib/utils'
import { toast } from 'sonner'

interface Props {
  riskId: string
}

export function MitigationRiskDetailsPage({ riskId }: Props) {
  const router = useRouter()
  const queryClient = useQueryClient()
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [planTitle, setPlanTitle] = useState('')
  const [planGoal, setPlanGoal] = useState('')
  const [planOwner, setPlanOwner] = useState('')

  // 1. Fetch the specific risk record
  const { data: allRisks = [], isLoading: risksLoading } = useQuery({
    queryKey: ['mitigation-detail-risks'],
    queryFn: () => oracleService.getIdentifyRisks(),
  })

  // 2. Fetch all controls
  const { data: allControls = [], isLoading: controlsLoading } = useQuery({
    queryKey: ['mitigation-detail-controls'],
    queryFn: () => oracleService.getControlImplementations(),
  })

  // 3. Fetch monitoring data
  const { data: allMonitoring = [], isLoading: monitoringLoading } = useQuery({
    queryKey: ['mitigation-detail-monitoring'],
    queryFn: () => oracleService.getRiskMonitoring(),
  })

  const isLoading = risksLoading || controlsLoading || monitoringLoading

  // Find the specific risk
  const risk = useMemo(() => {
    return allRisks.find((r: any) => String(r.uuid) === String(riskId)) || null
  }, [allRisks, riskId])

  // Filter controls linked to this risk
  const linkedControls = useMemo(() => {
    return allControls.filter((c: any) =>
      String(c.risk_uuid) === String(riskId) ||
      String(c.identify_risk_uuid) === String(riskId)
    )
  }, [allControls, riskId])

  // Get monitoring action plans for this specific risk
  const monitoringPlans = useMemo(() => {
    const linkedPlans = allMonitoring.filter((m: any) => 
      String(m.risk_uuid) === String(riskId) || 
      String(m.identify_risk_uuid) === String(riskId)
    )
    return linkedPlans.slice(0, 5) // Latest 5 monitoring plans for this risk
  }, [allMonitoring, riskId])

  // Compute risk metrics
  const metrics = useMemo(() => {
    if (!risk) return { sle: 0, probability: 0, impact: 0, score: 0, status: 'Unknown' }
    const sle = risk.inherent_sle || 0
    const probability = Math.min(5, Math.max(1, Math.ceil(sle / 20000)))
    const impact = Math.min(5, Math.max(1, Math.ceil((sle % 20000) / 4000) || 1))
    const score = probability * impact
    const status = risk.is_stage_complted === 'Y' ? 'Mitigated' : score >= 16 ? 'Critical' : score >= 10 ? 'High' : score >= 5 ? 'Medium' : 'Low'
    return { sle, probability, impact, score, status }
  }, [risk])

  // Compute residual risk from controls
  const residualMetrics = useMemo(() => {
    if (linkedControls.length === 0) return { score: metrics.score, reduction: 0 }
    const avgEffectiveness = linkedControls.reduce((sum: number, c: any) =>
      sum + (Number(c.control_design_effectiveness) || 50), 0) / linkedControls.length
    const reduction = Math.round((avgEffectiveness / 100) * metrics.score * 0.6)
    const residualScore = Math.max(1, metrics.score - reduction)
    return { score: residualScore, reduction: Math.round(((metrics.score - residualScore) / Math.max(1, metrics.score)) * 100) }
  }, [linkedControls, metrics])

  // Build 5x5 heatmap
  const heatmapCells = useMemo(() => {
    return Array.from({ length: 25 }, (_, i) => {
      const row = Math.floor(i / 5)
      const col = i % 5
      const prob = 5 - row
      const impact = col + 1
      const score = prob * impact
      const isInherent = prob === metrics.probability && impact === metrics.impact
      const isResidual = prob === Math.max(1, metrics.probability - 1) && impact === Math.max(1, metrics.impact - 1)
      return { prob, impact, score, isInherent, isResidual }
    })
  }, [metrics])

  // Create monitoring plan mutation
  const createPlanMutation = useMutation({
    mutationFn: (payload: any) => oracleService.createRiskMonitoring(payload),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['mitigation-detail-monitoring'] })
      toast.success('Action plan created and linked successfully')
      setIsDialogOpen(false)
      setPlanTitle('')
      setPlanGoal('')
      setPlanOwner('')
    },
    onError: (err: any) => {
      toast.error(`Failed to create plan: ${err.message}`)
    },
  })

  const handleCreatePlan = () => {
    if (!planTitle || !planGoal) {
      toast.error('Please fill in all fields')
      return
    }
    createPlanMutation.mutate({
      risk_uuid: riskId,
      identify_risk_uuid: riskId,
      monitoring_title: planTitle,
      monitoring_goal: planGoal,
      mitigation_owner: planOwner || 'Unassigned',
      is_stage_complted: 'N',
      approval_status: 'DRAFT',
      completion_pct: 0,
    })
  }

  const getRiskColor = (score: number) => {
    if (score >= 16) return { bg: 'bg-red-500/10', text: 'text-red-500', border: 'border-red-500/20', glow: 'shadow-red-500/20' }
    if (score >= 10) return { bg: 'bg-amber-500/10', text: 'text-amber-500', border: 'border-amber-500/20', glow: 'shadow-amber-500/20' }
    if (score >= 5) return { bg: 'bg-yellow-500/10', text: 'text-yellow-500', border: 'border-yellow-500/20', glow: 'shadow-yellow-500/20' }
    return { bg: 'bg-emerald-500/10', text: 'text-emerald-500', border: 'border-emerald-500/20', glow: 'shadow-emerald-500/20' }
  }

  const getHeatmapColor = (score: number, isInherent: boolean, isResidual: boolean) => {
    if (isInherent) return 'bg-red-500 text-white shadow-lg shadow-red-500/40 scale-110 z-10 ring-2 ring-red-300'
    if (isResidual) return 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/40 scale-105 z-10 ring-2 ring-emerald-300'
    if (score >= 16) return 'bg-red-500/15 text-red-400 border-red-500/20'
    if (score >= 10) return 'bg-amber-500/15 text-amber-400 border-amber-500/20'
    if (score >= 5) return 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20'
    return 'bg-emerald-500/10 text-emerald-500 border-emerald-500/15'
  }

  const getEffectivenessColor = (val: number) => {
    if (val >= 80) return 'text-emerald-500'
    if (val >= 60) return 'text-yellow-500'
    return 'text-red-500'
  }

  const riskColors = getRiskColor(metrics.score)

  if (isLoading) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center min-h-[60vh]">
        <div className="relative mb-6">
          <Loader2 className="w-12 h-12 animate-spin text-primary/30" />
          <Shield className="absolute inset-0 m-auto w-5 h-5 text-primary animate-pulse" />
        </div>
        <p className="text-[11px] font-black uppercase tracking-widest text-muted-foreground animate-pulse">
          Resolving Mitigation Vectors...
        </p>
      </div>
    )
  }

  return (
    <div className="flex-1 pb-10 bg-background/20">
      {/* Header */}
      <FadeIn delay={0.1} direction="none">
        <div className="border-b border-border/40 px-6 py-6 bg-background/60 backdrop-blur-xl sticky top-0 z-40 shadow-sm">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => router.back()} className="h-10 w-10 border border-border/50 rounded-xl hover:bg-secondary">
                <ArrowLeft className="w-4 h-4" />
              </Button>
              <div>
                <h1 className="text-xl font-black text-foreground tracking-tighter uppercase italic">
                  Mitigation Profile
                </h1>
                <p className="text-[12px] text-muted-foreground mt-0.5 font-medium italic opacity-70">
                  Risk UUID: {riskId} · {linkedControls.length} Controls Mapped
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className={cn("px-3 py-1.5 rounded-full border flex items-center gap-2", riskColors.bg, riskColors.border)}>
                <div className={cn("w-2 h-2 rounded-full animate-pulse", metrics.status === 'Mitigated' ? 'bg-emerald-500' : metrics.status === 'Critical' ? 'bg-red-500' : 'bg-amber-500')} />
                <span className={cn("text-[10px] font-black uppercase tracking-wider", riskColors.text)}>{metrics.status}</span>
              </div>
              <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogTrigger asChild>
                  <Button size="sm" className="rounded-full px-5 h-9 font-black uppercase text-[11px] tracking-widest shadow-xl shadow-primary/20">
                    <Plus className="w-3.5 h-3.5 mr-2" />
                    Action Plan
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-md">
                  <DialogHeader>
                    <DialogTitle className="font-black uppercase tracking-wider text-sm">Create Monitoring Plan</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 pt-2">
                    <div>
                      <label className="text-[11px] font-black uppercase tracking-wider text-muted-foreground mb-1.5 block">Plan Title</label>
                      <Input value={planTitle} onChange={e => setPlanTitle(e.target.value)} placeholder="e.g., Quarterly Control Review" className="h-10" />
                    </div>
                    <div>
                      <label className="text-[11px] font-black uppercase tracking-wider text-muted-foreground mb-1.5 block">Goal / Objective</label>
                      <textarea value={planGoal} onChange={e => setPlanGoal(e.target.value)} placeholder="Describe the mitigation objective..." className="w-full h-24 p-3 border rounded-md resize-none text-sm bg-background" />
                    </div>
                    <div>
                      <label className="text-[11px] font-black uppercase tracking-wider text-muted-foreground mb-1.5 block">Owner</label>
                      <select value={planOwner} onChange={e => setPlanOwner(e.target.value)} className="w-full h-10 px-3 border rounded-md text-sm bg-background">
                        <option value="">Select owner</option>
                        <option value="Risk Committee">Risk Committee</option>
                        <option value="Internal Audit">Internal Audit</option>
                        <option value="Operations">Operations</option>
                        <option value="Compliance">Compliance</option>
                      </select>
                    </div>
                    <div className="flex justify-end gap-2 pt-2">
                      <Button variant="outline" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
                      <Button onClick={handleCreatePlan} disabled={createPlanMutation.isPending}>
                        {createPlanMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Create Plan'}
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </div>
      </FadeIn>

      <div className="p-6 space-y-6 max-w-[1400px] mx-auto">
        {/* Risk Identity Banner */}
        <FadeIn delay={0.15}>
          <div className={cn("rounded-3xl p-6 border backdrop-blur-xl relative overflow-hidden", riskColors.bg, riskColors.border)}>
            <div className="absolute -top-10 -right-10 w-40 h-40 rounded-full blur-[60px] opacity-20 pointer-events-none bg-primary" />
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
              <div className="flex items-center gap-4">
                <div className={cn("w-14 h-14 rounded-2xl flex items-center justify-center border", riskColors.bg, riskColors.border)}>
                  {metrics.status === 'Mitigated' ? <ShieldCheck className={cn("w-7 h-7", riskColors.text)} /> : <ShieldAlert className={cn("w-7 h-7", riskColors.text)} />}
                </div>
                <div>
                  <h2 className="text-lg font-black text-foreground tracking-tight leading-tight">
                    {risk?.risk_statement || risk?.process_name || `Risk ${riskId}`}
                  </h2>
                  <div className="flex items-center gap-3 mt-1.5">
                    <span className="text-[10px] font-black text-muted-foreground uppercase tracking-widest">{risk?.risk_type || 'General Risk'}</span>
                    <span className="text-muted-foreground/30">·</span>
                    <span className="text-[10px] font-black text-muted-foreground uppercase tracking-widest">{risk?.process_name || 'Corporate'}</span>
                    {risk?.sub_process_name && (
                      <>
                        <span className="text-muted-foreground/30">·</span>
                        <span className="text-[10px] font-black text-muted-foreground uppercase tracking-widest">{risk.sub_process_name}</span>
                      </>
                    )}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant={risk?.is_stage_complted === 'Y' ? 'default' : 'secondary'} className="font-black text-[9px] tracking-widest px-3">
                  {risk?.approval_status || 'DRAFT'}
                </Badge>
                <Badge variant={risk?.is_sop_available === 'Y' ? 'default' : 'outline'} className="font-black text-[9px] tracking-widest px-3">
                  SOP: {risk?.is_sop_available === 'Y' ? 'Available' : 'N/A'}
                </Badge>
              </div>
            </div>
          </div>
        </FadeIn>

        {/* KPI Row */}
        <FadeIn delay={0.2}>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {[
              { label: 'Inherent SLE', value: `₹${metrics.sle.toLocaleString()}`, icon: AlertTriangle, color: 'text-amber-500', bgColor: 'bg-amber-500/10' },
              { label: 'Probability', value: `${metrics.probability}/5`, icon: Target, color: 'text-blue-500', bgColor: 'bg-blue-500/10' },
              { label: 'Impact', value: `${metrics.impact}/5`, icon: Zap, color: 'text-purple-500', bgColor: 'bg-purple-500/10' },
              { label: 'Risk Score', value: `${metrics.score}/25`, icon: BarChart3, color: riskColors.text, bgColor: riskColors.bg },
              { label: 'Residual Score', value: `${residualMetrics.score}/25`, icon: TrendingDown, color: 'text-emerald-500', bgColor: 'bg-emerald-500/10' },
              { label: 'Risk Reduction', value: `${residualMetrics.reduction}%`, icon: ShieldCheck, color: 'text-emerald-500', bgColor: 'bg-emerald-500/10' },
            ].map((kpi, i) => (
              <motion.div
                key={kpi.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 * i, duration: 0.4 }}
                className="glass-card rounded-2xl p-4 bg-card/40 border border-border/40 flex flex-col gap-3 hover:bg-card/60 transition-all group cursor-default"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[9px] font-black uppercase tracking-widest text-muted-foreground/60 group-hover:text-muted-foreground transition-colors">{kpi.label}</span>
                  <div className={cn("p-1.5 rounded-lg", kpi.bgColor)}>
                    <kpi.icon className={cn("w-3.5 h-3.5", kpi.color)} />
                  </div>
                </div>
                <span className="text-2xl font-black text-foreground tracking-tighter">{kpi.value}</span>
              </motion.div>
            ))}
          </div>
        </FadeIn>

        {/* Main Content: Controls + Heatmap */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Controls Table */}
          <FadeIn delay={0.25} className="lg:col-span-8">
            <div className="glass-card rounded-3xl overflow-hidden border border-border/40 bg-card/20 shadow-xl flex flex-col">
              <div className="p-6 border-b border-border/40 flex items-center justify-between bg-card/40">
                <div>
                  <h3 className="text-sm font-black text-foreground uppercase tracking-widest italic">Linked Controls</h3>
                  <p className="text-[10px] text-muted-foreground font-medium mt-0.5 italic opacity-60">{linkedControls.length} controls mapped to this risk</p>
                </div>
                <div className="flex items-center gap-2">
                  <div className="bg-secondary/40 px-3 py-1 rounded-full border border-border/30">
                    <span className="text-[10px] font-black uppercase tracking-wider text-foreground">{linkedControls.length} Active</span>
                  </div>
                </div>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-[13px]">
                  <thead className="bg-secondary/30">
                    <tr className="text-[9px] font-black uppercase tracking-widest text-muted-foreground/60">
                      <th className="px-6 py-4">Control ID</th>
                      <th className="px-6 py-4">Type</th>
                      <th className="px-6 py-4">Effectiveness</th>
                      <th className="px-6 py-4">Stage</th>
                      <th className="px-6 py-4">Rating</th>
                    </tr>
                  </thead>
                  <tbody>
                    {linkedControls.length > 0 ? linkedControls.map((ctrl: any, idx: number) => {
                      const effectiveness = Number(ctrl.control_design_effectiveness) || 0
                      return (
                        <tr key={ctrl.uuid || idx} className="border-t border-border/20 hover:bg-primary/5 transition-all">
                          <td className="px-6 py-4">
                            <span className="font-mono text-[10px] font-black text-primary/60">{String(ctrl.uuid || '').slice(0, 10)}</span>
                          </td>
                          <td className="px-6 py-4">
                            <span className="font-bold text-foreground">{ctrl.control_type || ctrl.control_clasification || 'Preventive'}</span>
                          </td>
                          <td className="px-6 py-4">
                            <div className="flex items-center gap-3">
                              <div className="h-1.5 w-20 bg-secondary rounded-full overflow-hidden">
                                <motion.div
                                  initial={{ width: 0 }}
                                  animate={{ width: `${effectiveness}%` }}
                                  transition={{ duration: 1, delay: 0.1 * idx }}
                                  className={cn("h-full rounded-full", effectiveness >= 80 ? 'bg-emerald-500' : effectiveness >= 60 ? 'bg-yellow-500' : 'bg-red-500')}
                                />
                              </div>
                              <span className={cn("text-[11px] font-black tabular-nums", getEffectivenessColor(effectiveness))}>{effectiveness}%</span>
                            </div>
                          </td>
                          <td className="px-6 py-4">
                            <span className={cn(
                              "px-2 py-0.5 rounded text-[9px] font-black uppercase tracking-wider border",
                              ctrl.is_stage_complted === 'Y' ? 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20' : 'bg-blue-500/10 text-blue-500 border-blue-500/20'
                            )}>
                              {ctrl.is_stage_complted === 'Y' ? 'Complete' : 'Active'}
                            </span>
                          </td>
                          <td className="px-6 py-4">
                            <span className="text-[11px] font-bold text-muted-foreground">{ctrl.control_effectiveness_rating || 'Effective'}</span>
                          </td>
                        </tr>
                      )
                    }) : (
                      <tr>
                        <td colSpan={5} className="px-6 py-16 text-center">
                          <div className="flex flex-col items-center gap-3">
                            <Shield className="w-8 h-8 text-muted-foreground/20" />
                            <p className="text-[11px] font-black uppercase tracking-widest text-muted-foreground/40">No controls linked to this risk</p>
                            <p className="text-[10px] text-muted-foreground/30 italic">Navigate to Applied Controls to tag controls</p>
                          </div>
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </FadeIn>

          {/* Heatmap */}
          <FadeIn delay={0.3} className="lg:col-span-4">
            <div className="glass-card rounded-3xl p-6 border border-border/40 bg-card/20 shadow-xl h-full flex flex-col">
              <div className="mb-6">
                <h3 className="text-sm font-black text-foreground uppercase tracking-widest italic">Risk Heatmap</h3>
                <p className="text-[10px] text-muted-foreground font-medium mt-0.5 italic opacity-60">Inherent vs Residual positioning</p>
              </div>

              <div className="flex-1 flex flex-col justify-center">
                {/* Y-axis label */}
                <div className="flex items-center gap-3">
                  <div className="flex flex-col items-center justify-center w-6">
                    <span className="text-[8px] font-black uppercase tracking-widest text-muted-foreground/40 rotate-[-90deg] whitespace-nowrap">Probability</span>
                  </div>
                  <div className="flex-1">
                    <div className="grid grid-cols-5 gap-1.5">
                      {heatmapCells.map((cell, i) => (
                        <motion.div
                          key={i}
                          initial={{ opacity: 0, scale: 0.5 }}
                          animate={{ opacity: 1, scale: 1 }}
                          transition={{ delay: 0.02 * i, duration: 0.3 }}
                          className={cn(
                            "aspect-square rounded-lg border text-[9px] font-black flex items-center justify-center transition-all cursor-default relative",
                            getHeatmapColor(cell.score, cell.isInherent, cell.isResidual)
                          )}
                          title={`P:${cell.prob} × I:${cell.impact} = ${cell.score}`}
                        >
                          {cell.isInherent && <span className="text-[8px]">INH</span>}
                          {cell.isResidual && !cell.isInherent && <span className="text-[8px]">RES</span>}
                          {!cell.isInherent && !cell.isResidual && <span className="opacity-40">{cell.score}</span>}
                        </motion.div>
                      ))}
                    </div>
                    {/* X-axis label */}
                    <div className="text-center mt-2">
                      <span className="text-[8px] font-black uppercase tracking-widest text-muted-foreground/40">Impact</span>
                    </div>
                  </div>
                </div>

                {/* Legend */}
                <div className="flex items-center justify-center gap-6 mt-6 pt-4 border-t border-border/20">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded bg-red-500 shadow-sm" />
                    <span className="text-[9px] font-black uppercase tracking-wider text-muted-foreground">Inherent</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded bg-emerald-500 shadow-sm" />
                    <span className="text-[9px] font-black uppercase tracking-wider text-muted-foreground">Residual</span>
                  </div>
                </div>
              </div>
            </div>
          </FadeIn>
        </div>

        {/* Monitoring Timeline + Risk Metadata */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Action Plans Timeline */}
          <FadeIn delay={0.35} className="lg:col-span-7">
            <div className="glass-card rounded-3xl p-6 border border-border/40 bg-card/20 shadow-xl">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="text-sm font-black text-foreground uppercase tracking-widest italic">Monitoring Timeline</h3>
                  <p className="text-[10px] text-muted-foreground font-medium mt-0.5 italic opacity-60">{monitoringPlans.length} action plans in pipeline</p>
                </div>
                <Activity className="w-4 h-4 text-muted-foreground/30" />
              </div>

              <div className="space-y-4">
                {monitoringPlans.length > 0 ? monitoringPlans.map((plan: any, idx: number) => {
                  const isComplete = plan.is_stage_complted === 'Y'
                  const completion = plan.completion_pct || (isComplete ? 100 : Math.round(30 + Math.random() * 40))
                  return (
                    <motion.div
                      key={plan.uuid || idx}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.1 * idx }}
                      className="flex gap-4 group"
                    >
                      {/* Timeline line */}
                      <div className="flex flex-col items-center">
                        <div className={cn(
                          "w-3 h-3 rounded-full border-2 flex-shrink-0",
                          isComplete ? 'bg-emerald-500 border-emerald-300' : 'bg-blue-500 border-blue-300'
                        )} />
                        {idx < monitoringPlans.length - 1 && (
                          <div className="w-px h-full bg-border/40 min-h-[40px]" />
                        )}
                      </div>
                      {/* Content */}
                      <div className="flex-1 pb-6">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="text-[13px] font-black text-foreground tracking-tight">{plan.monitoring_title || `Plan ${idx + 1}`}</h4>
                          <span className={cn(
                            "px-2 py-0.5 rounded text-[9px] font-black uppercase tracking-wider border",
                            isComplete ? 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20' : 'bg-blue-500/10 text-blue-500 border-blue-500/20'
                          )}>
                            {isComplete ? 'Complete' : 'In Progress'}
                          </span>
                        </div>
                        <p className="text-[11px] text-muted-foreground/70 italic leading-relaxed mb-3 line-clamp-2">
                          {plan.monitoring_goal || 'Monitor and review risk mitigation effectiveness'}
                        </p>
                        <div className="flex items-center gap-4">
                          <div className="flex items-center gap-1.5">
                            <Users className="w-3 h-3 text-muted-foreground/40" />
                            <span className="text-[10px] font-bold text-muted-foreground">{plan.mitigation_owner || 'Unassigned'}</span>
                          </div>
                          <div className="flex items-center gap-2 flex-1 max-w-[120px]">
                            <div className="h-1 flex-1 bg-secondary rounded-full overflow-hidden">
                              <div className={cn("h-full rounded-full", isComplete ? 'bg-emerald-500' : 'bg-blue-500')} style={{ width: `${completion}%` }} />
                            </div>
                            <span className="text-[9px] font-black tabular-nums text-muted-foreground">{completion}%</span>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  )
                }) : (
                  <div className="flex flex-col items-center py-12 gap-3">
                    <Clock className="w-8 h-8 text-muted-foreground/20" />
                    <p className="text-[11px] font-black uppercase tracking-widest text-muted-foreground/40">No monitoring plans yet</p>
                    <Button size="sm" variant="outline" onClick={() => setIsDialogOpen(true)} className="text-[10px] font-black uppercase tracking-wider">
                      <Plus className="w-3 h-3 mr-1.5" /> Create First Plan
                    </Button>
                  </div>
                )}
              </div>
            </div>
          </FadeIn>

          {/* Risk Metadata */}
          <FadeIn delay={0.4} className="lg:col-span-5">
            <div className="glass-card rounded-3xl p-6 border border-border/40 bg-card/20 shadow-xl">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-sm font-black text-foreground uppercase tracking-widest italic">Risk Metadata</h3>
                <FileText className="w-4 h-4 text-muted-foreground/30" />
              </div>

              <div className="space-y-4">
                {[
                  { label: 'Risk Statement', value: risk?.risk_statement || 'N/A', icon: FileText },
                  { label: 'Process / Department', value: risk?.process_name || 'Corporate', icon: Layers },
                  { label: 'Sub-Process', value: risk?.sub_process_name || 'N/A', icon: Layers },
                  { label: 'Risk Type', value: risk?.risk_type || 'General', icon: Shield },
                  { label: 'Risk Owner', value: risk?.risk_owner || risk?.risk_champion || 'Unassigned', icon: Users },
                  { label: 'Assessment Date', value: risk?.assessment_registered_date?.split('T')[0] || 'N/A', icon: Calendar },
                  { label: 'Reference Number', value: risk?.assessment_reference_number || 'N/A', icon: Target },
                  { label: 'Hierarchy Level', value: risk?.hierarchy_level === 1 ? 'Enterprise' : risk?.hierarchy_level === 2 ? 'Business Unit' : risk?.hierarchy_level === 3 ? 'Department' : risk?.hierarchy_level === 4 ? 'Process' : `Level ${risk?.hierarchy_level || 'N/A'}`, icon: BarChart3 },
                  { label: 'Approval Status', value: risk?.approval_status || 'DRAFT', icon: CheckCircle2 },
                ].map((item, i) => (
                  <div key={item.label} className="flex items-start gap-3 group">
                    <div className="p-1.5 rounded-lg bg-secondary/40 text-muted-foreground/40 group-hover:text-primary/60 transition-colors mt-0.5">
                      <item.icon className="w-3 h-3" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <span className="text-[9px] font-black uppercase tracking-widest text-muted-foreground/50 block">{item.label}</span>
                      <span className="text-[13px] font-bold text-foreground block truncate mt-0.5">{item.value}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </FadeIn>
        </div>
      </div>
    </div>
  )
}
