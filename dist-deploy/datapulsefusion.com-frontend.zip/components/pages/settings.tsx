'use client'

import React, { useState, useEffect } from 'react'
import {
  Bell,
  Lock,
  Users,
  Database,
  Eye,
  EyeOff,
  Key,
  Check,
  Loader2,
  Save,
  RotateCcw,
  Globe,
  Zap,
  HardDrive,
  ShieldCheck,
  AlertCircle,
  Trash2,
  Plus,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { motion, AnimatePresence } from 'framer-motion'
import { FadeIn } from '@/components/ui/fade-in'
import { useToast } from '@/hooks/use-toast'
import { cn } from '@/lib/utils'
import { useAuth, AppUser, Role } from '@/components/providers/auth-provider'
import { recordAudit } from '@/lib/auditLog'
import { useConfirm } from '@/components/ui/confirm-dialog'

const tabs = [
  { id: 'general', name: 'Organization', icon: Globe },
  { id: 'notifications', name: 'Notifications', icon: Bell },
  { id: 'security', name: 'Security', icon: Lock },
  { id: 'users', name: 'User Management', icon: Users },
  { id: 'api', name: 'API & Integrations', icon: Key },
  { id: 'data', name: 'Data Retention', icon: HardDrive },
]

const SETTINGS_KEY = 'pericope_settings_v1'

interface OrgSettings {
  orgName: string
  industry: string
  currency: string
  maturityTarget: string
  telemetryRetention: string
  notifications: { critical: boolean; sla: boolean; weekly: boolean }
  security: { mfa: boolean; encryption: string; sessionTimeout: number }
  dataRetention: { auditLog: string; assessment: string; report: string; piiHandling: string }
}

const DEFAULT_SETTINGS: OrgSettings = {
  orgName: 'Acme Corporation',
  industry: 'Financial Services',
  currency: 'INR',
  maturityTarget: 'Optimized',
  telemetryRetention: '5 Years',
  notifications: { critical: true, sla: true, weekly: false },
  security: { mfa: true, encryption: 'AES-256 GCM', sessionTimeout: 30 },
  dataRetention: { auditLog: '7 Years', assessment: '5 Years', report: '3 Years', piiHandling: 'Pseudonymized' },
}

const INDUSTRIES = ['Financial Services', 'Healthcare', 'Technology', 'Manufacturing', 'Retail', 'Energy & Utilities', 'Telecommunications', 'Public Sector', 'Education', 'Insurance']
const CURRENCIES = ['INR', 'USD', 'EUR', 'GBP', 'JPY', 'AUD', 'SGD', 'AED']
const ROLES: Role[] = ['Administrator', 'Risk Manager', 'Assessor', 'Auditor', 'Viewer']

export function SettingsPage() {
  const { toast } = useToast()
  const confirm = useConfirm()
  const { user: currentUser, users, setUsers, hasPermission } = useAuth()
  const [activeTab, setActiveTab] = useState('general')
  const [showPassword, setShowPassword] = useState(false)
  const [saving, setSaving] = useState(false)

  const [settings, setSettings] = useState<OrgSettings>(DEFAULT_SETTINGS)
  const [draft, setDraft] = useState<OrgSettings>(DEFAULT_SETTINGS)

  useEffect(() => {
    try {
      const stored = localStorage.getItem(SETTINGS_KEY)
      if (stored) {
        const parsed = JSON.parse(stored)
        setSettings(parsed)
        setDraft(parsed)
      }
    } catch { /* ignore */ }
  }, [])

  const persist = (next: OrgSettings) => {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(next))
    setSettings(next)
  }

  const handleSave = async () => {
    setSaving(true)
    await new Promise(r => setTimeout(r, 400))
    persist(draft)
    recordAudit({
      action: 'SETTINGS_CHANGE',
      entity: 'Settings',
      entity_id: activeTab,
      description: `Saved ${activeTab} settings`,
      before: settings,
      after: draft,
      result: 'SUCCESS',
    })
    toast({ title: 'Settings saved', description: 'Your changes are now active.' })
    setSaving(false)
  }

  const handleReset = () => {
    setDraft(DEFAULT_SETTINGS)
    toast({ title: 'Reset', description: 'Form reverted to defaults. Click Save to persist.' })
  }

  // ----- User management -----
  const [newUser, setNewUser] = useState<Omit<AppUser, 'id' | 'lastLogin'>>({
    name: '',
    email: '',
    role: 'Viewer',
    department: 'Operations',
    active: true,
  })

  const addUser = () => {
    if (!hasPermission('admin')) {
      toast({ title: 'Insufficient permission', description: 'Only Administrators can manage users.', variant: 'destructive' })
      return
    }
    if (!newUser.name || !newUser.email) {
      toast({ title: 'Missing fields', description: 'Name and email are required.', variant: 'destructive' })
      return
    }
    const id = `U-${String(users.length + 1).padStart(3, '0')}`
    const created: AppUser = { ...newUser, id }
    setUsers([...users, created])
    recordAudit({
      action: 'CREATE',
      entity: 'User',
      entity_id: id,
      description: `Created ${created.role} ${created.name} (${created.email})`,
      after: created,
      result: 'SUCCESS',
    })
    toast({ title: 'User created', description: `${created.name} added as ${created.role}.` })
    setNewUser({ name: '', email: '', role: 'Viewer', department: 'Operations', active: true })
  }

  const changeRole = (id: string, role: Role) => {
    if (!hasPermission('admin')) return
    const before = users.find(u => u.id === id)
    const next = users.map(u => (u.id === id ? { ...u, role } : u))
    setUsers(next)
    if (before) {
      recordAudit({
        action: 'ROLE_CHANGE',
        entity: 'User',
        entity_id: id,
        description: `Changed role of ${before.name} from ${before.role} to ${role}`,
        before, after: { ...before, role },
        result: 'SUCCESS',
      })
    }
  }

  const toggleActive = (id: string) => {
    if (!hasPermission('admin')) return
    const before = users.find(u => u.id === id)
    const next = users.map(u => (u.id === id ? { ...u, active: !u.active } : u))
    setUsers(next)
    if (before) {
      recordAudit({
        action: 'UPDATE',
        entity: 'User',
        entity_id: id,
        description: `${!before.active ? 'Activated' : 'Deactivated'} ${before.name}`,
        before, after: { ...before, active: !before.active },
        result: 'SUCCESS',
      })
    }
  }

  const removeUser = async (id: string) => {
    if (!hasPermission('admin')) return
    const target = users.find(u => u.id === id)
    if (!target) return
    if (target.id === currentUser?.id) {
      toast({ title: 'Blocked', description: 'You cannot delete your own account.', variant: 'destructive' })
      return
    }
    const ok = await confirm({
      title: `Remove ${target.name}?`,
      description: 'This will revoke all access for the user. This action cannot be undone.',
      confirmLabel: 'Remove user',
      tone: 'danger',
    })
    if (!ok) return
    setUsers(users.filter(u => u.id !== id))
    recordAudit({
      action: 'DELETE',
      entity: 'User',
      entity_id: id,
      description: `Removed user ${target.name} (${target.email})`,
      before: target,
      result: 'SUCCESS',
    })
    toast({ title: 'User removed', description: `${target.name} has been removed.` })
  }

  return (
    <div className="flex-1 pb-10 bg-background/20 min-h-screen">
      <FadeIn delay={0.1} direction="none">
        <div className="border-b border-border/40 px-6 py-6 bg-background/60 backdrop-blur-xl sticky top-0 z-40 shadow-sm">
          <h1 className="text-xl font-black text-foreground tracking-tighter uppercase">Settings</h1>
          <p className="text-[12px] text-muted-foreground mt-1 font-medium opacity-70">Manage organization, users, security, and data retention</p>
        </div>
      </FadeIn>

      <div className="flex px-8 pt-8 gap-12 items-start max-w-[1400px] mx-auto">
        {/* Navigation Rail */}
        <FadeIn delay={0.2} className="w-64 flex-shrink-0 sticky top-32">
          <div className="space-y-2">
            {tabs.map(tab => {
              const Icon = tab.icon
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={cn(
                    'relative w-full flex items-center gap-4 px-5 py-3 rounded-2xl text-[12px] font-black uppercase tracking-widest transition-all duration-300 text-left group',
                    activeTab === tab.id ? 'text-primary shadow-lg shadow-primary/5' : 'text-muted-foreground hover:text-foreground hover:bg-secondary/40'
                  )}
                >
                  <Icon className={cn('w-4 h-4 transition-transform group-hover:scale-110', activeTab === tab.id ? 'text-primary' : 'text-muted-foreground/60')} />
                  {tab.name}
                  {activeTab === tab.id && (
                    <motion.div
                      layoutId="activeSettingsRail"
                      className="absolute inset-0 bg-card/60 border border-border/40 rounded-2xl -z-10 shadow-[0_10px_30px_-10px_rgba(0,0,0,0.1)]"
                      transition={{ type: 'spring', stiffness: 400, damping: 30 }}
                    />
                  )}
                </button>
              )
            })}
          </div>
        </FadeIn>

        {/* Surface */}
        <div className="flex-1 min-h-[600px] pb-20">
          <AnimatePresence mode="wait">
            {/* ORGANIZATION */}
            {activeTab === 'general' && (
              <motion.div key="general" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-10">
                <div className="space-y-6">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-2xl bg-primary/10 text-primary border border-primary/20"><Globe className="w-5 h-5" /></div>
                    <h2 className="text-base font-black text-foreground uppercase tracking-widest">Organization Profile</h2>
                  </div>

                  <div className="glass-card rounded-3xl p-8 bg-card/30 border border-border/40 shadow-xl space-y-8">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-muted-foreground uppercase tracking-tighter pl-1">Organization Name</label>
                        <Input value={draft.orgName} onChange={e => setDraft({ ...draft, orgName: e.target.value })} className="h-11 rounded-xl font-bold text-sm" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-muted-foreground uppercase tracking-tighter pl-1">Industry Sector</label>
                        <select value={draft.industry} onChange={e => setDraft({ ...draft, industry: e.target.value })} className="w-full h-11 px-4 bg-background/50 border border-border/40 rounded-xl font-bold text-sm">
                          {INDUSTRIES.map(i => <option key={i} value={i}>{i}</option>)}
                        </select>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-muted-foreground uppercase tracking-tighter pl-1">Reporting Currency</label>
                        <select value={draft.currency} onChange={e => setDraft({ ...draft, currency: e.target.value })} className="w-full h-11 px-4 bg-background/50 border border-border/40 rounded-xl font-bold text-sm">
                          {CURRENCIES.map(c => <option key={c} value={c}>{c}</option>)}
                        </select>
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-muted-foreground uppercase tracking-tighter pl-1">ERM Maturity Target</label>
                        <select value={draft.maturityTarget} onChange={e => setDraft({ ...draft, maturityTarget: e.target.value })} className="w-full h-11 px-4 bg-background/50 border border-border/40 rounded-xl font-bold text-sm">
                          {['Initial', 'Developing', 'Defined', 'Managed', 'Optimized'].map(v => <option key={v} value={v}>{v}</option>)}
                        </select>
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-muted-foreground uppercase tracking-tighter pl-1">Default Retention</label>
                        <select value={draft.telemetryRetention} onChange={e => setDraft({ ...draft, telemetryRetention: e.target.value })} className="w-full h-11 px-4 bg-background/50 border border-border/40 rounded-xl font-bold text-sm">
                          {['1 Year', '3 Years', '5 Years', '7 Years', 'Indefinite'].map(v => <option key={v} value={v}>{v}</option>)}
                        </select>
                      </div>
                    </div>
                  </div>
                </div>

                <ActionRow saving={saving} onSave={handleSave} onReset={handleReset} />
              </motion.div>
            )}

            {/* NOTIFICATIONS */}
            {activeTab === 'notifications' && (
              <motion.div key="notifications" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-8">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 rounded-2xl bg-blue-500/10 text-blue-500 border border-blue-500/20"><Bell className="w-5 h-5" /></div>
                  <h2 className="text-base font-black text-foreground uppercase tracking-widest">Notifications</h2>
                </div>
                <div className="glass-card rounded-3xl p-8 bg-card/30 border border-border/40 shadow-xl space-y-6">
                  {([
                    { key: 'critical', label: 'Critical Risk Alerts', desc: 'Instant dispatch for high-exposure risk events.' },
                    { key: 'sla', label: 'SLA Escalation', desc: 'Notify stakeholders when monitoring actions are overdue.' },
                    { key: 'weekly', label: 'Weekly Digest', desc: 'Aggregated GRC digest every Monday.' },
                  ] as const).map(item => (
                    <div key={item.key} className="flex items-center justify-between p-4 bg-secondary/20 rounded-2xl border border-border/10">
                      <div>
                        <p className="text-[13px] font-black text-foreground leading-tight">{item.label}</p>
                        <p className="text-[11px] text-muted-foreground mt-0.5 font-medium">{item.desc}</p>
                      </div>
                      <button
                        onClick={() => setDraft({ ...draft, notifications: { ...draft.notifications, [item.key]: !draft.notifications[item.key] } })}
                        className={cn('w-12 h-6 rounded-full relative cursor-pointer p-1 transition-colors', draft.notifications[item.key] ? 'bg-primary' : 'bg-muted')}
                      >
                        <div className={cn('w-4 h-4 rounded-full bg-white shadow-sm transition-transform', draft.notifications[item.key] ? 'translate-x-6' : 'translate-x-0')} />
                      </button>
                    </div>
                  ))}
                </div>
                <ActionRow saving={saving} onSave={handleSave} onReset={handleReset} />
              </motion.div>
            )}

            {/* SECURITY */}
            {activeTab === 'security' && (
              <motion.div key="security" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-8">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 rounded-2xl bg-blue-500/10 text-blue-500 border border-blue-500/20"><Lock className="w-5 h-5" /></div>
                  <h2 className="text-base font-black text-foreground uppercase tracking-widest">Security Settings</h2>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="glass-card rounded-3xl p-6 bg-card/30 border border-border/40 shadow-xl flex flex-col justify-between">
                    <div className="space-y-2">
                      <p className="text-[11px] font-black uppercase text-muted-foreground">Multi-Factor Auth</p>
                      <p className="text-2xl font-black text-foreground">{draft.security.mfa ? 'Enabled' : 'Disabled'}</p>
                    </div>
                    <Button
                      variant="outline"
                      className="mt-6 rounded-xl"
                      onClick={() => setDraft({ ...draft, security: { ...draft.security, mfa: !draft.security.mfa } })}
                    >
                      {draft.security.mfa ? 'Disable MFA' : 'Enable MFA'}
                    </Button>
                  </div>
                  <div className="glass-card rounded-3xl p-6 bg-card/30 border border-border/40 shadow-xl flex flex-col justify-between">
                    <div className="space-y-2">
                      <p className="text-[11px] font-black uppercase text-muted-foreground">Encryption Mode</p>
                      <p className="text-2xl font-black text-foreground">{draft.security.encryption}</p>
                    </div>
                    <Button variant="ghost" className="mt-6 rounded-xl bg-blue-500/10 text-blue-500"><Check className="w-4 h-4 mr-2" />Verified</Button>
                  </div>
                  <div className="glass-card rounded-3xl p-6 bg-card/30 border border-border/40 shadow-xl flex flex-col justify-between">
                    <div className="space-y-2">
                      <p className="text-[11px] font-black uppercase text-muted-foreground">Session Timeout</p>
                      <p className="text-2xl font-black text-foreground">{draft.security.sessionTimeout} min</p>
                    </div>
                    <select
                      value={draft.security.sessionTimeout}
                      onChange={e => setDraft({ ...draft, security: { ...draft.security, sessionTimeout: Number(e.target.value) } })}
                      className="mt-6 h-9 rounded-xl border border-border/60 px-3 text-xs font-bold"
                    >
                      {[15, 30, 60, 120, 240].map(m => <option key={m} value={m}>{m} minutes</option>)}
                    </select>
                  </div>
                </div>
                <ActionRow saving={saving} onSave={handleSave} onReset={handleReset} />
              </motion.div>
            )}

            {/* USER MANAGEMENT */}
            {activeTab === 'users' && (
              <motion.div key="users" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-8">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 rounded-2xl bg-emerald-500/10 text-emerald-500 border border-emerald-500/20"><Users className="w-5 h-5" /></div>
                  <h2 className="text-base font-black text-foreground uppercase tracking-widest">User Management (RBAC)</h2>
                </div>

                {!hasPermission('admin') && (
                  <div className="rounded-2xl border border-amber-200 bg-amber-50/60 p-4 flex items-center gap-3">
                    <AlertCircle className="w-4 h-4 text-amber-600" />
                    <p className="text-[12px] text-amber-700 font-bold">Read-only — only Administrators can modify users.</p>
                  </div>
                )}

                <div className="glass-card rounded-3xl bg-card/30 border border-border/40 shadow-xl overflow-hidden">
                  <table className="w-full text-[13px]">
                    <thead className="bg-secondary/40">
                      <tr className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">
                        <th className="px-6 py-4 text-left">Name</th>
                        <th className="px-6 py-4 text-left">Email</th>
                        <th className="px-6 py-4 text-left">Role</th>
                        <th className="px-6 py-4 text-left">Department</th>
                        <th className="px-6 py-4 text-left">Status</th>
                        <th className="px-6 py-4 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border/30">
                      {users.map(u => (
                        <tr key={u.id} className="hover:bg-secondary/20">
                          <td className="px-6 py-3 font-bold text-foreground">{u.name}</td>
                          <td className="px-6 py-3 text-muted-foreground">{u.email}</td>
                          <td className="px-6 py-3">
                            <select
                              value={u.role}
                              disabled={!hasPermission('admin')}
                              onChange={e => changeRole(u.id, e.target.value as Role)}
                              className="h-8 px-2 rounded-lg border border-border/60 text-[11px] font-bold bg-white"
                            >
                              {ROLES.map(r => <option key={r}>{r}</option>)}
                            </select>
                          </td>
                          <td className="px-6 py-3 text-muted-foreground">{u.department}</td>
                          <td className="px-6 py-3">
                            <button
                              disabled={!hasPermission('admin')}
                              onClick={() => toggleActive(u.id)}
                              className={cn(
                                'px-2 py-0.5 rounded text-[9px] font-black uppercase tracking-widest border',
                                u.active ? 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20' : 'bg-muted text-muted-foreground border-border'
                              )}
                            >
                              {u.active ? 'Active' : 'Inactive'}
                            </button>
                          </td>
                          <td className="px-6 py-3 text-right">
                            <Button
                              variant="ghost"
                              size="icon"
                              disabled={!hasPermission('admin') || u.id === currentUser?.id}
                              onClick={() => removeUser(u.id)}
                              className="text-red-500 hover:bg-red-50"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {hasPermission('admin') && (
                  <div className="glass-card rounded-3xl p-6 bg-card/30 border border-border/40 shadow-xl space-y-4">
                    <h3 className="text-[11px] font-black uppercase tracking-widest text-foreground">Add User</h3>
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                      <Input placeholder="Full name" value={newUser.name} onChange={e => setNewUser({ ...newUser, name: e.target.value })} />
                      <Input placeholder="Email" type="email" value={newUser.email} onChange={e => setNewUser({ ...newUser, email: e.target.value })} />
                      <select value={newUser.role} onChange={e => setNewUser({ ...newUser, role: e.target.value as Role })} className="h-9 px-3 border border-border rounded-md text-sm">
                        {ROLES.map(r => <option key={r}>{r}</option>)}
                      </select>
                      <Input placeholder="Department" value={newUser.department} onChange={e => setNewUser({ ...newUser, department: e.target.value })} />
                    </div>
                    <Button onClick={addUser} className="rounded-xl"><Plus className="w-4 h-4 mr-2" />Add user</Button>
                  </div>
                )}
              </motion.div>
            )}

            {/* API */}
            {activeTab === 'api' && (
              <motion.div key="api" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-8">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 rounded-2xl bg-blue-500/10 text-blue-500 border border-blue-500/20"><Key className="w-5 h-5" /></div>
                  <h2 className="text-base font-black text-foreground uppercase tracking-widest">API & Integrations</h2>
                </div>
                <div className="glass-card rounded-3xl p-8 bg-card/30 border border-border/40 shadow-xl space-y-6">
                  <div className="space-y-3">
                    <label className="text-[10px] font-black text-muted-foreground uppercase">Production API Key</label>
                    <div className="flex gap-2">
                      <Input
                        type={showPassword ? 'text' : 'password'}
                        value="pericope_prod_ak_9823h4k234h2k34j2k34"
                        readOnly
                        className="h-11 rounded-xl font-mono text-xs"
                      />
                      <Button variant="outline" size="icon" className="h-11 w-11 rounded-xl" onClick={() => setShowPassword(s => !s)}>
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </Button>
                    </div>
                  </div>
                  <p className="text-[11px] text-muted-foreground italic">Rotate keys regularly. Only Administrators can view production credentials.</p>
                </div>
              </motion.div>
            )}

            {/* DATA RETENTION */}
            {activeTab === 'data' && (
              <motion.div key="data" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-8">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 rounded-2xl bg-indigo-500/10 text-indigo-500 border border-indigo-500/20"><HardDrive className="w-5 h-5" /></div>
                  <h2 className="text-base font-black text-foreground uppercase tracking-widest">Data Retention</h2>
                </div>
                <div className="glass-card rounded-3xl p-8 bg-card/30 border border-border/40 shadow-xl space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {[
                      { key: 'auditLog' as const, label: 'Audit log retention' },
                      { key: 'assessment' as const, label: 'Risk assessment retention' },
                      { key: 'report' as const, label: 'Generated reports retention' },
                    ].map(item => (
                      <div className="space-y-2" key={item.key}>
                        <label className="text-[10px] font-black text-muted-foreground uppercase tracking-tighter pl-1">{item.label}</label>
                        <select
                          value={draft.dataRetention[item.key]}
                          onChange={e => setDraft({ ...draft, dataRetention: { ...draft.dataRetention, [item.key]: e.target.value } })}
                          className="w-full h-11 px-4 bg-background/50 border border-border/40 rounded-xl font-bold text-sm"
                        >
                          {['1 Year', '3 Years', '5 Years', '7 Years', '10 Years', 'Indefinite'].map(v => <option key={v}>{v}</option>)}
                        </select>
                      </div>
                    ))}
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-muted-foreground uppercase tracking-tighter pl-1">PII Handling</label>
                      <select
                        value={draft.dataRetention.piiHandling}
                        onChange={e => setDraft({ ...draft, dataRetention: { ...draft.dataRetention, piiHandling: e.target.value } })}
                        className="w-full h-11 px-4 bg-background/50 border border-border/40 rounded-xl font-bold text-sm"
                      >
                        {['Pseudonymized', 'Encrypted at rest', 'Encrypted at rest + in transit', 'Tokenized'].map(v => <option key={v}>{v}</option>)}
                      </select>
                    </div>
                  </div>

                  <div className="rounded-2xl border border-emerald-200 bg-emerald-50/40 p-4 flex items-start gap-3">
                    <ShieldCheck className="w-4 h-4 text-emerald-600 mt-1" />
                    <div>
                      <p className="text-[12px] font-black text-emerald-700">SOX & GDPR aligned</p>
                      <p className="text-[11px] text-emerald-700/80 mt-1">Audit logs retained ≥ 7 years satisfies SOX Section 802. PII handling follows GDPR Article 32.</p>
                    </div>
                  </div>
                </div>
                <ActionRow saving={saving} onSave={handleSave} onReset={handleReset} />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  )
}

function ActionRow({ saving, onSave, onReset }: { saving: boolean; onSave: () => void; onReset: () => void }) {
  return (
    <div className="flex items-center gap-4 pt-6">
      <Button
        size="lg"
        className="rounded-full px-10 h-12 font-black uppercase text-[11px] tracking-widest shadow-2xl shadow-primary/20"
        onClick={onSave}
        disabled={saving}
      >
        {saving ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Save className="w-4 h-4 mr-2" />}
        Save changes
      </Button>
      <Button variant="ghost" className="rounded-full h-12 px-6 font-black uppercase text-[11px] tracking-widest text-muted-foreground" onClick={onReset}>
        <RotateCcw className="w-4 h-4 mr-2" />
        Reset to defaults
      </Button>
    </div>
  )
}
