'use client'

import React, { useMemo, useState } from 'react'
import { ClipboardCheck, Plus, Pencil, Trash2, Search, ShieldCheck, AlertOctagon, Wrench, BookOpen } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'
import { createStore, useStoreSnapshot, genId } from '@/lib/localStore'
import { useToast } from '@/hooks/use-toast'
import { recordAudit } from '@/lib/auditLog'
import { useConfirm } from '@/components/ui/confirm-dialog'
import { useAuth } from '@/components/providers/auth-provider'

export type ControlType = 'Preventive' | 'Detective' | 'Corrective' | 'Compensating'
export type ControlNature = 'Manual' | 'Automated' | 'Hybrid'
export type ControlFrequency = 'Continuous' | 'Daily' | 'Weekly' | 'Monthly' | 'Quarterly' | 'Annual' | 'Event-driven'

export interface Control {
  id: string
  code: string
  name: string
  description: string
  type: ControlType
  nature: ControlNature
  frequency: ControlFrequency
  owner: string
  framework: string[]
  designEffectiveness: number // 1-5
  operatingEffectiveness: number // 1-5
  linkedRisks: string[]
  lastTested?: string
  status: 'Active' | 'Retired' | 'Draft'
}

const SEED: Control[] = [
  { id: 'CTL-001', code: 'CTL-IT-AUTH-01', name: 'MFA on all production systems', description: 'Multi-factor authentication enforced for all administrative access to production environments.', type: 'Preventive', nature: 'Automated', frequency: 'Continuous', owner: 'CISO', framework: ['ISO 27001', 'SOX'], designEffectiveness: 5, operatingEffectiveness: 5, linkedRisks: ['R-001', 'R-014'], lastTested: '2026-04-15', status: 'Active' },
  { id: 'CTL-002', code: 'CTL-FIN-REC-02', name: 'Daily bank reconciliation', description: 'Treasury team reconciles bank statements daily against ERP entries.', type: 'Detective', nature: 'Manual', frequency: 'Daily', owner: 'CFO', framework: ['SOX'], designEffectiveness: 4, operatingEffectiveness: 4, linkedRisks: ['R-003'], lastTested: '2026-05-01', status: 'Active' },
  { id: 'CTL-003', code: 'CTL-OPS-INC-03', name: 'Incident response playbook', description: 'Documented IR procedures with named owners and 1-hour activation SLA.', type: 'Corrective', nature: 'Hybrid', frequency: 'Event-driven', owner: 'COO', framework: ['ISO 27001'], designEffectiveness: 4, operatingEffectiveness: 3, linkedRisks: ['R-007', 'R-012'], lastTested: '2026-03-22', status: 'Active' },
  { id: 'CTL-004', code: 'CTL-COMP-TRN-04', name: 'Annual GDPR training', description: 'All employees complete mandatory GDPR awareness training annually.', type: 'Preventive', nature: 'Automated', frequency: 'Annual', owner: 'Chief Compliance Officer', framework: ['GDPR'], designEffectiveness: 5, operatingEffectiveness: 4, linkedRisks: ['R-005'], lastTested: '2026-01-10', status: 'Active' },
  { id: 'CTL-005', code: 'CTL-IT-BCK-05', name: 'Encrypted off-site backup', description: 'Nightly encrypted backups stored in geo-redundant storage with 30-day retention.', type: 'Preventive', nature: 'Automated', frequency: 'Daily', owner: 'CIO', framework: ['ISO 27001', 'SOX'], designEffectiveness: 5, operatingEffectiveness: 5, linkedRisks: ['R-009'], lastTested: '2026-04-30', status: 'Active' },
  { id: 'CTL-006', code: 'CTL-VEN-DUE-06', name: 'Vendor due-diligence questionnaire', description: 'Risk-based DDQ executed prior to onboarding any new vendor handling sensitive data.', type: 'Preventive', nature: 'Manual', frequency: 'Event-driven', owner: 'Head of Procurement', framework: ['ISO 27001'], designEffectiveness: 3, operatingEffectiveness: 3, linkedRisks: ['R-018'], status: 'Active' },
  { id: 'CTL-007', code: 'CTL-FIN-SOD-07', name: 'Segregation of duties — payments', description: 'Maker–checker control: no single user can both initiate and approve payments > $10K.', type: 'Preventive', nature: 'Automated', frequency: 'Continuous', owner: 'CFO', framework: ['SOX'], designEffectiveness: 5, operatingEffectiveness: 5, linkedRisks: ['R-004'], lastTested: '2026-05-12', status: 'Active' },
  { id: 'CTL-008', code: 'CTL-COMP-MON-08', name: 'Regulatory horizon scanning', description: 'Quarterly review of regulatory changes affecting in-scope jurisdictions.', type: 'Detective', nature: 'Manual', frequency: 'Quarterly', owner: 'Chief Compliance Officer', framework: ['GDPR', 'SOX'], designEffectiveness: 3, operatingEffectiveness: 2, linkedRisks: ['R-010'], status: 'Active' },
]

export const controlsStore = createStore<Control>({ key: 'controls', seed: SEED })

const TYPE_TONE: Record<ControlType, string> = {
  Preventive: 'bg-blue-50 text-blue-700 border-blue-200',
  Detective: 'bg-indigo-50 text-indigo-700 border-indigo-200',
  Corrective: 'bg-amber-50 text-amber-700 border-amber-200',
  Compensating: 'bg-purple-50 text-purple-700 border-purple-200',
}

export function ControlLibraryPage() {
  const items = useStoreSnapshot(controlsStore)
  const { toast } = useToast()
  const confirm = useConfirm()
  const { hasPermission } = useAuth()
  const [editing, setEditing] = useState<Control | null>(null)
  const [search, setSearch] = useState('')
  const [typeFilter, setTypeFilter] = useState<'All' | ControlType>('All')

  const filtered = useMemo(() => items.filter(c => {
    if (typeFilter !== 'All' && c.type !== typeFilter) return false
    if (search && !`${c.name} ${c.code} ${c.owner} ${c.framework.join(' ')}`.toLowerCase().includes(search.toLowerCase())) return false
    return true
  }), [items, search, typeFilter])

  const stats = useMemo(() => ({
    total: items.length,
    active: items.filter(c => c.status === 'Active').length,
    preventive: items.filter(c => c.type === 'Preventive').length,
    avgEff: items.length ? (items.reduce((s, c) => s + (c.designEffectiveness + c.operatingEffectiveness) / 2, 0) / items.length).toFixed(1) : '0',
  }), [items])

  const handleSave = (c: Control) => {
    const isNew = !items.find(x => x.id === c.id)
    if (isNew) {
      controlsStore.add(c)
      recordAudit({ action: 'CREATE', entity: 'Control', entity_id: c.id, description: `Created control ${c.code} – ${c.name}`, after: c, result: 'SUCCESS' })
      toast({ title: 'Control created', description: c.name })
    } else {
      controlsStore.update(c.id, c)
      recordAudit({ action: 'UPDATE', entity: 'Control', entity_id: c.id, description: `Updated control ${c.code}`, after: c, result: 'SUCCESS' })
      toast({ title: 'Control updated', description: c.name })
    }
    setEditing(null)
  }

  const handleDelete = async (c: Control) => {
    const ok = await confirm({
      title: `Delete ${c.code}?`,
      description: `This will remove "${c.name}" from the library. This action cannot be undone.`,
      confirmLabel: 'Delete control',
      tone: 'danger',
    })
    if (!ok) return
    controlsStore.remove(c.id)
    recordAudit({ action: 'DELETE', entity: 'Control', entity_id: c.id, description: `Deleted control ${c.code}`, before: c, result: 'SUCCESS' })
    toast({ title: 'Control deleted', description: c.name })
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <ClipboardCheck className="w-4 h-4 text-primary" />
            <span className="text-[10px] font-black uppercase tracking-[0.3em] text-primary">Central library</span>
          </div>
          <h1 className="text-3xl font-black tracking-tight">Control Library</h1>
          <p className="text-muted-foreground mt-2 font-medium">Central register of preventive, detective, and corrective controls.</p>
        </div>
        {hasPermission('create') && <Button onClick={() => setEditing(blank())} className="rounded-2xl"><Plus className="w-4 h-4 mr-2" />New control</Button>}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <StatCard label="Total controls" value={stats.total} icon={BookOpen} />
        <StatCard label="Active" value={stats.active} icon={ShieldCheck} tone="emerald" />
        <StatCard label="Preventive" value={stats.preventive} icon={Wrench} tone="blue" />
        <StatCard label="Avg effectiveness" value={`${stats.avgEff} / 5`} icon={AlertOctagon} tone="amber" />
      </div>

      <Card className="p-4">
        <div className="flex flex-col md:flex-row gap-3 items-stretch">
          <div className="relative md:max-w-sm w-full">
            <Search className="absolute left-3 top-2.5 w-4 h-4 text-muted-foreground" />
            <Input placeholder="Search controls…" value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
          </div>
          <div className="flex items-center gap-2">
            {(['All', 'Preventive', 'Detective', 'Corrective', 'Compensating'] as const).map(t => (
              <Button key={t} variant={typeFilter === t ? 'primary' : 'ghost'} size="sm" onClick={() => setTypeFilter(t)}>{t}</Button>
            ))}
          </div>
        </div>
      </Card>

      <Card className="overflow-hidden">
        <table className="w-full text-[13px]">
          <thead className="bg-secondary/40">
            <tr className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">
              <th className="px-4 py-3 text-left">Code</th>
              <th className="px-4 py-3 text-left">Control</th>
              <th className="px-4 py-3 text-left">Type</th>
              <th className="px-4 py-3 text-left">Owner</th>
              <th className="px-4 py-3 text-left">Frequency</th>
              <th className="px-4 py-3 text-left">Effectiveness</th>
              <th className="px-4 py-3 text-left">Linked risks</th>
              <th className="px-4 py-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border/30">
            {filtered.map(c => (
              <tr key={c.id} className="hover:bg-secondary/20">
                <td className="px-4 py-3 font-mono text-[11px] text-muted-foreground">{c.code}</td>
                <td className="px-4 py-3">
                  <div className="font-bold text-foreground">{c.name}</div>
                  <div className="text-[11px] text-muted-foreground line-clamp-1">{c.description}</div>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {c.framework.map(f => <Badge key={f} variant="outline" className="text-[9px]">{f}</Badge>)}
                  </div>
                </td>
                <td className="px-4 py-3">
                  <span className={cn('px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-widest border', TYPE_TONE[c.type])}>{c.type}</span>
                </td>
                <td className="px-4 py-3 text-muted-foreground">{c.owner}</td>
                <td className="px-4 py-3 text-muted-foreground">{c.frequency}</td>
                <td className="px-4 py-3">
                  <div className="flex flex-col">
                    <span className="text-[11px] font-bold">D: {c.designEffectiveness}/5 · O: {c.operatingEffectiveness}/5</span>
                    <div className="h-1.5 bg-muted rounded-full mt-1">
                      <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${((c.designEffectiveness + c.operatingEffectiveness) / 10) * 100}%` }} />
                    </div>
                  </div>
                </td>
                <td className="px-4 py-3 text-[11px] text-muted-foreground">{c.linkedRisks.length}</td>
                <td className="px-4 py-3 text-right">
                  {hasPermission('update') && <Button variant="ghost" size="icon" onClick={() => setEditing(c)}><Pencil className="w-4 h-4" /></Button>}
                  {hasPermission('delete') && <Button variant="ghost" size="icon" onClick={() => handleDelete(c)} className="text-red-500 hover:bg-red-50"><Trash2 className="w-4 h-4" /></Button>}
                </td>
              </tr>
            ))}
            {filtered.length === 0 && (
              <tr><td colSpan={8} className="px-4 py-12 text-center text-muted-foreground italic">No controls match your filters.</td></tr>
            )}
          </tbody>
        </table>
      </Card>

      {editing && <ControlEditor initial={editing} onCancel={() => setEditing(null)} onSave={handleSave} />}
    </div>
  )
}

function blank(): Control {
  return {
    id: genId('CTL'),
    code: '', name: '', description: '',
    type: 'Preventive', nature: 'Manual', frequency: 'Monthly',
    owner: '', framework: [],
    designEffectiveness: 3, operatingEffectiveness: 3,
    linkedRisks: [], status: 'Draft',
  }
}

function StatCard({ label, value, icon: Icon, tone = 'blue' }: { label: string; value: number | string; icon: any; tone?: 'blue' | 'emerald' | 'amber' }) {
  const colorMap = { blue: 'text-blue-600 bg-blue-50', emerald: 'text-emerald-600 bg-emerald-50', amber: 'text-amber-600 bg-amber-50' }[tone]
  return (
    <Card className="p-5 flex items-center gap-4">
      <div className={cn('w-12 h-12 rounded-2xl flex items-center justify-center', colorMap)}>
        <Icon className="w-5 h-5" />
      </div>
      <div>
        <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">{label}</p>
        <p className="text-2xl font-black tabular-nums text-foreground">{value}</p>
      </div>
    </Card>
  )
}

function ControlEditor({ initial, onCancel, onSave }: { initial: Control; onCancel: () => void; onSave: (c: Control) => void }) {
  const [draft, setDraft] = useState<Control>(initial)
  const [frameworkText, setFrameworkText] = useState(initial.framework.join(', '))

  const submit = () => {
    if (!draft.code || !draft.name) return
    onSave({ ...draft, framework: frameworkText.split(',').map(s => s.trim()).filter(Boolean) })
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={onCancel}>
      <Card className="w-full max-w-3xl p-8 max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
        <h2 className="text-xl font-black mb-6">{initial.code ? 'Edit control' : 'New control'}</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Field label="Code"><Input value={draft.code} onChange={e => setDraft({ ...draft, code: e.target.value })} placeholder="CTL-XX-NN" /></Field>
          <Field label="Name"><Input value={draft.name} onChange={e => setDraft({ ...draft, name: e.target.value })} /></Field>
          <Field label="Description" wide><Input value={draft.description} onChange={e => setDraft({ ...draft, description: e.target.value })} /></Field>
          <Field label="Type">
            <select className="h-9 px-3 border border-border rounded-md text-sm w-full" value={draft.type} onChange={e => setDraft({ ...draft, type: e.target.value as ControlType })}>
              {['Preventive', 'Detective', 'Corrective', 'Compensating'].map(o => <option key={o}>{o}</option>)}
            </select>
          </Field>
          <Field label="Nature">
            <select className="h-9 px-3 border border-border rounded-md text-sm w-full" value={draft.nature} onChange={e => setDraft({ ...draft, nature: e.target.value as ControlNature })}>
              {['Manual', 'Automated', 'Hybrid'].map(o => <option key={o}>{o}</option>)}
            </select>
          </Field>
          <Field label="Frequency">
            <select className="h-9 px-3 border border-border rounded-md text-sm w-full" value={draft.frequency} onChange={e => setDraft({ ...draft, frequency: e.target.value as ControlFrequency })}>
              {['Continuous', 'Daily', 'Weekly', 'Monthly', 'Quarterly', 'Annual', 'Event-driven'].map(o => <option key={o}>{o}</option>)}
            </select>
          </Field>
          <Field label="Owner"><Input value={draft.owner} onChange={e => setDraft({ ...draft, owner: e.target.value })} /></Field>
          <Field label="Frameworks (comma-separated)"><Input value={frameworkText} onChange={e => setFrameworkText(e.target.value)} placeholder="ISO 27001, SOX" /></Field>
          <Field label="Design effectiveness (1-5)"><Input type="number" min={1} max={5} value={draft.designEffectiveness} onChange={e => setDraft({ ...draft, designEffectiveness: Number(e.target.value) })} /></Field>
          <Field label="Operating effectiveness (1-5)"><Input type="number" min={1} max={5} value={draft.operatingEffectiveness} onChange={e => setDraft({ ...draft, operatingEffectiveness: Number(e.target.value) })} /></Field>
          <Field label="Status">
            <select className="h-9 px-3 border border-border rounded-md text-sm w-full" value={draft.status} onChange={e => setDraft({ ...draft, status: e.target.value as Control['status'] })}>
              {['Active', 'Draft', 'Retired'].map(o => <option key={o}>{o}</option>)}
            </select>
          </Field>
        </div>

        <div className="flex justify-end gap-2 mt-6">
          <Button variant="ghost" onClick={onCancel}>Cancel</Button>
          <Button onClick={submit}>Save</Button>
        </div>
      </Card>
    </div>
  )
}

function Field({ label, children, wide }: { label: string; children: React.ReactNode; wide?: boolean }) {
  return (
    <div className={cn('space-y-1', wide && 'md:col-span-2')}>
      <label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">{label}</label>
      {children}
    </div>
  )
}
