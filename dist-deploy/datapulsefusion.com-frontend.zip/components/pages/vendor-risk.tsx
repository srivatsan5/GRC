'use client'

import React, { useMemo, useState } from 'react'
import { Briefcase, Plus, Trash2, Pencil, ShieldCheck, AlertTriangle, ArrowUpRight } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'
import { createStore, useStoreSnapshot, genId } from '@/lib/localStore'
import { useToast } from '@/hooks/use-toast'
import { recordAudit } from '@/lib/auditLog'
import { useConfirm } from '@/components/ui/confirm-dialog'
import { useAuth } from '@/components/providers/auth-provider'

export type VendorTier = 'Critical' | 'High' | 'Medium' | 'Low'

export interface Vendor {
  id: string
  name: string
  category: string
  tier: VendorTier
  country: string
  contractValue: number
  riskScore: number // 1-100
  lastAssessment: string
  nextReview: string
  contact: string
  status: 'Active' | 'Onboarding' | 'Offboarding'
  findings: number
}

const SEED: Vendor[] = [
  { id: 'V-0001', name: 'Cloudbase Hosting Ltd', category: 'Cloud Infrastructure', tier: 'Critical', country: 'IE', contractValue: 1250000, riskScore: 78, lastAssessment: '2026-03-12', nextReview: '2026-09-12', contact: 'partners@cloudbase.io', status: 'Active', findings: 2 },
  { id: 'V-0002', name: 'Sentinel Cybersecurity', category: 'Managed Security', tier: 'Critical', country: 'US', contractValue: 820000, riskScore: 91, lastAssessment: '2026-04-20', nextReview: '2026-10-20', contact: 'msa@sentinel.com', status: 'Active', findings: 0 },
  { id: 'V-0003', name: 'PayStream Analytics', category: 'Financial Data', tier: 'High', country: 'GB', contractValue: 410000, riskScore: 64, lastAssessment: '2026-02-08', nextReview: '2026-08-08', contact: 'risk@paystream.co.uk', status: 'Active', findings: 1 },
  { id: 'V-0004', name: 'TextWorks Translations', category: 'Localization', tier: 'Low', country: 'IN', contractValue: 65000, riskScore: 32, lastAssessment: '2025-12-15', nextReview: '2026-12-15', contact: 'hello@textworks.in', status: 'Active', findings: 0 },
  { id: 'V-0005', name: 'Apex HR Outsourcing', category: 'HR Services', tier: 'High', country: 'PH', contractValue: 320000, riskScore: 55, lastAssessment: '2026-01-30', nextReview: '2026-07-30', contact: 'compliance@apexhr.ph', status: 'Active', findings: 3 },
  { id: 'V-0006', name: 'Streamline Print Co', category: 'Logistics', tier: 'Medium', country: 'DE', contractValue: 180000, riskScore: 41, lastAssessment: '2026-03-01', nextReview: '2026-09-01', contact: 'sales@streamline.de', status: 'Active', findings: 0 },
  { id: 'V-0007', name: 'NorthStar Legal LLP', category: 'Legal Counsel', tier: 'Medium', country: 'CA', contractValue: 240000, riskScore: 38, lastAssessment: '2026-02-19', nextReview: '2026-08-19', contact: 'contracts@northstar.ca', status: 'Active', findings: 0 },
  { id: 'V-0008', name: 'Auriga Marketing', category: 'Marketing', tier: 'Low', country: 'AU', contractValue: 95000, riskScore: 28, lastAssessment: '2025-11-04', nextReview: '2026-11-04', contact: 'hello@auriga.com.au', status: 'Active', findings: 0 },
]

export const vendorStore = createStore<Vendor>({ key: 'vendors', seed: SEED })

const TIER_TONE: Record<VendorTier, string> = {
  Critical: 'bg-red-50 text-red-700 border-red-200',
  High: 'bg-amber-50 text-amber-700 border-amber-200',
  Medium: 'bg-blue-50 text-blue-700 border-blue-200',
  Low: 'bg-emerald-50 text-emerald-700 border-emerald-200',
}

export function VendorRiskPage() {
  const items = useStoreSnapshot(vendorStore)
  const { toast } = useToast()
  const confirm = useConfirm()
  const { hasPermission } = useAuth()
  const [search, setSearch] = useState('')
  const [tierFilter, setTierFilter] = useState<'All' | VendorTier>('All')
  const [editing, setEditing] = useState<Vendor | null>(null)

  const filtered = useMemo(() => items.filter(v => {
    if (tierFilter !== 'All' && v.tier !== tierFilter) return false
    if (search && !`${v.name} ${v.category} ${v.id} ${v.country}`.toLowerCase().includes(search.toLowerCase())) return false
    return true
  }), [items, search, tierFilter])

  const stats = useMemo(() => ({
    total: items.length,
    critical: items.filter(v => v.tier === 'Critical').length,
    overdue: items.filter(v => new Date(v.nextReview) < new Date()).length,
    findings: items.reduce((s, v) => s + v.findings, 0),
  }), [items])

  const save = (v: Vendor) => {
    const isNew = !items.find(x => x.id === v.id)
    if (isNew) {
      vendorStore.add(v)
      recordAudit({ action: 'CREATE', entity: 'Vendor', entity_id: v.id, description: `Onboarded vendor ${v.name}`, after: v, result: 'SUCCESS' })
      toast({ title: 'Vendor created' })
    } else {
      vendorStore.update(v.id, v)
      recordAudit({ action: 'UPDATE', entity: 'Vendor', entity_id: v.id, description: `Updated vendor ${v.name}`, after: v, result: 'SUCCESS' })
      toast({ title: 'Vendor updated' })
    }
    setEditing(null)
  }

  const remove = async (v: Vendor) => {
    const ok = await confirm({ title: `Remove ${v.name}?`, description: 'This will permanently remove the vendor record. This action cannot be undone.', confirmLabel: 'Remove vendor', tone: 'danger' })
    if (!ok) return
    vendorStore.remove(v.id)
    recordAudit({ action: 'DELETE', entity: 'Vendor', entity_id: v.id, description: `Removed vendor ${v.name}`, before: v, result: 'SUCCESS' })
    toast({ title: 'Vendor removed' })
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Briefcase className="w-4 h-4 text-primary" />
            <span className="text-[10px] font-black uppercase tracking-[0.3em] text-primary">Third-party Risk</span>
          </div>
          <h1 className="text-3xl font-black tracking-tight">Vendor Risk Management</h1>
          <p className="text-muted-foreground mt-2 font-medium">Tiered TPRM register with assessments and review cadence.</p>
        </div>
        {hasPermission('create') && <Button onClick={() => setEditing(blank())} className="rounded-2xl"><Plus className="w-4 h-4 mr-2" />Onboard vendor</Button>}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Stat label="Total vendors" value={stats.total} icon={Briefcase} tone="blue" />
        <Stat label="Critical-tier" value={stats.critical} icon={AlertTriangle} tone="red" />
        <Stat label="Reviews overdue" value={stats.overdue} icon={ArrowUpRight} tone="amber" />
        <Stat label="Open findings" value={stats.findings} icon={ShieldCheck} tone="emerald" />
      </div>

      <Card className="p-4">
        <div className="flex flex-col md:flex-row gap-3 items-stretch">
          <Input placeholder="Search vendors…" value={search} onChange={e => setSearch(e.target.value)} className="md:max-w-sm" />
          <div className="flex items-center gap-2">
            {(['All', 'Critical', 'High', 'Medium', 'Low'] as const).map(t => (
              <Button key={t} variant={tierFilter === t ? 'primary' : 'ghost'} size="sm" onClick={() => setTierFilter(t)}>{t}</Button>
            ))}
          </div>
        </div>
      </Card>

      <Card className="overflow-hidden">
        <table className="w-full text-[13px]">
          <thead className="bg-secondary/40">
            <tr className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">
              <th className="px-4 py-3 text-left">ID</th>
              <th className="px-4 py-3 text-left">Vendor</th>
              <th className="px-4 py-3 text-left">Tier</th>
              <th className="px-4 py-3 text-left">Country</th>
              <th className="px-4 py-3 text-right">Contract</th>
              <th className="px-4 py-3 text-left">Risk score</th>
              <th className="px-4 py-3 text-left">Next review</th>
              <th className="px-4 py-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border/30">
            {filtered.map(v => {
              const overdue = new Date(v.nextReview) < new Date()
              return (
                <tr key={v.id} className="hover:bg-secondary/20">
                  <td className="px-4 py-3 font-mono text-[11px] text-muted-foreground">{v.id}</td>
                  <td className="px-4 py-3">
                    <div className="font-bold">{v.name}</div>
                    <div className="text-[11px] text-muted-foreground">{v.category}</div>
                  </td>
                  <td className="px-4 py-3"><span className={cn('px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-widest border', TIER_TONE[v.tier])}>{v.tier}</span></td>
                  <td className="px-4 py-3 text-muted-foreground">{v.country}</td>
                  <td className="px-4 py-3 text-right tabular-nums">${v.contractValue.toLocaleString()}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <div className="w-20 h-1.5 bg-muted rounded-full overflow-hidden">
                        <div className={cn('h-full rounded-full', v.riskScore > 70 ? 'bg-red-500' : v.riskScore > 50 ? 'bg-amber-500' : 'bg-emerald-500')} style={{ width: `${v.riskScore}%` }} />
                      </div>
                      <span className="text-[11px] font-bold tabular-nums">{v.riskScore}</span>
                    </div>
                  </td>
                  <td className={cn('px-4 py-3 text-[11px]', overdue ? 'text-red-600 font-black' : 'text-muted-foreground')}>{v.nextReview}{overdue ? ' · overdue' : ''}</td>
                  <td className="px-4 py-3 text-right">
                    {hasPermission('update') && <Button variant="ghost" size="icon" onClick={() => setEditing(v)}><Pencil className="w-4 h-4" /></Button>}
                    {hasPermission('delete') && <Button variant="ghost" size="icon" onClick={() => remove(v)} className="text-red-500 hover:bg-red-50"><Trash2 className="w-4 h-4" /></Button>}
                  </td>
                </tr>
              )
            })}
            {filtered.length === 0 && <tr><td colSpan={8} className="px-4 py-12 text-center text-muted-foreground italic">No vendors match.</td></tr>}
          </tbody>
        </table>
      </Card>

      {editing && <VendorEditor initial={editing} onCancel={() => setEditing(null)} onSave={save} />}
    </div>
  )
}

function blank(): Vendor {
  const now = new Date()
  const next = new Date(); next.setMonth(next.getMonth() + 6)
  return { id: genId('V'), name: '', category: '', tier: 'Medium', country: '', contractValue: 0, riskScore: 50, lastAssessment: now.toISOString().slice(0, 10), nextReview: next.toISOString().slice(0, 10), contact: '', status: 'Onboarding', findings: 0 }
}

function Stat({ label, value, icon: Icon, tone }: { label: string; value: number; icon: any; tone: 'blue' | 'emerald' | 'amber' | 'red' }) {
  const colorMap = { blue: 'text-blue-600 bg-blue-50', emerald: 'text-emerald-600 bg-emerald-50', amber: 'text-amber-600 bg-amber-50', red: 'text-red-600 bg-red-50' }[tone]
  return (
    <Card className="p-5 flex items-center gap-4">
      <div className={cn('w-12 h-12 rounded-2xl flex items-center justify-center', colorMap)}><Icon className="w-5 h-5" /></div>
      <div>
        <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">{label}</p>
        <p className="text-2xl font-black tabular-nums text-foreground">{value}</p>
      </div>
    </Card>
  )
}

function VendorEditor({ initial, onCancel, onSave }: { initial: Vendor; onCancel: () => void; onSave: (v: Vendor) => void }) {
  const [draft, setDraft] = useState<Vendor>(initial)
  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={onCancel}>
      <Card className="w-full max-w-2xl p-8" onClick={e => e.stopPropagation()}>
        <h2 className="text-xl font-black mb-6">{initial.name ? 'Edit vendor' : 'Onboard vendor'}</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Field label="Name"><Input value={draft.name} onChange={e => setDraft({ ...draft, name: e.target.value })} /></Field>
          <Field label="Category"><Input value={draft.category} onChange={e => setDraft({ ...draft, category: e.target.value })} /></Field>
          <Field label="Tier">
            <select className="h-9 px-3 border border-border rounded-md text-sm w-full" value={draft.tier} onChange={e => setDraft({ ...draft, tier: e.target.value as VendorTier })}>
              {['Critical', 'High', 'Medium', 'Low'].map(o => <option key={o}>{o}</option>)}
            </select>
          </Field>
          <Field label="Country code"><Input value={draft.country} onChange={e => setDraft({ ...draft, country: e.target.value.toUpperCase() })} maxLength={2} /></Field>
          <Field label="Contract value"><Input type="number" value={draft.contractValue} onChange={e => setDraft({ ...draft, contractValue: Number(e.target.value) })} /></Field>
          <Field label="Risk score (1-100)"><Input type="number" min={1} max={100} value={draft.riskScore} onChange={e => setDraft({ ...draft, riskScore: Number(e.target.value) })} /></Field>
          <Field label="Contact"><Input value={draft.contact} onChange={e => setDraft({ ...draft, contact: e.target.value })} /></Field>
          <Field label="Next review"><Input type="date" value={draft.nextReview} onChange={e => setDraft({ ...draft, nextReview: e.target.value })} /></Field>
        </div>
        <div className="flex justify-end gap-2 mt-6">
          <Button variant="ghost" onClick={onCancel}>Cancel</Button>
          <Button onClick={() => onSave(draft)}>Save</Button>
        </div>
      </Card>
    </div>
  )
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1">
      <label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">{label}</label>
      {children}
    </div>
  )
}
