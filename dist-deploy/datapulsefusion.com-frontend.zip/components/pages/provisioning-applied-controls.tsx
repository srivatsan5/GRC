'use client'

import React, { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { ArrowLeft, Plus, Trash2, Loader2 } from 'lucide-react'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { oracleService } from '@/lib/oracleService'
import { toast } from 'sonner'

interface ControlEntry {
  id: number
  control: string
  residual_impact: string
  likelihood: string
  control_owner: string
  control_frequency: string
  control_effectiveness: string
}

interface Props {
  assessmentId: string
  riskId: string
}

export function ProvisioningAppliedControlsPage({ assessmentId, riskId }: Props) {
  const router = useRouter()
  const queryClient = useQueryClient()
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [deleteId, setDeleteId] = useState<string | number | null>(null)

  const { data: controls = [], isLoading } = useQuery({
    queryKey: ['applied-controls', riskId],
    queryFn: () => oracleService.getControlImplementations(),
  })

  const { data: availableControls = [] } = useQuery({
    queryKey: ['control-register'],
    queryFn: () => oracleService.getControlRegisters(),
  })

  const [newControl, setNewControl] = useState<ControlEntry>({
    id: 0,
    control: '',
    residual_impact: '',
    likelihood: '',
    control_owner: '',
    control_frequency: '',
    control_effectiveness: '',
  })

  const createMutation = useMutation({
    mutationFn: (data: ControlEntry) => oracleService.createControlImplementation({
      identify_risk_uuid: Number(riskId) || 1,
      assessment_reference_number_uuid: Number(assessmentId) || 1,
      risk_uuid: Number(riskId) || 1,
      residual_likelihood: Number(data.likelihood) || 1,
      inherent_likelihood: Number(data.residual_impact) || 1,
      control_effectiveness_rating: data.control_effectiveness,
      evidence_notes: data.control,
      is_stage_complted: 'N',
      approval_status: 'DRAFT',
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['applied-controls', riskId] })
      toast.success('Control added successfully')
      setNewControl({
        id: 0,
        control: '',
        residual_impact: '',
        likelihood: '',
        control_owner: '',
        control_frequency: '',
        control_effectiveness: '',
      })
      setIsDialogOpen(false)
    },
    onError: (err: any) => {
      toast.error(`Failed to add control: ${err.message}`)
    },
  })

  const deleteMutation = useMutation({
    mutationFn: (id: string | number) => oracleService.deleteControlImplementation(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['applied-controls', riskId] })
      toast.success('Control removed successfully')
      setDeleteId(null)
    },
    onError: (err: any) => {
      toast.error(`Failed to remove control: ${err.message}`)
      setDeleteId(null)
    },
  })

  const handleAddControl = () => {
    if (!newControl.control || !newControl.residual_impact || !newControl.likelihood || 
        !newControl.control_owner || !newControl.control_frequency || !newControl.control_effectiveness) {
      toast.error('All fields are required for each control line')
      return
    }
    createMutation.mutate(newControl)
  }

  const handleRemoveControl = (id: string | number) => {
    setDeleteId(id)
    deleteMutation.mutate(id)
  }

  const maxImpact = controls.length > 0 ? Math.max(...controls.map((c: any) => parseInt(c.residual_impact) || 0)) : 0
  const maxLikelihood = controls.length > 0 ? Math.max(...controls.map((c: any) => parseInt(c.residual_likelihood) || parseInt(c.likelihood) || 0)) : 0
  const heatMapValue = maxImpact * maxLikelihood

  return (
    <div className="min-h-screen bg-background p-8">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <Button 
            variant="ghost" 
            size="icon"
            className="transition-all duration-200 hover:bg-muted active:scale-95"
            onClick={() => router.back()}
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold text-foreground">3.1.1.3 Applied Controls</h1>
            <p className="text-sm text-muted-foreground mt-1">Assessment ID: {assessmentId} | Risk ID: {riskId}</p>
          </div>
        </div>

        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-foreground">Tag Controls to Risk</h2>
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button className="transition-all duration-200 hover:scale-105 active:scale-95">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Control
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add Control</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Control</label>
                    <select 
                      value={newControl.control}
                      onChange={(e) => setNewControl({ ...newControl, control: e.target.value })}
                      className="w-full h-10 px-3 border rounded-md"
                    >
                      <option value="">Select control</option>
                      {availableControls.map((ctrl: any) => (
                        <option key={ctrl.uuid || ctrl.id} value={ctrl.control_name || ctrl.name || 'Control'}>
                          {ctrl.control_name || ctrl.name || 'Control'}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-1">Residual Impact</label>
                      <select 
                        value={newControl.residual_impact}
                        onChange={(e) => setNewControl({ ...newControl, residual_impact: e.target.value })}
                        className="w-full h-10 px-3 border rounded-md"
                      >
                        <option value="">Select impact</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">Likelihood</label>
                      <select 
                        value={newControl.likelihood}
                        onChange={(e) => setNewControl({ ...newControl, likelihood: e.target.value })}
                        className="w-full h-10 px-3 border rounded-md"
                      >
                        <option value="">Select likelihood</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                      </select>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-1">Control Owner</label>
                      <select 
                        value={newControl.control_owner}
                        onChange={(e) => setNewControl({ ...newControl, control_owner: e.target.value })}
                        className="w-full h-10 px-3 border rounded-md"
                      >
                        <option value="">Select owner</option>
                        <option value="Owner A">Owner A</option>
                        <option value="Owner B">Owner B</option>
                        <option value="Owner C">Owner C</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">Control Frequency</label>
                      <select 
                        value={newControl.control_frequency}
                        onChange={(e) => setNewControl({ ...newControl, control_frequency: e.target.value })}
                        className="w-full h-10 px-3 border rounded-md"
                      >
                        <option value="">Select frequency</option>
                        <option value="Daily">Daily</option>
                        <option value="Weekly">Weekly</option>
                        <option value="Monthly">Monthly</option>
                        <option value="Quarterly">Quarterly</option>
                        <option value="Annually">Annually</option>
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Control Effectiveness</label>
                    <select 
                      value={newControl.control_effectiveness}
                      onChange={(e) => setNewControl({ ...newControl, control_effectiveness: e.target.value })}
                      className="w-full h-10 px-3 border rounded-md"
                    >
                      <option value="">Select effectiveness</option>
                      <option value="Effective">Effective</option>
                      <option value="Partially Effective">Partially Effective</option>
                      <option value="Ineffective">Ineffective</option>
                    </select>
                  </div>
                  <div className="flex justify-end gap-2 pt-4">
                    <Button 
                      variant="outline" 
                      className="transition-all duration-200 active:scale-95"
                      onClick={() => setIsDialogOpen(false)}
                    >
                      Cancel
                    </Button>
                    <Button 
                      onClick={handleAddControl} 
                      disabled={createMutation.isPending}
                      className="transition-all duration-200 hover:scale-105 active:scale-95"
                    >
                      {createMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Save'}
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          <div className="border rounded-lg overflow-hidden">
            <table className="w-full">
              <thead className="bg-muted">
                <tr>
                  <th className="text-left p-4 font-medium">Control</th>
                  <th className="text-left p-4 font-medium">Residual Impact</th>
                  <th className="text-left p-4 font-medium">Likelihood</th>
                  <th className="text-left p-4 font-medium">Control Owner</th>
                  <th className="text-left p-4 font-medium">Control Frequency</th>
                  <th className="text-left p-4 font-medium">Control Effectiveness</th>
                  <th className="text-right p-4 font-medium"></th>
                </tr>
              </thead>
              <tbody>
                {isLoading ? (
                  <tr>
                    <td colSpan={7} className="p-8 text-center">
                      <Loader2 className="w-6 h-6 animate-spin mx-auto" />
                    </td>
                  </tr>
                ) : (
                  controls.map((control: any) => (
                    <tr key={control.uuid} className="border-t">
                      <td className="p-4">{control.control_id}</td>
                      <td className="p-4">{control.residual_likelihood}</td>
                      <td className="p-4">{control.residual_likelihood}</td>
                      <td className="p-4">{control.control_owner}</td>
                      <td className="p-4">{control.control_frequency}</td>
                      <td className="p-4">{control.control_design_effectiveness}</td>
                      <td className="p-4 text-right">
                        <Button 
                          variant="ghost" 
                          size="icon"
                          className="transition-all duration-200 hover:bg-destructive/10 active:scale-95"
                          onClick={() => handleRemoveControl(control.uuid)}
                          disabled={deleteMutation.isPending && deleteId === control.uuid}
                        >
                          {deleteMutation.isPending && deleteId === control.uuid ? (
                            <Loader2 className="w-4 h-4 animate-spin" />
                          ) : (
                            <Trash2 className="w-4 h-4" />
                          )}
                        </Button>
                      </td>
                    </tr>
                  ))
                )}
                {!isLoading && controls.length === 0 && (
                  <tr>
                    <td colSpan={7} className="p-8 text-center text-muted-foreground">
                      No controls tagged to this risk
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        <div className="mt-8 p-6 border rounded-lg bg-muted/20">
          <h3 className="text-lg font-bold mb-2">Heat Map</h3>
          <p className="text-sm text-muted-foreground mb-4">Max impact multiplied by max likelihood across all controls</p>
          <div className="text-4xl font-bold text-foreground">{heatMapValue}</div>
        </div>
      </div>
    </div>
  )
}
