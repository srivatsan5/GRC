'use client'

import React, { useState, createContext, useContext } from 'react'
import { PericopeSidebar } from './pericope-sidebar'
import { PericopeNavbar } from './pericope-navbar'
import { cn } from '@/lib/utils'

// Context for sidebar state
const SidebarContext = createContext<{ isOpen: boolean; toggle: () => void; close: () => void }>({
  isOpen: false,
  toggle: () => {},
  close: () => {},
})

export function useSidebar() {
  return useContext(SidebarContext)
}

export function PericopeLayout({ children, className }: { children: React.ReactNode, className?: string }) {
  const [sidebarOpen, setSidebarOpen] = useState(false)

  const toggle = () => setSidebarOpen(prev => !prev)
  const close = () => setSidebarOpen(false)

  return (
    <SidebarContext.Provider value={{ isOpen: sidebarOpen, toggle, close }}>
      <div className="min-h-screen bg-white relative font-sans">
        {/* Plain White/Blue Background Layer */}
        <div className="fixed inset-0 pointer-events-none z-0 bg-blue-50/20" />

        {/* Overlay when sidebar is open */}
        {sidebarOpen && (
          <div
            className="fixed inset-0 bg-blue-900/10 backdrop-blur-[2px] z-40 transition-opacity"
            onClick={close}
          />
        )}

        {/* Collapsible Sidebar */}
        <PericopeSidebar />

        {/* Main Content — full width, no left margin */}
        <div className="relative z-10 flex flex-col min-h-screen">
          <PericopeNavbar />
          <main className={cn(
            "flex-1 mt-16 px-8 py-10 max-w-[1700px] mx-auto w-full transition-all duration-300",
            className
          )}>
            <div className="animate-in fade-in slide-in-from-bottom-6 duration-700">
              {children}
            </div>
          </main>
          
          {/* Footer */}
          <footer className="px-8 py-6 opacity-30 select-none pointer-events-none flex justify-between items-center text-[10px] uppercase font-black tracking-[0.3em] text-blue-400">
             <span>Pericope ERM · Enterprise Risk Management</span>
             <span>System Status: Operational</span>
          </footer>
        </div>
      </div>
    </SidebarContext.Provider>
  )
}
