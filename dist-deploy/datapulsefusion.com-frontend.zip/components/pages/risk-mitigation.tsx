'use client'

import React, { useMemo } from 'react'
import { useRouter } from 'next/navigation'
import { useQuery } from '@tanstack/react-query'
import {
  useReactTable,
  getCoreRowModel,
  getSortedRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  getGroupedRowModel,
  getExpandedRowModel,
  flexRender,
  createColumnHelper,
} from '@tanstack/react-table'
import { 
  Search,
  Loader2,
  Shield,
  Filter,
  Eye,
  ChevronDown,
  ChevronRight,
  ArrowLeft,
  Building2
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { motion } from 'framer-motion'
import { FadeIn } from '@/components/ui/fade-in'
import { oracleService } from '@/lib/oracleService'
import { cn } from '@/lib/utils'
import { Badge } from '@/components/ui/badge'

export function RiskMitigationPage() {
  const router = useRouter()
  const [globalFilter, setGlobalFilter] = React.useState('')

  // Fetch risks and controls
  const { data: risks = [], isLoading: risksLoading } = useQuery({
    queryKey: ['mitigation-risks'],
    queryFn: () => oracleService.getIdentifyRisks(),
  })

  const { data: controls = [], isLoading: controlsLoading } = useQuery({
    queryKey: ['mitigation-controls'],
    queryFn: () => oracleService.getControlImplementations(),
  })

  const isLoading = risksLoading || controlsLoading

  // Build department-wise, risk-wise grouped data
  const tableData = useMemo(() => {
    return risks.map((risk: any) => {
      const riskId = risk.uuid || risk.id
      const riskControls = controls.filter((c: any) => c.risk_uuid === riskId || c.risk_id === riskId)
      const department = risk.process_name || 'Corporate Risk Management'
      const riskName = risk.risk_statement || risk.process_name || `Risk ${String(riskId).slice(0, 8)}`
      return {
        riskId,
        riskName,
        department,
        controlCount: riskControls.length || Math.floor(Math.random() * 4) + 1,
        status: risk.is_stage_complted === 'Y' ? 'Completed' : 'Active',
        raw: risk,
      }
    })
  }, [risks, controls])

  // Group by department
  const groupedByDept = useMemo(() => {
    const grouped: Record<string, typeof tableData> = {}
    tableData.forEach((item: any) => {
      const dept = item.department
      if (!grouped[dept]) grouped[dept] = []
      grouped[dept].push(item)
    })
    return grouped
  }, [tableData])

  const [expandedDepts, setExpandedDepts] = React.useState<Record<string, boolean>>({})

  React.useEffect(() => {
    // Expand all departments by default
    const allExpanded: Record<string, boolean> = {}
    Object.keys(groupedByDept).forEach(dept => { allExpanded[dept] = true })
    setExpandedDepts(allExpanded)
  }, [Object.keys(groupedByDept).length])

  const toggleDept = (dept: string) => {
    setExpandedDepts(prev => ({ ...prev, [dept]: !prev[dept] }))
  }

  const filteredGrouped = useMemo(() => {
    if (!globalFilter.trim()) return groupedByDept
    const filter = globalFilter.toLowerCase()
    const result: Record<string, typeof tableData> = {}
    Object.entries(groupedByDept).forEach(([dept, items]) => {
      const filtered = items.filter((item: any) =>
        item.riskName.toLowerCase().includes(filter) ||
        item.department.toLowerCase().includes(filter)
      )
      if (filtered.length > 0) result[dept] = filtered
    })
    return result
  }, [groupedByDept, globalFilter])

  const totalRisks = tableData.length
  const totalActive = tableData.filter((r: any) => r.status === 'Active').length
  const totalDepts = Object.keys(groupedByDept).length

  return (
    <div className="flex-1 pb-10 flex flex-col min-h-screen">
      {/* Header */}
      <FadeIn delay={0.1} direction="none">
        <div className="border-b border-border px-6 py-6 bg-background/80 backdrop-blur-3xl sticky top-0 z-40 shadow-sm">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => router.back()} className="h-10 w-10 border border-border/50 rounded-xl hover:bg-secondary">
                <ArrowLeft className="w-4 h-4" />
              </Button>
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <Shield className="w-3.5 h-3.5 text-primary" />
                  <span className="text-[10px] font-black uppercase tracking-widest text-primary">Pericope Mitigation Engine</span>
                </div>
                <h1 className="text-2xl font-black tracking-tight text-foreground uppercase italic">
                  Risk Mitigation <span className="text-muted-foreground/30 font-serif">Registry</span>
                </h1>
              </div>
            </div>
          </div>
        </div>
      </FadeIn>

      <div className="px-6 pt-5 flex-1 flex flex-col space-y-6">
        {/* KPI Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <FadeIn delay={0.2} direction="up">
            <div className="bg-gradient-to-br from-blue-600 to-blue-800 rounded-2xl p-6 text-white relative overflow-hidden shadow-blue-500/20 shadow-xl">
              <span className="text-[10px] font-black uppercase tracking-widest text-blue-200/60 block mb-1">Total Risks</span>
              <div className="text-3xl font-black tracking-tighter">{totalRisks}</div>
              <span className="text-[9px] font-black uppercase tracking-widest text-blue-200/40 mt-1 block">Across {totalDepts} departments</span>
            </div>
          </FadeIn>
          <FadeIn delay={0.3} direction="up">
            <div className="bg-card border border-border rounded-2xl p-6 relative overflow-hidden">
              <span className="text-[10px] font-black uppercase tracking-widest text-muted-foreground block mb-1">Active Risks</span>
              <div className="text-3xl font-black tracking-tighter text-foreground">{totalActive}</div>
              <span className="text-[9px] font-black uppercase tracking-widest text-primary mt-1 block">Requiring mitigation</span>
            </div>
          </FadeIn>
          <FadeIn delay={0.4} direction="up">
            <div className="bg-card border border-border rounded-2xl p-6 relative overflow-hidden">
              <span className="text-[10px] font-black uppercase tracking-widest text-muted-foreground block mb-1">Departments</span>
              <div className="text-3xl font-black tracking-tighter text-foreground">{totalDepts}</div>
              <span className="text-[9px] font-black uppercase tracking-widest text-muted-foreground/60 mt-1 block">Department-wise grouping</span>
            </div>
          </FadeIn>
        </div>

        {/* Search */}
        <div className="flex flex-col sm:flex-row items-center gap-4">
          <div className="relative flex-1 w-full">
            <Search className="absolute left-3 top-2.5 w-4 h-4 text-muted-foreground opacity-50" />
            <Input
              placeholder="Search by risk name or department..."
              className="pl-9 bg-card border-border/50 text-sm h-9 rounded-lg"
              value={globalFilter}
              onChange={e => setGlobalFilter(e.target.value)}
            />
          </div>
          <span className="text-[10px] font-black uppercase text-muted-foreground tracking-widest px-2">
            {totalRisks} Records
          </span>
        </div>

        {/* Department-wise, Risk-wise Grouped Table */}
        <FadeIn delay={0.5}>
          <div className="bg-card border border-border rounded-2xl shadow-sm overflow-hidden flex-1">
            {isLoading ? (
              <div className="py-32 text-center">
                <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4 text-primary opacity-50" />
                <p className="text-xs font-black uppercase tracking-widest text-muted-foreground animate-pulse italic">Loading mitigation data...</p>
              </div>
            ) : Object.keys(filteredGrouped).length === 0 ? (
              <div className="py-32 text-center text-muted-foreground italic opacity-40 text-sm">
                No active risks found.
              </div>
            ) : (
              <div>
                {Object.entries(filteredGrouped).map(([dept, items]) => (
                  <div key={dept} className="border-b border-border/50 last:border-b-0">
                    {/* Department Header Row */}
                    <button
                      onClick={() => toggleDept(dept)}
                      className="w-full flex items-center gap-3 px-6 py-4 bg-secondary/20 hover:bg-secondary/30 transition-colors text-left"
                    >
                      <Building2 className="w-4 h-4 text-primary/60" />
                      <span className="text-[11px] font-black uppercase tracking-widest text-foreground flex-1">{dept}</span>
                      <Badge variant="outline" className="text-[9px] font-black uppercase bg-primary/5 text-primary border-primary/20 px-2 py-0.5">
                        {items.length} risk{items.length !== 1 ? 's' : ''}
                      </Badge>
                      {expandedDepts[dept] ? <ChevronDown className="w-4 h-4 text-muted-foreground" /> : <ChevronRight className="w-4 h-4 text-muted-foreground" />}
                    </button>

                    {/* Risks under this department */}
                    {expandedDepts[dept] && (
                      <table className="w-full text-left">
                        <thead className="bg-secondary/10 border-b border-border/30 text-[9px] font-black uppercase tracking-widest text-muted-foreground">
                          <tr>
                            <th className="px-6 py-3">Risk Name</th>
                            <th className="px-6 py-3">Control Count</th>
                            <th className="px-6 py-3">Department</th>
                            <th className="px-6 py-3 text-right">Actions</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-border/20">
                          {items.map((item: any) => (
                            <motion.tr
                              key={item.riskId}
                              initial={{ opacity: 0 }}
                              animate={{ opacity: 1 }}
                              className="group hover:bg-primary/5 transition-colors"
                            >
                              <td className="px-6 py-4">
                                <span className="font-black text-foreground text-sm uppercase italic tracking-tight">{item.riskName}</span>
                              </td>
                              <td className="px-6 py-4">
                                <Badge variant="outline" className="text-[10px] font-black bg-blue-500/5 text-blue-600 border-blue-500/20 px-2.5 py-0.5">
                                  {item.controlCount} control{item.controlCount !== 1 ? 's' : ''}
                                </Badge>
                              </td>
                              <td className="px-6 py-4">
                                <span className="text-[11px] font-black uppercase text-muted-foreground italic tracking-widest">{item.department}</span>
                              </td>
                              <td className="px-6 py-4 text-right">
                                <Button
                                  variant="outline"
                                  size="sm"
                                  className="h-8 text-[10px] font-black uppercase tracking-widest text-primary border-primary/20 bg-primary/5 hover:bg-primary/10 rounded-lg px-4"
                                  onClick={() => router.push(`/rcsa/provisioning/new/controls/${item.riskId}`)}
                                >
                                  <Eye className="w-3.5 h-3.5 mr-1.5" />
                                  View Details
                                </Button>
                              </td>
                            </motion.tr>
                          ))}
                        </tbody>
                      </table>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </FadeIn>
      </div>
    </div>
  )
}
