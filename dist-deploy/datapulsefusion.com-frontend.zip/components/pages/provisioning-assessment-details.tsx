'use client'

import React, { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { ArrowLeft, Plus, Loader2, Trash2 } from 'lucide-react'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import * as z from 'zod'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { oracleService } from '@/lib/oracleService'
import { toast } from 'sonner'

const addRiskSchema = z.object({
  risk: z.string().min(1, 'Required'),
  inherent_likelihood: z.string().min(1, 'Required'),
  inherent_impact: z.string().min(1, 'Required'),
  justification: z.string().min(1, 'Required'),
  risk_owner: z.string().min(1, 'Required'),
})

type AddRiskFormValues = z.infer<typeof addRiskSchema>

interface Props {
  assessmentId: string
}

export function ProvisioningAssessmentDetailsPage({ assessmentId }: Props) {
  const router = useRouter()
  const queryClient = useQueryClient()
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [deleteId, setDeleteId] = useState<string | number | null>(null)

  const { data: connectedRisks = [], isLoading } = useQuery({
    queryKey: ['connected-risks', assessmentId],
    queryFn: () => oracleService.getIdentifyRisks({ assessment_id: assessmentId }),
  })

  const { data: existingRisks = [] } = useQuery({
    queryKey: ['existing-risks'],
    queryFn: () => oracleService.getRiskStatements(),
  })

  const { register, handleSubmit, reset, formState: { errors } } = useForm<AddRiskFormValues>({
    resolver: zodResolver(addRiskSchema),
    defaultValues: {
      risk: '',
      inherent_likelihood: '',
      inherent_impact: '',
      justification: '',
      risk_owner: '',
    }
  })

  const createMutation = useMutation({
    mutationFn: (data: AddRiskFormValues) => oracleService.createIdentifyRisk({
      risk_statement: data.risk,
      inherent_sle: Number(data.inherent_likelihood) * Number(data.inherent_impact) * 10000,
      risk_owner: data.risk_owner,
      process_name: data.risk_owner,
      approver_comments: data.justification,
      assessment_registered_date: new Date().toISOString(),
      is_stage_complted: 'N',
      status: 'N',
      approval_status: 'DRAFT',
      hierarchy_level: 3,
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['connected-risks', assessmentId] })
      toast.success('Risk added successfully')
      setIsDialogOpen(false)
      reset()
    },
    onError: (err: any) => {
      toast.error(`Failed to add risk: ${err.message}`)
    },
  })

  const deleteMutation = useMutation({
    mutationFn: (id: string | number) => oracleService.deleteIdentifyRisk(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['connected-risks', assessmentId] })
      toast.success('Risk deleted successfully')
      setDeleteId(null)
    },
    onError: (err: any) => {
      toast.error(`Failed to delete risk: ${err.message}`)
      setDeleteId(null)
    },
  })

  const onSubmit = (data: AddRiskFormValues) => {
    createMutation.mutate(data)
  }

  const handleAppliedControls = (riskId: number) => {
    router.push(`/rcsa/provisioning/${assessmentId}/controls/${riskId}`)
  }

  return (
    <div className="min-h-screen bg-background p-8">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <Button 
            variant="ghost" 
            size="icon" 
            className="transition-all duration-200 hover:bg-muted active:scale-95"
            onClick={() => router.back()}
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold text-foreground">3.1.1.1 Assessment Details</h1>
            <p className="text-sm text-muted-foreground mt-1">Assessment ID: {assessmentId}</p>
          </div>
        </div>

        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-foreground">3.1.1.2 Risk Identification</h2>
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button className="transition-all duration-200 hover:scale-105 active:scale-95">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Risk
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add Risk</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Risk</label>
                    <select {...register('risk')} className="w-full h-10 px-3 border rounded-md">
                      <option value="">Select risk</option>
                      {existingRisks.map((risk: any) => (
                        <option key={risk.uuid || risk.id} value={risk.title || risk.risk_reference_number || risk.risk_statement || risk.name}>{risk.title || risk.risk_reference_number || risk.risk_statement || risk.name}</option>
                      ))}
                    </select>
                    {errors.risk && <span className="text-xs text-destructive">{errors.risk.message}</span>}
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-1">Inherent Likelihood</label>
                      <select {...register('inherent_likelihood')} className="w-full h-10 px-3 border rounded-md">
                        <option value="">Select likelihood</option>
                        <option value="1">1 - Rare</option>
                        <option value="2">2 - Unlikely</option>
                        <option value="3">3 - Possible</option>
                        <option value="4">4 - Likely</option>
                        <option value="5">5 - Certain</option>
                      </select>
                      {errors.inherent_likelihood && <span className="text-xs text-destructive">{errors.inherent_likelihood.message}</span>}
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">Inherent Impact</label>
                      <select {...register('inherent_impact')} className="w-full h-10 px-3 border rounded-md">
                        <option value="">Select impact</option>
                        <option value="1">1 - Insignificant</option>
                        <option value="2">2 - Minor</option>
                        <option value="3">3 - Moderate</option>
                        <option value="4">4 - Major</option>
                        <option value="5">5 - Catastrophic</option>
                      </select>
                      {errors.inherent_impact && <span className="text-xs text-destructive">{errors.inherent_impact.message}</span>}
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Justification</label>
                    <textarea {...register('justification')} className="w-full h-24 p-3 border rounded-md resize-none" placeholder="Enter justification" />
                    {errors.justification && <span className="text-xs text-destructive">{errors.justification.message}</span>}
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Risk Owner</label>
                    <select {...register('risk_owner')} className="w-full h-10 px-3 border rounded-md">
                      <option value="">Select risk owner</option>
                      <option value="Owner A">Owner A</option>
                      <option value="Owner B">Owner B</option>
                      <option value="Owner C">Owner C</option>
                    </select>
                    {errors.risk_owner && <span className="text-xs text-destructive">{errors.risk_owner.message}</span>}
                  </div>
                  <div className="flex justify-end gap-2 pt-4">
                    <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
                    <Button type="submit" disabled={createMutation.isPending}>
                      {createMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Save'}
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>

          <div className="border rounded-lg overflow-hidden">
            <table className="w-full">
              <thead className="bg-muted">
                <tr>
                  <th className="text-left p-4 font-medium">Risk</th>
                  <th className="text-left p-4 font-medium">Inherent Likelihood</th>
                  <th className="text-left p-4 font-medium">Inherent Impact</th>
                  <th className="text-left p-4 font-medium">Justification</th>
                  <th className="text-left p-4 font-medium">Risk Owner</th>
                  <th className="text-right p-4 font-medium">Applied Controls</th>
                </tr>
              </thead>
              <tbody>
                {isLoading ? (
                  <tr>
                    <td colSpan={6} className="p-8 text-center">
                      <Loader2 className="w-6 h-6 animate-spin mx-auto" />
                    </td>
                  </tr>
                ) : (
                  connectedRisks.map((risk: any) => (
                    <tr key={risk.uuid} className="border-t">
                      <td className="p-4">{risk.risk_statement || risk.process_name || 'N/A'}</td>
                      <td className="p-4">{risk.inherent_sle}</td>
                      <td className="p-4">{risk.inherent_sle}</td>
                      <td className="p-4">{risk.risk_statement}</td>
                      <td className="p-4">{risk.process_name}</td>
                      <td className="p-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <Button 
                            variant="ghost" 
                            size="icon"
                            className="transition-all duration-200 hover:bg-destructive/10 active:scale-95"
                            onClick={() => {
                              setDeleteId(risk.uuid)
                              deleteMutation.mutate(risk.uuid)
                            }}
                            disabled={deleteMutation.isPending && deleteId === risk.uuid}
                          >
                            {deleteMutation.isPending && deleteId === risk.uuid ? (
                              <Loader2 className="w-4 h-4 animate-spin" />
                            ) : (
                              <Trash2 className="w-4 h-4 text-destructive" />
                            )}
                          </Button>
                          <Button 
                            size="sm" 
                            className="transition-all duration-200 hover:scale-105 active:scale-95"
                            onClick={() => handleAppliedControls(risk.uuid)}
                          >
                            Applied Controls
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
                {!isLoading && connectedRisks.length === 0 && (
                  <tr>
                    <td colSpan={6} className="p-8 text-center text-muted-foreground">
                      No connected risks found
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  )
}
