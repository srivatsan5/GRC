'use client'

import React, { useMemo, useState, useEffect } from 'react'
import {
  useReactTable,
  getCoreRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  getFilteredRowModel,
  flexRender,
  createColumnHelper,
  SortingState,
} from '@tanstack/react-table'
import {
  Search,
  Download,
  ChevronDown,
  ChevronUp,
  Loader2,
  History,
  Database,
  Calendar,
  Filter,
  ArrowRight,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { motion, AnimatePresence } from 'framer-motion'
import { FadeIn } from '@/components/ui/fade-in'
import { cn } from '@/lib/utils'
import { listAudit, AuditEntry } from '@/lib/auditLog'
import { useToast } from '@/hooks/use-toast'

const actionColors: Record<string, string> = {
  CREATE: '#3b82f6',
  UPDATE: '#8b5cf6',
  DELETE: '#ef4444',
  LOGIN: '#10b981',
  LOGOUT: '#64748b',
  APPROVE: '#06b6d4',
  REJECT: '#f59e0b',
  EXPORT: '#a855f7',
  VIEW: '#94a3b8',
  SETTINGS_CHANGE: '#0ea5e9',
  ROLE_CHANGE: '#f97316',
}

export function AuditTrailPage() {
  const { toast } = useToast()
  const [globalFilter, setGlobalFilter] = useState('')
  const [dateFrom, setDateFrom] = useState('')
  const [dateTo, setDateTo] = useState('')
  const [sorting, setSorting] = useState<SortingState>([{ id: 'timestamp', desc: true }])
  const [entries, setEntries] = useState<AuditEntry[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    setEntries(listAudit())
    setLoading(false)
    const handler = () => setEntries(listAudit())
    window.addEventListener('storage', handler)
    return () => window.removeEventListener('storage', handler)
  }, [])

  const filteredByDate = useMemo(() => {
    return entries.filter(e => {
      if (dateFrom && e.timestamp < dateFrom) return false
      if (dateTo && e.timestamp > dateTo + 'T23:59:59') return false
      return true
    })
  }, [entries, dateFrom, dateTo])

  const columnHelper = createColumnHelper<AuditEntry>()

  const columns = useMemo(() => [
    columnHelper.accessor('timestamp', {
      header: 'Timestamp',
      cell: info => {
        const d = new Date(info.getValue())
        return (
          <div className="flex flex-col">
            <span className="font-mono text-[11px] font-black text-foreground tabular-nums">
              {d.toLocaleTimeString('en-GB', { hour12: false })}
            </span>
            <span className="text-[9px] font-bold text-muted-foreground uppercase tracking-tighter">
              {d.toLocaleDateString('en-GB')}
            </span>
          </div>
        )
      },
    }),
    columnHelper.accessor('action', {
      header: 'Action',
      cell: info => {
        const val = info.getValue()
        const color = actionColors[val] || '#64748b'
        return (
          <div className="flex items-center gap-2">
            <div className="w-1.5 h-3 rounded-full" style={{ color, backgroundColor: color }} />
            <span className="text-[10px] font-black uppercase tracking-widest text-foreground">{val.replace('_', ' ')}</span>
          </div>
        )
      },
    }),
    columnHelper.accessor('actor_name', {
      header: 'User',
      cell: info => (
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-full bg-primary/10 border border-primary/20 flex items-center justify-center text-[9px] font-black text-primary">
            {String(info.getValue()).charAt(0).toUpperCase()}
          </div>
          <div className="flex flex-col">
            <span className="font-bold text-foreground text-[12px]">{info.getValue()}</span>
            <span className="text-[9px] text-muted-foreground uppercase tracking-widest">{info.row.original.actor_role}</span>
          </div>
        </div>
      ),
    }),
    columnHelper.accessor('entity', {
      header: 'Entity',
      cell: info => (
        <div className="flex flex-col">
          <span className="text-foreground font-bold text-[12px]">{info.getValue()}</span>
          {info.row.original.entity_id ? (
            <span className="text-[9px] font-mono text-muted-foreground/70">{String(info.row.original.entity_id)}</span>
          ) : null}
        </div>
      ),
    }),
    columnHelper.accessor('description', {
      header: 'Description',
      cell: info => <span className="text-muted-foreground text-[12px] truncate max-w-[260px] block">{info.getValue()}</span>,
    }),
    columnHelper.accessor('result', {
      header: 'Result',
      cell: info => {
        const v = info.getValue()
        return (
          <span className={cn(
            'px-2 py-0.5 rounded text-[9px] font-black uppercase tracking-widest border',
            v === 'SUCCESS'
              ? 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20'
              : 'bg-red-500/10 text-red-600 border-red-500/20'
          )}>
            {v}
          </span>
        )
      },
    }),
  ], [])

  const table = useReactTable({
    data: filteredByDate,
    columns,
    state: { globalFilter, sorting },
    onSortingChange: setSorting,
    onGlobalFilterChange: setGlobalFilter,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    initialState: { pagination: { pageSize: 15 } },
  })

  const stats = useMemo(() => ({
    total: entries.length,
    success: entries.filter(e => e.result === 'SUCCESS').length,
    failed: entries.filter(e => e.result === 'FAILURE').length,
    distinctUsers: new Set(entries.map(e => e.actor_id)).size,
  }), [entries])

  const handleExport = () => {
    const header = 'Timestamp,Action,User,Role,Entity,Entity ID,Description,Result\n'
    const rows = filteredByDate.map(e => [
      e.timestamp,
      e.action,
      `"${e.actor_name}"`,
      e.actor_role,
      `"${e.entity}"`,
      e.entity_id ?? '',
      `"${e.description.replace(/"/g, '""')}"`,
      e.result,
    ].join(',')).join('\n')
    const blob = new Blob([header + rows], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `audit-trail-${new Date().toISOString().slice(0, 10)}.csv`
    a.click()
    URL.revokeObjectURL(url)
    toast({ title: 'Export complete', description: `${filteredByDate.length} audit entries exported.` })
  }

  if (loading) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center min-h-[60vh]">
        <div className="relative mb-6">
          <Loader2 className="w-12 h-12 animate-spin text-primary/30" />
          <History className="absolute inset-0 m-auto w-5 h-5 text-primary animate-pulse" />
        </div>
        <p className="text-[11px] font-black uppercase tracking-widest text-muted-foreground animate-pulse">Loading audit trail…</p>
      </div>
    )
  }

  return (
    <div className="flex-1 pb-10 bg-background/20 font-sans">
      <FadeIn delay={0.1} direction="none">
        <div className="border-b border-border/40 px-6 py-6 bg-background/60 backdrop-blur-xl sticky top-0 z-40 flex justify-between items-center shadow-sm">
          <div>
            <h1 className="text-xl font-black text-foreground tracking-tighter uppercase">Audit Trail</h1>
            <p className="text-[12px] text-muted-foreground mt-1 font-medium opacity-70">User-attributed activity log — SOX & ISO 31000 compliant</p>
          </div>
          <div className="flex items-center gap-4">
            <div className="hidden lg:flex flex-col items-end mr-4">
              <span className="text-[9px] font-black text-muted-foreground uppercase opacity-60">Live</span>
              <span className="text-[11px] font-black text-primary flex items-center gap-1.5">Streaming <div className="w-1.5 h-1.5 rounded-full bg-primary animate-ping" /></span>
            </div>
            <Button variant="outline" size="sm" onClick={handleExport} className="h-9 px-4 rounded-full border-border/50 text-[11px] font-black uppercase tracking-widest bg-card/40">
              <Download className="w-3.5 h-3.5 mr-2" />
              Export CSV
            </Button>
          </div>
        </div>
      </FadeIn>

      <div className="px-6 pt-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <div className="glass-card rounded-2xl p-4 bg-card/30 border border-border/40 flex flex-col gap-1">
            <span className="text-[9px] font-black text-muted-foreground uppercase opacity-60">Total Events</span>
            <span className="text-2xl font-black text-foreground tabular-nums">{stats.total}</span>
          </div>
          <div className="glass-card rounded-2xl p-4 bg-card/30 border border-border/40 flex flex-col gap-1">
            <span className="text-[9px] font-black text-emerald-500 uppercase opacity-60">Success</span>
            <span className="text-2xl font-black text-emerald-500 tabular-nums">{stats.success}</span>
          </div>
          <div className="glass-card rounded-2xl p-4 bg-card/30 border border-border/40 flex flex-col gap-1">
            <span className="text-[9px] font-black text-destructive uppercase opacity-60">Failed</span>
            <span className="text-2xl font-black text-destructive tabular-nums">{stats.failed}</span>
          </div>
          <div className="glass-card rounded-2xl p-4 bg-card/30 border border-border/40 flex flex-col gap-1">
            <span className="text-[9px] font-black text-primary uppercase opacity-60">Distinct Users</span>
            <span className="text-2xl font-black text-primary tabular-nums">{stats.distinctUsers}</span>
          </div>
        </div>

        <div className="flex flex-col md:flex-row gap-4 mb-8 bg-card/40 p-3 rounded-2xl border border-border/40 backdrop-blur-md">
          <div className="relative flex-1 max-w-sm">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground/50" />
            <Input
              placeholder="Search audit entries..."
              className="pl-12 h-11 bg-background/40 border-none rounded-xl text-[14px] font-bold"
              value={globalFilter}
              onChange={e => setGlobalFilter(e.target.value)}
            />
          </div>

          <div className="flex items-center gap-3 ml-auto">
            <div className="flex items-center gap-2 bg-secondary/30 px-4 py-2 rounded-xl border border-border/20">
              <Calendar className="w-3.5 h-3.5 text-muted-foreground" />
              <input type="date" value={dateFrom} onChange={e => setDateFrom(e.target.value)} className="bg-transparent border-none text-[11px] font-black uppercase outline-none text-foreground/70" />
              <ArrowRight className="w-3 h-3 text-border" />
              <input type="date" value={dateTo} onChange={e => setDateTo(e.target.value)} className="bg-transparent border-none text-[11px] font-black uppercase outline-none text-foreground/70" />
            </div>
            <Button size="icon" variant="ghost" className="w-11 h-11 rounded-xl bg-secondary/50 border border-border/20"><Filter className="w-4 h-4" /></Button>
          </div>
        </div>

        <FadeIn delay={0.3} className="flex-1 min-h-0">
          <div className="glass-card rounded-3xl overflow-hidden shadow-2xl border border-border/40 flex flex-col h-full bg-card/10">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-[13px] border-collapse">
                <thead className="bg-secondary/80 backdrop-blur-xl border-b border-border/40">
                  <tr className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">
                    {table.getHeaderGroups()[0].headers.map(h => {
                      const sorted = h.column.getIsSorted()
                      return (
                        <th key={h.id} className="px-6 py-5 border-r border-border/10 last:border-r-0">
                          <button onClick={h.column.getToggleSortingHandler()} className="flex items-center gap-1 hover:text-foreground">
                            {flexRender(h.column.columnDef.header, h.getContext())}
                            {sorted === 'asc' ? <ChevronUp className="w-3 h-3" /> : sorted === 'desc' ? <ChevronDown className="w-3 h-3" /> : null}
                          </button>
                        </th>
                      )
                    })}
                  </tr>
                </thead>
                <tbody>
                  <AnimatePresence initial={false}>
                    {table.getRowModel().rows.map(row => (
                      <motion.tr
                        key={row.id}
                        layout="position"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="group border-b border-border/10 hover:bg-secondary/40 transition-all"
                      >
                        {row.getVisibleCells().map(cell => (
                          <td key={cell.id} className="px-6 py-4 border-r border-border/10 last:border-r-0">
                            {flexRender(cell.column.columnDef.cell, cell.getContext())}
                          </td>
                        ))}
                      </motion.tr>
                    ))}
                    {table.getRowModel().rows.length === 0 && (
                      <tr>
                        <td colSpan={6} className="px-6 py-16 text-center text-muted-foreground italic">No audit entries match your filters.</td>
                      </tr>
                    )}
                  </AnimatePresence>
                </tbody>
              </table>
            </div>

            <div className="bg-secondary/60 px-8 py-4 border-t border-border/40 flex items-center justify-between">
              <div className="flex items-center gap-4">
                <Database className="w-4 h-4 text-primary/60" />
                <span className="text-[11px] font-black uppercase tracking-widest text-muted-foreground">
                  Page {table.getState().pagination.pageIndex + 1} / {table.getPageCount() || 1} · {filteredByDate.length} entries
                </span>
              </div>

              <div className="flex items-center gap-2">
                <Button variant="ghost" size="icon" className="w-8 h-8" onClick={() => table.previousPage()} disabled={!table.getCanPreviousPage()}>
                  <ArrowRight className="w-4 h-4 rotate-180" />
                </Button>
                <Button variant="ghost" size="icon" className="w-8 h-8" onClick={() => table.nextPage()} disabled={!table.getCanNextPage()}>
                  <ArrowRight className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        </FadeIn>
      </div>
    </div>
  )
}
