'use client'

import React, { useMemo, useState } from 'react'
import { Users, Plus, Trash2, Shield, AlertCircle, Search } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card } from '@/components/ui/card'
import { cn } from '@/lib/utils'
import { useToast } from '@/hooks/use-toast'
import { recordAudit } from '@/lib/auditLog'
import { useConfirm } from '@/components/ui/confirm-dialog'
import { useAuth, AppUser, Role } from '@/components/providers/auth-provider'

const ROLES: Role[] = ['Administrator', 'Risk Manager', 'Assessor', 'Auditor', 'Viewer']

const ROLE_DESCRIPTIONS: Record<Role, string> = {
  Administrator: 'Full access — settings, RBAC, all CRUD.',
  'Risk Manager': 'Create / read / update / delete risks, controls, assessments.',
  Assessor: 'Create / read / update risks and assessments — no delete.',
  Auditor: 'Read-only access to all modules and audit trail.',
  Viewer: 'Read-only access to dashboards and reports.',
}

const ROLE_TONE: Record<Role, string> = {
  Administrator: 'bg-red-50 text-red-700 border-red-200',
  'Risk Manager': 'bg-blue-50 text-blue-700 border-blue-200',
  Assessor: 'bg-indigo-50 text-indigo-700 border-indigo-200',
  Auditor: 'bg-amber-50 text-amber-700 border-amber-200',
  Viewer: 'bg-emerald-50 text-emerald-700 border-emerald-200',
}

export function UserManagementPage() {
  const { users, setUsers, user: currentUser, hasPermission } = useAuth()
  const { toast } = useToast()
  const confirm = useConfirm()
  const [search, setSearch] = useState('')
  const [roleFilter, setRoleFilter] = useState<'All' | Role>('All')
  const [draft, setDraft] = useState<Omit<AppUser, 'id' | 'lastLogin'>>({ name: '', email: '', role: 'Viewer', department: 'Operations', active: true })

  const filtered = useMemo(() => users.filter(u => {
    if (roleFilter !== 'All' && u.role !== roleFilter) return false
    if (search && !`${u.name} ${u.email} ${u.department}`.toLowerCase().includes(search.toLowerCase())) return false
    return true
  }), [users, search, roleFilter])

  const stats = useMemo(() => ({
    total: users.length,
    active: users.filter(u => u.active).length,
    admins: users.filter(u => u.role === 'Administrator').length,
    roleCount: new Set(users.map(u => u.role)).size,
  }), [users])

  const addUser = () => {
    if (!hasPermission('admin')) { toast({ title: 'Insufficient permission', variant: 'destructive' }); return }
    if (!draft.name || !draft.email) { toast({ title: 'Name and email required', variant: 'destructive' }); return }
    const id = `U-${String(users.length + 1).padStart(3, '0')}`
    const created: AppUser = { ...draft, id }
    setUsers([...users, created])
    recordAudit({ action: 'CREATE', entity: 'User', entity_id: id, description: `Created ${created.role} ${created.name}`, after: created, result: 'SUCCESS' })
    toast({ title: 'User created' })
    setDraft({ name: '', email: '', role: 'Viewer', department: 'Operations', active: true })
  }

  const changeRole = (id: string, role: Role) => {
    const before = users.find(u => u.id === id)
    const next = users.map(u => u.id === id ? { ...u, role } : u)
    setUsers(next)
    if (before) recordAudit({ action: 'ROLE_CHANGE', entity: 'User', entity_id: id, description: `Changed role of ${before.name} from ${before.role} to ${role}`, before, after: { ...before, role }, result: 'SUCCESS' })
  }

  const toggleActive = (id: string) => {
    const before = users.find(u => u.id === id)
    const next = users.map(u => u.id === id ? { ...u, active: !u.active } : u)
    setUsers(next)
    if (before) recordAudit({ action: 'UPDATE', entity: 'User', entity_id: id, description: `${!before.active ? 'Activated' : 'Deactivated'} ${before.name}`, before, after: { ...before, active: !before.active }, result: 'SUCCESS' })
  }

  const removeUser = async (id: string) => {
    const target = users.find(u => u.id === id); if (!target) return
    if (target.id === currentUser?.id) { toast({ title: 'You cannot delete your own account', variant: 'destructive' }); return }
    const ok = await confirm({ title: `Remove ${target.name}?`, description: 'All access for this user will be revoked. This action cannot be undone.', confirmLabel: 'Remove user', tone: 'danger' })
    if (!ok) return
    setUsers(users.filter(u => u.id !== id))
    recordAudit({ action: 'DELETE', entity: 'User', entity_id: id, description: `Removed user ${target.name}`, before: target, result: 'SUCCESS' })
    toast({ title: 'User removed' })
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Users className="w-4 h-4 text-primary" />
            <span className="text-[10px] font-black uppercase tracking-[0.3em] text-primary">RBAC</span>
          </div>
          <h1 className="text-3xl font-black tracking-tight">User Management</h1>
          <p className="text-muted-foreground mt-2 font-medium">Role-based access control across the platform.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <StatCard label="Total users" value={stats.total} icon={Users} tone="blue" />
        <StatCard label="Active" value={stats.active} icon={Shield} tone="emerald" />
        <StatCard label="Administrators" value={stats.admins} icon={Shield} tone="red" />
        <StatCard label="Distinct roles" value={stats.roleCount} icon={Users} tone="amber" />
      </div>

      <Card className="p-5">
        <h3 className="text-[11px] font-black uppercase tracking-widest text-muted-foreground mb-3">Role permissions reference</h3>
        <div className="grid grid-cols-1 md:grid-cols-5 gap-2">
          {ROLES.map(r => (
            <div key={r} className={cn('p-3 rounded-xl border', ROLE_TONE[r])}>
              <p className="text-[11px] font-black uppercase tracking-widest">{r}</p>
              <p className="text-[10px] mt-1">{ROLE_DESCRIPTIONS[r]}</p>
            </div>
          ))}
        </div>
      </Card>

      {!hasPermission('admin') && (
        <div className="rounded-2xl border border-amber-200 bg-amber-50/60 p-4 flex items-center gap-3">
          <AlertCircle className="w-4 h-4 text-amber-600" />
          <p className="text-[12px] text-amber-700 font-bold">Read-only — only Administrators can modify users.</p>
        </div>
      )}

      <Card className="p-4">
        <div className="flex flex-col md:flex-row gap-3 items-stretch">
          <div className="relative md:max-w-sm w-full">
            <Search className="absolute left-3 top-2.5 w-4 h-4 text-muted-foreground" />
            <Input placeholder="Search users…" value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            {(['All', ...ROLES] as const).map(r => (
              <Button key={r} variant={roleFilter === r ? 'primary' : 'ghost'} size="sm" onClick={() => setRoleFilter(r as any)}>{r}</Button>
            ))}
          </div>
        </div>
      </Card>

      <Card className="overflow-hidden">
        <table className="w-full text-[13px]">
          <thead className="bg-secondary/40">
            <tr className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">
              <th className="px-4 py-3 text-left">ID</th>
              <th className="px-4 py-3 text-left">Name</th>
              <th className="px-4 py-3 text-left">Email</th>
              <th className="px-4 py-3 text-left">Role</th>
              <th className="px-4 py-3 text-left">Department</th>
              <th className="px-4 py-3 text-left">Status</th>
              <th className="px-4 py-3 text-left">Last login</th>
              <th className="px-4 py-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border/30">
            {filtered.map(u => (
              <tr key={u.id} className="hover:bg-secondary/20">
                <td className="px-4 py-3 font-mono text-[11px] text-muted-foreground">{u.id}</td>
                <td className="px-4 py-3 font-bold">{u.name}</td>
                <td className="px-4 py-3 text-muted-foreground">{u.email}</td>
                <td className="px-4 py-3">
                  <select value={u.role} disabled={!hasPermission('admin')} onChange={e => changeRole(u.id, e.target.value as Role)} className="h-8 px-2 rounded-lg border border-border/60 text-[11px] font-bold bg-white">
                    {ROLES.map(r => <option key={r}>{r}</option>)}
                  </select>
                </td>
                <td className="px-4 py-3 text-muted-foreground">{u.department}</td>
                <td className="px-4 py-3">
                  <button disabled={!hasPermission('admin')} onClick={() => toggleActive(u.id)} className={cn('px-2 py-0.5 rounded text-[9px] font-black uppercase tracking-widest border', u.active ? 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20' : 'bg-muted text-muted-foreground border-border')}>
                    {u.active ? 'Active' : 'Inactive'}
                  </button>
                </td>
                <td className="px-4 py-3 text-[11px] text-muted-foreground">{u.lastLogin ? new Date(u.lastLogin).toLocaleDateString() : '—'}</td>
                <td className="px-4 py-3 text-right">
                  <Button variant="ghost" size="icon" disabled={!hasPermission('admin') || u.id === currentUser?.id} onClick={() => removeUser(u.id)} className="text-red-500 hover:bg-red-50">
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>

      {hasPermission('admin') && (
        <Card className="p-6 space-y-4">
          <h3 className="text-[11px] font-black uppercase tracking-widest">Add user</h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
            <Input placeholder="Full name" value={draft.name} onChange={e => setDraft({ ...draft, name: e.target.value })} />
            <Input placeholder="Email" type="email" value={draft.email} onChange={e => setDraft({ ...draft, email: e.target.value })} />
            <select value={draft.role} onChange={e => setDraft({ ...draft, role: e.target.value as Role })} className="h-9 px-3 border border-border rounded-md text-sm">
              {ROLES.map(r => <option key={r}>{r}</option>)}
            </select>
            <Input placeholder="Department" value={draft.department} onChange={e => setDraft({ ...draft, department: e.target.value })} />
          </div>
          <Button onClick={addUser} className="rounded-xl"><Plus className="w-4 h-4 mr-2" />Add user</Button>
        </Card>
      )}
    </div>
  )
}

function StatCard({ label, value, icon: Icon, tone }: { label: string; value: number; icon: any; tone: 'blue' | 'emerald' | 'amber' | 'red' }) {
  const colorMap = { blue: 'text-blue-600 bg-blue-50', emerald: 'text-emerald-600 bg-emerald-50', amber: 'text-amber-600 bg-amber-50', red: 'text-red-600 bg-red-50' }[tone]
  return (
    <Card className="p-5 flex items-center gap-4">
      <div className={cn('w-12 h-12 rounded-2xl flex items-center justify-center', colorMap)}><Icon className="w-5 h-5" /></div>
      <div>
        <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">{label}</p>
        <p className="text-2xl font-black tabular-nums text-foreground">{value}</p>
      </div>
    </Card>
  )
}
