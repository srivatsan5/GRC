'use client'

import React from 'react'
import { useRouter } from 'next/navigation'
import { useQueries, useQuery } from '@tanstack/react-query'
import { 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  AreaChart,
  Area
} from 'recharts'
import { 
  Activity, 
  AlertTriangle, 
  TrendingUp, 
  Clock,
  ArrowUpRight,
  ChevronRight,
  ShieldCheck,
  Calendar
} from 'lucide-react'
import { motion } from 'framer-motion'
import { cn } from '@/lib/utils'
import { oracleService } from '@/lib/oracleService'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Skeleton } from '@/components/ui/skeleton'

export function Dashboard() {
  const router = useRouter()
  const results = useQueries({
    queries: [
      { queryKey: ['dashboard', 'summary'], queryFn: oracleService.getDashboardSummary },
      { queryKey: ['dashboard', 'risk-trend'], queryFn: oracleService.getRiskTrend },
      { queryKey: ['dashboard', 'risk-distribution'], queryFn: oracleService.getRiskDistribution },
      { queryKey: ['dashboard', 'risk-by-process'], queryFn: oracleService.getRiskByProcess },
    ],
  })

  const isLoading = results.some(r => r.isLoading)
  const summaryData = results[0].data || []
  const riskTrend = results[1].data || []
  const riskDistribution = results[2].data || []
  const riskByProcess = results[3].data || []

  const summary = summaryData?.[0] || {}

  // Fetch live risk records for the Activity Ledger
  const { data: liveRisks = [] } = useQuery({
    queryKey: ['dashboard', 'live-risks'],
    queryFn: () => oracleService.getIdentifyRisks(),
  })

  // Compute live KPI values from real data
  const totalRisks = summary.total_risks || liveRisks.length || 0
  const totalControls = summary.total_controls || 0
  const totalMonitoring = summary.total_monitoring || 0
  const completedRisks = summary.completed_risks || liveRisks.filter((r: any) => r.is_stage_complted === 'Y').length
  const overdueMonitoring = totalMonitoring > 0 ? Math.max(0, totalMonitoring - completedRisks) : 0
  const openCycles = totalRisks > 0 ? liveRisks.filter((r: any) => r.is_stage_complted !== 'Y').length : 0
  const controlEffRate = totalControls > 0 ? `${Math.round((totalControls / Math.max(totalRisks, 1)) * 100)}%` : '—'

  const stats = [
    { title: 'TOTAL PROJECT RISKS', value: totalRisks, trend: totalRisks > 0 ? `${totalRisks} active` : 'None', color: 'primary', icon: AlertTriangle },
    { title: 'CONTROL COVERAGE', value: controlEffRate, trend: totalControls > 0 ? `${totalControls} linked` : 'No controls', color: totalControls > 0 ? 'success' : 'destructive', icon: ShieldCheck },
    { title: 'MONITORING ACTIONS', value: totalMonitoring, trend: overdueMonitoring > 0 ? `${overdueMonitoring} pending` : 'On track', color: overdueMonitoring > 3 ? 'destructive' : 'primary', icon: Clock },
    { title: 'OPEN RCSA CYCLES', value: openCycles, trend: openCycles > 0 ? 'Active' : 'All closed', color: 'primary', icon: Activity },
  ]

  if (isLoading) {
    return (
      <div className="space-y-8 animate-pulse">
        <div className="flex justify-between items-end">
          <div className="space-y-3">
             <Skeleton className="h-4 w-24" />
             <Skeleton className="h-10 w-64" />
          </div>
          <Skeleton className="h-10 w-32" />
        </div>
        <div className="grid grid-cols-4 gap-6">
          {[1,2,3,4].map(i => <Skeleton key={i} className="h-32 rounded-2xl" />)}
        </div>
        <div className="grid grid-cols-12 gap-6">
          <Skeleton className="col-span-8 h-[400px] rounded-2xl" />
          <Skeleton className="col-span-4 h-[400px] rounded-2xl" />
        </div>
      </div>
    )
  }

  return (
    <div className="w-full max-w-full overflow-x-hidden space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-1000">
      {/* Hero Section */}
      <section className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[10px] font-display font-black uppercase tracking-[0.2em] text-muted-foreground/60">Executive Oversight</span>
            <div className="h-[1px] w-4 bg-muted-foreground/30" />
            <span className="text-[10px] font-display font-black uppercase tracking-[0.2em] text-primary">Live</span>
          </div>
          <h1 className="font-display font-black text-4xl text-foreground tracking-tight">Executive Dashboard</h1>
          <p className="text-muted-foreground mt-2 font-medium">Holistic risk intelligence and control performance metrics.</p>
        </div>
        <div className="flex items-center gap-3">
          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} className="flex items-center glass-card px-4 py-2.5 rounded-xl group cursor-pointer hover:bg-blue-50/50 transition-all">
            <Calendar className="w-4 h-4 text-blue-500 mr-2" />
            <span className="text-xs font-bold text-blue-600">Q1 2026 Cycle</span>
            <ChevronRight className="w-3 h-3 text-blue-400 ml-2 rotate-90" />
          </motion.div>
          <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
            <Button variant="primary" onClick={() => router.push('/risk-assessments/dashboard')} className="h-[42px] px-6 shadow-sm bg-blue-600 hover:bg-blue-700 text-white border-0">
              <ArrowUpRight className="w-4 h-4 mr-2" />
              Intelligence Report
            </Button>
          </motion.div>
        </div>
      </section>

      {/* KPI Grid */}
      <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, i) => {
          const links = ['/risk-identification', '/assessments/controls', '/monitoring', '/rcsa']
          return (
          <Card key={i} onClick={() => router.push(links[i] || '/')} className={cn(
            "p-6 h-36 flex flex-col justify-between group glass-card relative overflow-hidden cursor-pointer hover:border-primary/50 transition-colors",
            stat.color === 'destructive' && "bg-red-50/30 border-red-100 shadow-red-500/5"
          )}>
            <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:scale-110 transition-transform">
               <stat.icon className="w-16 h-16" />
            </div>
            <div className="flex justify-between items-start relative z-10">
              <span className="text-[9px] font-display font-black text-muted-foreground/60 tracking-[0.15em] uppercase">{stat.title}</span>
              <Badge variant={stat.color as any} className="font-black text-[8px] tracking-widest px-2">{stat.trend}</Badge>
            </div>
            <div className="flex flex-col gap-1 relative z-10">
              <span className="font-display font-black text-4xl text-foreground animate-in slide-in-from-left-2 duration-500">{stat.value}</span>
              <div className="flex items-center gap-1.5 opacity-60">
                 <div className={cn("w-1.5 h-1.5 rounded-full", stat.color === 'success' ? 'bg-emerald-500' : stat.color === 'destructive' ? 'bg-red-500' : 'bg-primary')} />
                 <span className="text-[10px] font-bold text-muted-foreground uppercase">{stat.color === 'destructive' ? 'SLA Compromised' : 'Optimal Path'}</span>
              </div>
            </div>
          </Card>
          )
        })}
      </section>

      {/* Analytics Bento */}
      <section className="grid grid-cols-12 gap-8">
        {/* Risk Trend Chart */}
        <Card className="col-span-12 lg:col-span-8 p-8 flex flex-col border-none shadow-2xl shadow-blue-500/5 glass">
          <div className="flex items-center justify-between mb-10">
            <div>
              <CardTitle className="text-2xl font-black tracking-tight">Risk Trend</CardTitle>
              <CardDescription className="font-medium">Aggregated risk fluctuation over trailing 6 months.</CardDescription>
            </div>
            <div className="flex gap-2 bg-accent/30 p-1.5 rounded-xl border border-outline-variant/30">
              <button className="text-[10px] font-black px-4 py-2 rounded-lg bg-white shadow-sm text-primary transition-all">6 MONTHS</button>
              <button className="text-[10px] font-black px-4 py-2 rounded-lg text-muted-foreground hover:text-foreground transition-all">1 YEAR</button>
            </div>
          </div>
          <div className="h-[320px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={riskTrend}>
                <defs>
                  <linearGradient id="indigoGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="var(--primary)" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="var(--primary)" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--outline-variant)" opacity={0.3} />
                <XAxis dataKey="risk_date" axisLine={false} tickLine={false} style={{ fontSize: '10px', fontWeight: 900 }} stroke="var(--muted-foreground)" />
                <YAxis axisLine={false} tickLine={false} style={{ fontSize: '10px', fontWeight: 900 }} stroke="var(--muted-foreground)" />
                <Tooltip 
                  contentStyle={{ backgroundColor: 'var(--card)', border: '1px solid var(--outline-variant)', borderRadius: '16px', fontSize: '11px', boxShadow: '0 20px 40px rgba(0,0,0,0.1)' }}
                  itemStyle={{ fontWeight: 900, color: 'var(--primary)', textTransform: 'uppercase' }}
                />
                <Area 
                  type="monotone" 
                  dataKey="total_risks" 
                  stroke="var(--primary)" 
                  strokeWidth={4} 
                  fillOpacity={1} 
                  fill="url(#indigoGradient)" 
                  animationDuration={2500}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <div className="col-span-12 lg:col-span-4 flex flex-col gap-8">
          <div className="bg-blue-600 border-none p-7 rounded-[2.5rem] flex-grow group relative overflow-hidden shadow-md">
            <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16 transition-transform group-hover:scale-110 duration-500" />
            <div className="flex items-center justify-between mb-8 relative z-10">
              <h3 className="font-display font-black text-xs text-white/40 tracking-[0.2em] flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-orange-500 shrink-0" />
                SECURITY PULSE
              </h3>
              <Badge variant="destructive" className="bg-white text-blue-600 border-none font-black text-[8px]">Critical</Badge>
            </div>
            <div className="space-y-6 relative z-10">
              {[
                { title: 'Identity Leak detected', desc: 'EMEA HR node compromised.', time: '12m ago' },
                { title: 'Control Gap in IT', desc: 'ISO 27001 evidence overdue.', time: '2h ago' }
              ].map((alert, i) => (
                <div key={i} className="group/item cursor-pointer border-l-2 border-white/10 hover:border-primary pl-4 transition-all">
                  <p className="text-[13px] font-black text-white group-hover/item:text-primary transition-colors">{alert.title}</p>
                  <p className="text-[11px] text-white/40 font-medium mt-0.5">{alert.desc}</p>
                  <div className="flex items-center justify-between mt-3">
                    <span className="text-[9px] font-black text-white/20 uppercase tracking-widest">{alert.time}</span>
                    <button onClick={() => router.push('/monitoring')} className="text-[10px] font-black text-white/60 hover:text-white flex items-center gap-1 group/btn">
                      Respond <ArrowUpRight className="w-3 h-3 group-hover/btn:translate-x-1" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <Card className="p-7 border-none shadow-2xl shadow-blue-500/5 glass">
             <div className="flex items-center justify-between mb-8">
                <CardTitle className="text-xs font-black uppercase tracking-widest text-muted-foreground/60 leading-none">Risk Distribution</CardTitle>
                <div className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]" />
             </div>
            <div className="space-y-6">
              {riskByProcess.slice(0, 3).map((p: any, i: number) => (
                <div key={i} className="space-y-2.5">
                  <div className="flex justify-between items-end text-[10px] font-black uppercase tracking-tight">
                    <span className="text-muted-foreground/80">{p.process}</span>
                    <span className="text-foreground">{p.count}%</span>
                  </div>
                  <div className="h-1.5 w-full bg-accent/40 rounded-full overflow-hidden">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: `${p.count}%` }}
                      transition={{ duration: 1, delay: 0.1, ease: "circOut" }}
                      className="h-full bg-blue-600 rounded-full" 
                    />
                  </div>
                </div>
              ))}
            </div>
            <Button onClick={() => router.push('/risk-assessments/dashboard')} variant="ghost" className="w-full mt-8 h-10 text-[10px] font-black uppercase tracking-widest text-primary/60 hover:text-primary hover:bg-primary/5">
              Deep Analytics
              <ChevronRight className="w-3.5 h-3.5 ml-2" />
            </Button>
          </Card>
        </div>
      </section>

      {/* Recent Activity Ledger */}
      <Card className="overflow-hidden border-none shadow-2xl shadow-blue-500/5 glass">
        <CardHeader className="flex flex-row items-center justify-between p-8 border-b border-outline-variant/30">
          <div>
            <CardTitle className="text-2xl font-black tracking-tight leading-none">Recent Risk Activity</CardTitle>
            <CardDescription className="text-[13px] font-medium mt-2">Latest RCSA assessment modifications across the organization.</CardDescription>
          </div>
          <div className="flex gap-3">
             <Button variant="outline" size="sm" className="h-10 px-6 font-black text-[10px] uppercase tracking-widest rounded-xl">
               Export CSV
             </Button>
             <Button variant="secondary" size="sm" className="h-10 px-6 font-black text-[10px] uppercase tracking-widest rounded-xl">
               Audit Trails
             </Button>
          </div>
        </CardHeader>
        <Table>
          <TableHeader>
            <TableRow className="hover:bg-transparent bg-accent/10">
              <TableHead className="px-8 h-14 text-[10px] font-black uppercase tracking-[0.15em]">Institutional Entity</TableHead>
              <TableHead className="h-14 text-[10px] font-black uppercase tracking-[0.15em]">Assessor</TableHead>
              <TableHead className="h-14 text-[10px] font-black uppercase tracking-[0.15em]">Lifecycle Status</TableHead>
              <TableHead className="h-14 text-[10px] font-black uppercase tracking-[0.15em]">Performance</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {(liveRisks.length > 0 ? liveRisks : []).slice(0, 8).map((row: any, i: number) => {
              const isCompleted = row.is_stage_complted === 'Y'
              const progress = isCompleted ? 100 : row.start_date ? 40 : 10
              const displayName = row.risk_statement || row.process_name || row.risk_type || `Risk ${row.uuid}`
              const processName = row.process_name || row.sub_process_name || 'Corporate'
              const statusLabel = isCompleted ? 'Validated' : row.start_date ? 'Active Cycle' : 'Pending'
              return (
              <TableRow key={row.uuid || i} className="group hover:bg-blue-50/50 transition-all duration-300">
                <TableCell className="px-8 py-5">
                   <div className="flex items-center gap-4">
                     <div className="w-10 h-10 rounded-xl bg-primary/5 flex items-center justify-center text-primary group-hover:scale-110 transition-transform">
                        <Activity className="w-5 h-5" />
                     </div>
                     <div>
                       <p className="font-black text-blue-900 leading-tight">{displayName}</p>
                       <p className="text-[10px] font-black text-muted-foreground/40 mt-0.5 uppercase tracking-widest">UUID-{String(row.uuid || '').slice(0, 6)}</p>
                     </div>
                   </div>
                </TableCell>
                <TableCell className="text-blue-600 font-bold text-[13px]">
                   <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-full bg-blue-50 flex items-center justify-center text-[9px] font-black text-blue-400">
                        {processName[0]}
                      </div>
                      {processName}
                   </div>
                </TableCell>
                <TableCell>
                  <Badge variant={statusLabel === 'Validated' ? 'success' : statusLabel === 'Pending' ? 'warning' : 'default'} className="font-black text-[9px] tracking-widest px-3">
                    {statusLabel}
                  </Badge>
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-4">
                    <div className="h-1.5 w-32 bg-accent/40 rounded-full overflow-hidden shadow-inner">
                      <div className={cn(
                        "h-full transition-all duration-1000 shadow-[0_0_8px_currentColor]",
                        progress === 100 ? "bg-emerald-500 text-emerald-500" : "bg-primary text-primary"
                      )} style={{ width: `${progress}%` }} />
                    </div>
                    <span className="text-[10px] font-black text-blue-500 tabular-nums">{progress}%</span>
                  </div>
                </TableCell>
                <TableCell className="px-8 text-right">
                   <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
                     <Button onClick={() => router.push(`/risk-identification?riskId=${row.uuid || row.id}`)} variant="ghost" size="icon" className="h-10 w-10 text-muted-foreground hover:text-primary hover:bg-primary/5 transition-all">
                        <ChevronRight className="w-5 h-5" />
                     </Button>
                   </motion.div>
                </TableCell>
              </TableRow>
              )
            })}
            {liveRisks.length === 0 && (
              <TableRow>
                <TableCell colSpan={5} className="px-8 py-12 text-center text-muted-foreground italic">
                  No risk records found. Create your first risk in RCSA Provisioning.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </Card>
    </div>
  )
}
