import express from "express";
import axios from "axios";
import cors from "cors";

const app = express();
app.use(cors());
app.use(express.json());

const BASE_URL = "https://ga8231f10084da5-pericopeai.adb.us-chicago-1.oraclecloudapps.com/ords/grc/risk";

// helper
const callAPI = async (method, url, data = {}) => {
  try {
    const res = await axios({
      method,
      url: `${BASE_URL}${url}`,
      data,
      headers: {
        "Content-Type": "application/json"
      }
    });
    return res.data;
  } catch (err) {
    throw err.response?.data || err.message;
  }
};

//////////////////////////////////////////////////////////
// GENERIC ROUTE CREATOR
//////////////////////////////////////////////////////////

const createRoutes = (route) => {
  // GET all
  app.get(`/${route}`, async (req, res) => {
    try {
      const data = await callAPI("get", `/${route}/`);
      res.json(data);
    } catch (err) {
      res.status(500).json(err);
    }
  });

  // GET by ID
  app.get(`/${route}/:id`, async (req, res) => {
    try {
      const data = await callAPI("get", `/${route}/${req.params.id}`);
      res.json(data);
    } catch (err) {
      res.status(500).json(err);
    }
  });

  // POST
  app.post(`/${route}`, async (req, res) => {
    try {
      const data = await callAPI("post", `/${route}/`, req.body);
      res.json(data);
    } catch (err) {
      res.status(500).json(err);
    }
  });

  // PUT
  app.put(`/${route}/:id`, async (req, res) => {
    try {
      const data = await callAPI("put", `/${route}/${req.params.id}`, req.body);
      res.json(data);
    } catch (err) {
      res.status(500).json(err);
    }
  });

  // DELETE
  app.delete(`/${route}/:id`, async (req, res) => {
    try {
      const data = await callAPI("delete", `/${route}/${req.params.id}`);
      res.json(data);
    } catch (err) {
      res.status(500).json(err);
    }
  });
};

//////////////////////////////////////////////////////////
// REGISTER YOUR 6 TABLES
//////////////////////////////////////////////////////////

const routes = [
  "per_trn_identify_risk",
  "per_trn_risk_monitoring",
  "per_trn_control_implementation",
  "per_mst_business_process",
  "per_mst_control_type",
  "per_mst_risk_category"
];

routes.forEach(createRoutes);

//////////////////////////////////////////////////////////
// HEALTH CHECK
//////////////////////////////////////////////////////////

app.get("/", (req, res) => {
  res.send("API Running 🚀");
});

//////////////////////////////////////////////////////////
// START SERVER
//////////////////////////////////////////////////////////

const PORT = 5000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
