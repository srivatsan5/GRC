'use client'

import * as React from 'react'
import Link from 'next/link'
import { Bell, Search, ChevronRight, Menu, ChevronLeft, X, AlertTriangle, Activity, Shield } from 'lucide-react'
import { cn } from '@/lib/utils'
import { Button } from './ui/button'
import { Input } from './ui/input'
import { usePathname, useRouter } from 'next/navigation'
import { motion, AnimatePresence } from 'framer-motion'
import { useSidebar } from './pericope-layout'
import { useAuth } from './providers/auth-provider'

const QUICK_LINKS: Array<{ label: string; href: string; icon: any; keywords: string[] }> = [
  { label: 'Dashboard', href: '/dashboard', icon: Activity, keywords: ['dashboard', 'home', 'cockpit'] },
  { label: 'RCSA Hub', href: '/rcsa', icon: Shield, keywords: ['rcsa', 'assessment'] },
  { label: 'Assessment Setup', href: '/rcsa/provisioning', icon: Shield, keywords: ['provisioning', 'setup', 'new', 'create'] },
  { label: 'Risk Identification', href: '/rcsa/identification', icon: Shield, keywords: ['identification', 'identify'] },
  { label: 'Risk Mitigation', href: '/rcsa/mitigation', icon: Shield, keywords: ['mitigation', 'controls'] },
  { label: 'Risk Monitoring', href: '/rcsa/monitoring', icon: Shield, keywords: ['monitoring'] },
  { label: 'Inherent Analysis', href: '/assessments/inherent', icon: Shield, keywords: ['inherent', 'analysis'] },
  { label: 'Residual Mapping', href: '/assessments/residual', icon: Shield, keywords: ['residual', 'heatmap'] },
  { label: 'Risk Heatmaps', href: '/heatmaps', icon: Shield, keywords: ['heatmaps', 'heatmap', 'matrix'] },
  { label: 'KRI Intelligence', href: '/kri', icon: Activity, keywords: ['kri', 'indicator', 'threshold'] },
  { label: 'Control Library', href: '/control-library', icon: Shield, keywords: ['control', 'library'] },
  { label: 'Risk Appetite', href: '/risk-appetite', icon: Shield, keywords: ['appetite', 'tolerance'] },
  { label: 'Workflow & Approvals', href: '/workflow', icon: Shield, keywords: ['workflow', 'approval'] },
  { label: 'Vendor Risk (TPRM)', href: '/vendor-risk', icon: Shield, keywords: ['vendor', 'tprm', 'third-party'] },
  { label: 'Incident Management', href: '/incidents', icon: AlertTriangle, keywords: ['incident'] },
  { label: 'Business Continuity', href: '/bcp', icon: Shield, keywords: ['bcp', 'continuity'] },
  { label: 'Scenario Analysis', href: '/scenario', icon: Shield, keywords: ['scenario', 'stress'] },
  { label: 'Policy Management', href: '/policy', icon: Shield, keywords: ['policy'] },
  { label: 'Audit Trail', href: '/audit-trail', icon: Shield, keywords: ['audit', 'trail', 'log'] },
  { label: 'User Management', href: '/users', icon: Shield, keywords: ['users', 'rbac', 'roles'] },
  { label: 'Risk Reports', href: '/reports', icon: Shield, keywords: ['reports', 'analytics'] },
  { label: 'Settings', href: '/settings', icon: Shield, keywords: ['settings', 'configuration'] },
]

const NOTIFICATIONS = [
  { id: 'n-1', title: 'Inherent assessment overdue', body: 'RCSA-F-202604-322 has not been finalized.', time: '12 min ago', tone: 'warning' as const },
  { id: 'n-2', title: 'New KRI breach', body: 'IT Outage Hours exceeded amber threshold.', time: '1 hr ago', tone: 'critical' as const },
  { id: 'n-3', title: 'Vendor review due', body: 'Quarterly review for Vendor-V0042 starts Monday.', time: '3 hr ago', tone: 'info' as const },
  { id: 'n-4', title: 'Policy acknowledged', body: 'IT Security Policy v3.2 acknowledged by 92% of staff.', time: 'Yesterday', tone: 'info' as const },
]

export function PericopeNavbar() {
  const pathname = usePathname()
  const router = useRouter()
  const { toggle } = useSidebar()
  const { user } = useAuth()

  const [searchOpen, setSearchOpen] = React.useState(false)
  const [searchQuery, setSearchQuery] = React.useState('')
  const [notificationsOpen, setNotificationsOpen] = React.useState(false)
  const searchRef = React.useRef<HTMLDivElement>(null)
  const notifRef = React.useRef<HTMLDivElement>(null)

  React.useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault()
        setSearchOpen(o => !o)
      }
      if (e.key === 'Escape') {
        setSearchOpen(false)
        setNotificationsOpen(false)
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [])

  React.useEffect(() => {
    const onClick = (e: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(e.target as Node)) setSearchOpen(false)
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) setNotificationsOpen(false)
    }
    document.addEventListener('mousedown', onClick)
    return () => document.removeEventListener('mousedown', onClick)
  }, [])

  const segments = pathname.split('/').filter(Boolean)
  const breadcrumbs = segments.map((s, i) => ({
    name: s.charAt(0).toUpperCase() + s.slice(1).replace(/-/g, ' '),
    href: '/' + segments.slice(0, i + 1).join('/')
  }))

  const filteredQuickLinks = React.useMemo(() => {
    const q = searchQuery.trim().toLowerCase()
    if (!q) return QUICK_LINKS.slice(0, 8)
    return QUICK_LINKS.filter(link => {
      return link.label.toLowerCase().includes(q) || link.keywords.some(k => k.includes(q))
    }).slice(0, 12)
  }, [searchQuery])

  const initials = (user?.name || 'U S').split(' ').map(p => p[0]).slice(0, 2).join('').toUpperCase()

  return (
    <header className="fixed top-0 right-0 left-0 h-16 z-40 flex items-center justify-between px-8 bg-white/80 backdrop-blur-md border-b border-blue-100 transition-all duration-500">
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-1.5 mr-2">
          <Button
            variant="ghost"
            size="icon"
            onClick={toggle}
            className="text-blue-500 hover:bg-blue-50 rounded-xl transition-all"
          >
            <Menu className="w-5 h-5" />
          </Button>

          <div className="flex items-center gap-1 ml-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => router.back()}
              className="w-8 h-8 text-blue-400 hover:text-blue-600 hover:bg-blue-50/50 rounded-lg transition-all"
            >
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => router.forward()}
              className="w-8 h-8 text-blue-400 hover:text-blue-600 hover:bg-blue-50/50 rounded-lg transition-all"
            >
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        </div>

        <nav className="flex items-center gap-2 text-[10px] font-display font-black tracking-widest uppercase text-blue-400">
          <Link href="/">
            <motion.span
              initial={{ color: '#60a5fa' }}
              whileHover={{ color: '#2563eb' }}
              className="cursor-pointer transition-colors"
            >
              Pericope ERM
            </motion.span>
          </Link>
          {breadcrumbs.length > 0 && <ChevronRight className="w-3 h-3 opacity-30" />}
          {breadcrumbs.map((bc, i) => (
            <React.Fragment key={bc.href}>
              <span className={cn(
                'transition-all duration-300',
                i === breadcrumbs.length - 1 ? 'text-primary font-black scale-105' : 'hover:text-blue-600 cursor-pointer'
              )}>
                {bc.name}
              </span>
              {i < breadcrumbs.length - 1 && <ChevronRight className="w-3 h-3 opacity-30" />}
            </React.Fragment>
          ))}
        </nav>
      </div>

      <div className="flex items-center gap-6">
        {/* Global Search */}
        <div className="relative hidden md:block" ref={searchRef}>
          <div
            onClick={() => setSearchOpen(true)}
            className="flex items-center bg-blue-50/50 border border-blue-100/50 rounded-full px-4 py-1.5 w-72 cursor-text hover:bg-white transition-all"
          >
            <Search className="w-3.5 h-3.5 text-blue-400" />
            <span className="text-xs ml-2 flex-1 text-blue-300 font-medium">Search modules, risks, reports…</span>
            <div className="flex items-center gap-1 opacity-50">
              <span className="text-[9px] font-black text-blue-400 bg-blue-50 px-1.5 py-0.5 rounded border border-blue-200">Ctrl</span>
              <span className="text-[9px] font-black text-blue-400 bg-blue-50 px-1.5 py-0.5 rounded border border-blue-200">K</span>
            </div>
          </div>

          <AnimatePresence>
            {searchOpen && (
              <motion.div
                initial={{ opacity: 0, y: -8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                className="absolute right-0 mt-2 w-[380px] bg-white rounded-2xl shadow-2xl border border-blue-100 overflow-hidden z-50"
              >
                <div className="p-3 border-b border-blue-50">
                  <Input
                    autoFocus
                    placeholder="Search modules, pages, settings..."
                    value={searchQuery}
                    onChange={e => setSearchQuery(e.target.value)}
                    className="h-9 text-sm"
                  />
                </div>
                <div className="max-h-[320px] overflow-y-auto py-1">
                  {filteredQuickLinks.length === 0 && (
                    <div className="px-4 py-6 text-center text-[12px] text-muted-foreground italic">No matches found</div>
                  )}
                  {filteredQuickLinks.map(link => (
                    <button
                      key={link.href}
                      onClick={() => { router.push(link.href); setSearchOpen(false); setSearchQuery('') }}
                      className="w-full flex items-center gap-3 px-4 py-2 hover:bg-blue-50/60 text-left"
                    >
                      <div className="w-7 h-7 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
                        <link.icon className="w-3.5 h-3.5" />
                      </div>
                      <span className="text-[13px] font-bold text-blue-900">{link.label}</span>
                      <span className="ml-auto text-[9px] text-blue-300 uppercase tracking-widest">{link.href}</span>
                    </button>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <div className="flex items-center gap-3">
          {/* Notifications */}
          <div className="relative" ref={notifRef}>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setNotificationsOpen(o => !o)}
              className="group relative text-blue-400 hover:text-primary hover:bg-blue-50/50 rounded-xl transition-all"
            >
              <Bell className="w-4 h-4" />
              <span className="absolute top-2.5 right-2.5 w-1.5 h-1.5 bg-blue-500 rounded-full ring-2 ring-white animate-pulse" />
            </Button>

            <AnimatePresence>
              {notificationsOpen && (
                <motion.div
                  initial={{ opacity: 0, y: -8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  className="absolute right-0 mt-2 w-[360px] bg-white rounded-2xl shadow-2xl border border-blue-100 overflow-hidden z-50"
                >
                  <div className="flex items-center justify-between px-4 py-3 border-b border-blue-50">
                    <h3 className="text-[11px] font-black uppercase tracking-widest text-blue-900">Notifications</h3>
                    <button onClick={() => setNotificationsOpen(false)} className="text-blue-300 hover:text-blue-600">
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="max-h-[400px] overflow-y-auto divide-y divide-blue-50">
                    {NOTIFICATIONS.map(n => (
                      <div key={n.id} className="px-4 py-3 hover:bg-blue-50/40 flex gap-3">
                        <div className={cn(
                          'w-2 h-2 rounded-full mt-2 flex-shrink-0',
                          n.tone === 'critical' ? 'bg-red-500' : n.tone === 'warning' ? 'bg-amber-500' : 'bg-blue-500'
                        )} />
                        <div className="flex-1">
                          <p className="text-[12px] font-black text-blue-900">{n.title}</p>
                          <p className="text-[11px] text-blue-500 mt-0.5">{n.body}</p>
                          <p className="text-[9px] text-blue-300 uppercase tracking-widest mt-1.5">{n.time}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="px-4 py-3 bg-blue-50/40">
                    <button
                      onClick={() => { router.push('/audit-trail'); setNotificationsOpen(false) }}
                      className="w-full text-[10px] font-black uppercase tracking-widest text-blue-600 hover:text-blue-800"
                    >
                      View all in audit trail →
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <div className="h-6 w-px bg-blue-100/50" />

          <Button
            variant="ghost"
            onClick={() => router.push('/users')}
            className="pl-3 pr-2 py-1 gap-3 rounded-xl hover:bg-white hover:shadow-2xl hover:shadow-blue-500/5 border border-transparent hover:border-blue-100/50 transition-all duration-500 group"
          >
            <div className="flex flex-col items-end mr-1">
              <span className="text-[10px] font-black uppercase tracking-tighter text-blue-800">{user?.name || 'User'}</span>
              <span className="text-[8px] font-bold text-blue-500/60 uppercase tracking-widest">{user?.role || 'Viewer'}</span>
            </div>
            <div className="w-8 h-8 rounded-lg bg-blue-600 text-white flex items-center justify-center text-[10px] font-black shadow-sm group-hover:scale-105 transition-transform duration-500">
              {initials}
            </div>
          </Button>
        </div>
      </div>
    </header>
  )
}
