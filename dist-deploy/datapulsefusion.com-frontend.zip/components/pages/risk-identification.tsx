'use client'

import React, { useMemo, useState } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import {
  useReactTable,
  getCoreRowModel,
  getSortedRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  flexRender,
  createColumnHelper,
} from '@tanstack/react-table'
import { 
  Plus, 
  Search, 
  MoreVertical, 
  ChevronUp, 
  ChevronDown, 
  ChevronsUpDown, 
  Loader2, 
  AlertCircle,
  Shield,
  ArrowLeft,
  Filter,
  CheckCircle2,
  Inbox,
  Trash2
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogTrigger,
} from "@/components/ui/dialog"
import { motion, AnimatePresence } from 'framer-motion'
import { FadeIn, StaggerContainer, StaggerItem } from '@/components/ui/fade-in'
import { oracleService } from '@/lib/oracleService'
import { cn } from '@/lib/utils'
import { toast } from 'sonner'

export function RiskIdentificationPage({ assessmentId: propAssessmentId }: { assessmentId?: string }) {
  const router = useRouter()
  const searchParams = useSearchParams()
  const queryClient = useQueryClient()
  const assessmentId = propAssessmentId || searchParams.get('assessmentId')
  const [globalFilter, setGlobalFilter] = React.useState('')
  const [isAddRiskOpen, setIsAddRiskOpen] = React.useState(false)
  const [selectedRiskId, setSelectedRiskId] = React.useState('')
  const [inherentLikelihood, setInherentLikelihood] = React.useState('3')
  const [inherentImpact, setInherentImpact] = React.useState('3')
  const [justification, setJustification] = React.useState('')
  const [riskOwner, setRiskOwner] = React.useState('Subha')

  // 1. Data Fetching
  const { data: risks = [], isLoading, isError, error, refetch } = useQuery({
    queryKey: ['risks', assessmentId],
    queryFn: () => oracleService.getIdentifyRisks(),
  })

  const { data: masterRisks = [] } = useQuery({
     queryKey: ['master-risks'],
     queryFn: () => oracleService.getIdentifyRisks(),
     enabled: !!assessmentId
  })

  // 2. Mutations
  const createMutation = useMutation({
    mutationFn: (data: any) => oracleService.createIdentifyRisk(data),
    onSuccess: () => {
      toast.success("Risk cataloged successfully into database")
      setIsAddRiskOpen(false)
      setSelectedRiskId('')
      setInherentLikelihood('3')
      setInherentImpact('3')
      setJustification('')
      queryClient.invalidateQueries({ queryKey: ['risks'] })
      refetch()
      router.push('/rcsa/provisioning')
    },
    onError: (err: any) => {
      toast.error(`Persistence failed: ${err.message}`)
    }
  })

  const deleteMutation = useMutation({
    mutationFn: (id: string | number) => oracleService.deleteIdentifyRisk(id),
    onSuccess: () => {
      toast.success("Risk deleted successfully from catalog")
      queryClient.invalidateQueries({ queryKey: ['risks'] })
      refetch()
    },
    onError: (err: any) => {
      toast.error(`Failed to delete risk: ${err.message}`)
    }
  })

  const handleSaveRisk = () => {
    if (!selectedRiskId) {
      toast.error("Please select a risk from the library")
      return
    }

    const likelihood = Number(inherentLikelihood) || 3
    const impact = Number(inherentImpact) || 3

    const payload = {
      risk_statement: masterRisks.find((r: any) => String(r.uuid) === String(selectedRiskId))?.risk_statement || `Risk ${selectedRiskId}`,
      risk_type: 'General Risk',
      inherent_sle: likelihood * impact * 10000,
      risk_owner: riskOwner,
      is_stage_complted: 'N',
      approval_status: 'DRAFT',
      status: 'N',
    }

    createMutation.mutate(payload)
  }

  // 3. Column Definitions
  const columnHelper = createColumnHelper<any>()
  
  const columns = useMemo(() => [
    columnHelper.accessor('uuid', {
      header: 'Fiducial ID',
      cell: info => <span className="font-mono text-[10px] font-black text-primary/50 uppercase tracking-tighter">{(String(info.getValue() || info.row.original.id || '').slice(0, 8))}</span>,
    }),
    columnHelper.accessor('risk_statement', {
      header: ({ column }) => (
        <button className="flex items-center gap-1.5 hover:text-foreground transition-colors group" onClick={() => column.toggleSorting(column.getIsSorted() === 'asc')}>
          Risk Statement {column.getIsSorted() === 'asc' ? <ChevronUp className="w-3 h-3 text-primary"/> : column.getIsSorted() === 'desc' ? <ChevronDown className="w-3 h-3 text-primary"/> : <ChevronsUpDown className="w-3 h-3 opacity-20 group-hover:opacity-100 transition-opacity"/>}
        </button>
      ),
      cell: info => (
        <div className="flex flex-col">
          <span className="font-black text-foreground uppercase italic tracking-tight">{info.getValue() || info.row.original.process_name || 'N/A'}</span>
          <span className="text-[9px] font-black text-muted-foreground/40 uppercase tracking-widest mt-0.5">{info.row.original.risk_type || 'General'}</span>
        </div>
      ),
    }),
    columnHelper.accessor('assessor', {
      header: 'Ownership',
      cell: info => <span className="text-[11px] font-black uppercase text-muted-foreground italic tracking-widest">{info.row.original.process_name || 'Unassigned'}</span>,
    }),
    columnHelper.accessor('inherent_sle', {
      header: 'Exposure (SLE)',
      cell: info => {
        const value = info.getValue() || 0
        const label = value > 50000 ? 'Critical' : value > 10000 ? 'Significant' : 'Moderate'
        return (
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-black">${Number(value).toLocaleString()}</span>
            <span className={cn(
              "text-[8px] px-1.5 py-0.5 rounded font-black uppercase tracking-tighter shadow-sm",
              value > 50000 ? "bg-red-500/10 text-red-500 border border-red-500/20" : 
              value > 10000 ? "bg-amber-500/10 text-amber-500 border border-amber-500/20" : 
              "bg-emerald-500/10 text-emerald-500 border border-emerald-500/20"
            )}>
              {label}
            </span>
          </div>
        )
      },
    }),
    columnHelper.display({
      id: 'actions',
      cell: ({ row }) => (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
             <Button variant="ghost" size="icon" className="h-8 w-8 hover:bg-secondary rounded-lg">
               <MoreVertical className="w-4 h-4 text-muted-foreground/60" />
             </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-48 bg-card border-border shadow-lg rounded-xl">
            <DropdownMenuItem onClick={() => router.push(`/risk-assessments/dashboard?riskId=${row.original.uuid || row.original.id}`)} className="text-[11px] font-bold hover:bg-secondary cursor-pointer uppercase tracking-wider text-muted-foreground">
              Assess Risk
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => router.push(`/monitoring?riskId=${row.original.uuid || row.original.id}`)} className="text-[11px] font-bold hover:bg-secondary cursor-pointer uppercase tracking-wider text-muted-foreground">
              Monitor Risk
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => router.push(`/rcsa/provisioning/${assessmentId || 'new'}/controls/${row.original.uuid || row.original.id}`)} className="text-[11px] font-bold hover:bg-secondary cursor-pointer uppercase tracking-wider text-primary">
              Applied Controls
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => {
                const id = row.original.uuid || row.original.id || row.original.identify_risk_uuid;
                if(confirm("Confirm destructive teardown of this risk node?")) {
                  deleteMutation.mutate(id);
                }
              }} 
              disabled={deleteMutation.isPending}
              className="text-[11px] font-black hover:bg-destructive/10 cursor-pointer uppercase tracking-wider text-destructive focus:bg-destructive/20"
            >
              <Trash2 className="w-3.5 h-3.5 mr-2" />
              Destruct Node
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      ),
    }),
  ], [router, assessmentId, deleteMutation.isPending])

  const table = useReactTable({
    data: risks,
    columns,
    state: { globalFilter },
    onGlobalFilterChange: setGlobalFilter,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
  })

  if (isError) {
    return (
      <div className="flex-1 flex items-center justify-center p-6 text-center">
        <div className="bg-destructive/5 border border-destructive/20 p-12 rounded-3xl max-w-md">
           <AlertCircle className="w-12 h-12 text-destructive mx-auto mb-6" />
           <h2 className="text-xl font-black uppercase italic text-foreground tracking-tight mb-2">Synchrony Failure</h2>
           <p className="text-xs text-muted-foreground font-medium italic opacity-70">The Oracle Identification Bridge encountered a synchronization error. Please verify database connectivity.</p>
           <Button variant="outline" className="mt-8 h-10 px-8 rounded-xl border-destructive/30 text-destructive hover:bg-destructive/5" onClick={() => refetch()}>
              Restart Bridge
           </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="flex-1 pb-10 flex flex-col min-h-screen">
      {/* Page Header */}
      <FadeIn delay={0.1} direction="none">
        <div className="border-b border-border px-6 py-6 bg-background/80 backdrop-blur-3xl sticky top-0 z-40 shadow-sm">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              {assessmentId && (
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button variant="ghost" size="icon" onClick={() => router.back()} className="h-10 w-10 border border-border/50 rounded-xl hover:bg-secondary">
                     <ArrowLeft className="w-4 h-4" />
                  </Button>
                </motion.div>
              )}
              <div>
                <div className="flex items-center gap-2 mb-1">
                   <Shield className="w-3.5 h-3.5 text-primary" />
                   <span className="text-[10px] font-black uppercase tracking-widest text-primary">Pericope Identification Engine</span>
                </div>
                <h1 className="text-2xl font-black tracking-tight text-foreground uppercase italic">
                  {assessmentId ? 'Connected Risks' : 'Risk Identification Ledger'}
                </h1>
                {assessmentId && (
                   <p className="text-[11px] font-bold text-muted-foreground mt-1 bg-primary/5 border border-primary/20 px-2 py-0.5 rounded inline-block">
                      Context Assessment: {assessmentId.slice(0, 16)}
                   </p>
                )}
              </div>
            </div>
            <div className="flex items-center gap-3">
               <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                 <Button variant="outline" className="h-10 text-[11px] font-black uppercase tracking-wider border-border/60 hover:bg-secondary rounded-xl px-5">
                    Export Ledger
                 </Button>
               </motion.div>
               
               <Dialog open={isAddRiskOpen} onOpenChange={setIsAddRiskOpen}>
                 <DialogTrigger asChild>
                   <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                     <Button className="bg-primary hover:bg-primary/90 text-primary-foreground text-[11px] font-black uppercase tracking-widest shadow-xl shadow-primary/20 h-10 px-6 rounded-xl">
                       <Plus className="w-4 h-4 mr-2" />
                       {assessmentId ? 'Connect Risk' : 'Add New Risk'}
                     </Button>
                   </motion.div>
                 </DialogTrigger>
                 <DialogContent className="max-w-md bg-card border border-border/60 shadow-2xl p-0 overflow-hidden rounded-2xl">
                    <div className="h-1.5 w-full bg-primary" />
                    <div className="p-8 space-y-6 text-foreground">
                       <DialogHeader>
                          <DialogTitle className="text-xl font-black tracking-tight uppercase italic">Intelligence Selection</DialogTitle>
                          <DialogDescription className="text-[10px] font-black uppercase text-muted-foreground tracking-widest mt-1">
                             {assessmentId ? 'Select an existing risk from the intelligence library to connect to this assessment.' : 'Catalog a new risk into the enterprise ledger.'}
                          </DialogDescription>
                       </DialogHeader>

                         <div className="space-y-4">
                            <div className="space-y-1.5">
                               <label className="text-[10px] font-black uppercase text-muted-foreground tracking-widest">Master Risk Library</label>
                               <select value={selectedRiskId} onChange={e => setSelectedRiskId(e.target.value)} className="w-full h-11 px-3 text-xs font-bold bg-secondary/30 border border-border/50 rounded-xl focus:ring-2 focus:ring-primary/20 outline-none appearance-none">
                                  <option value="">Select a identified risk...</option>
                                  {masterRisks.map((r: any) => (
                                    <option key={r.uuid || r.id} value={r.uuid || r.id}>
                                       {r.hierarchy_name || r.risk_statement}
                                    </option>
                                  ))}
                               </select>
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                               <div className="space-y-1.5">
                                 <label className="text-[10px] font-black uppercase text-muted-foreground tracking-widest">Inherent Likelihood</label>
                                 <select value={inherentLikelihood} onChange={e => setInherentLikelihood(e.target.value)} className="w-full h-11 px-3 text-xs font-bold bg-secondary/30 border border-border/50 rounded-xl outline-none appearance-none">
                                    <option value="1">1 - Rare</option>
                                    <option value="2">2 - Unlikely</option>
                                    <option value="3">3 - Possible</option>
                                    <option value="4">4 - Likely</option>
                                    <option value="5">5 - Almost Certain</option>
                                 </select>
                               </div>
                               <div className="space-y-1.5">
                                 <label className="text-[10px] font-black uppercase text-muted-foreground tracking-widest">Inherent Impact</label>
                                 <select value={inherentImpact} onChange={e => setInherentImpact(e.target.value)} className="w-full h-11 px-3 text-xs font-bold bg-secondary/30 border border-border/50 rounded-xl outline-none appearance-none">
                                    <option value="1">1 - Insignificant</option>
                                    <option value="2">2 - Minor</option>
                                    <option value="3">3 - Moderate</option>
                                    <option value="4">4 - Major</option>
                                    <option value="5">5 - Extreme</option>
                                 </select>
                               </div>
                            </div>
                            <div className="space-y-1.5">
                              <label className="text-[10px] font-black uppercase text-muted-foreground tracking-widest">Justification</label>
                              <textarea value={justification} onChange={e => setJustification(e.target.value)} className="w-full h-20 p-3 text-xs font-bold bg-secondary/30 border border-border/50 rounded-xl resize-none outline-none focus:ring-2 focus:ring-primary/20" placeholder="Provide context for risk ratings..." />
                            </div>
                            <div className="space-y-1.5">
                              <label className="text-[10px] font-black uppercase text-muted-foreground tracking-widest">Risk Owner</label>
                              <select value={riskOwner} onChange={e => setRiskOwner(e.target.value)} className="w-full h-11 px-3 text-xs font-bold bg-secondary/30 border border-border/50 rounded-xl outline-none appearance-none">
                                <option>Subha</option>
                                <option>Corporate Risk Team</option>
                                <option>Information Security Dept</option>
                              </select>
                            </div>
                         </div>

                       <div className="flex justify-end gap-3 pt-2">
                          <Button variant="ghost" className="text-xs font-black uppercase tracking-widest px-6 h-10 rounded-xl" onClick={() => setIsAddRiskOpen(false)}>Cancel</Button>
                          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                            <Button 
                              className="bg-primary hover:bg-primary/90 text-primary-foreground text-xs font-black uppercase tracking-widest px-8 h-10 rounded-xl shadow-lg shadow-primary/20"
                              onClick={handleSaveRisk}
                              disabled={createMutation.isPending}
                            >
                               {createMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                               {createMutation.isPending ? 'Saving...' : (assessmentId ? 'Connect' : 'Save')}
                            </Button>
                          </motion.div>
                       </div>
                    </div>
                 </DialogContent>
               </Dialog>
            </div>
          </div>
        </div>
      </FadeIn>

      <div className="px-6 pt-5 flex-1 flex flex-col">
        {/* Search & Statistics */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
           <div className="relative max-w-sm flex-1">
              <Search className="absolute left-3 top-2.5 w-4 h-4 text-muted-foreground opacity-50" />
              <Input
                placeholder="Search risk ledger..."
                className="pl-9 h-9 text-[12px] bg-card border-border/50 shadow-sm focus-visible:ring-1 focus-visible:ring-primary/20 transition-all rounded-lg"
                value={globalFilter ?? ''}
                onChange={e => setGlobalFilter(e.target.value)}
              />
           </div>
           
           <div className="flex items-center gap-6 text-[10px] font-black uppercase tracking-widest text-muted-foreground/60 italic">
              <div className="flex items-center gap-1.5">
                 <span>Identified:</span>
                 <span className="text-foreground not-italic">{risks.length}</span>
              </div>
              <div className="flex items-center gap-1.5">
                 <span className="w-1.5 h-1.5 rounded-full bg-blue-300" />
                 <span>Critical:</span>
                 <span className="text-foreground not-italic">{risks.filter((r: any) => (Number(r.inherent_sle) || 0) > 50000).length}</span>
              </div>
           </div>
        </div>

        {/* Intelligence Ledger */}
        <div className="bg-card border border-border rounded-2xl shadow-sm overflow-hidden flex-1 flex flex-col">
           <div className="overflow-x-auto">
              {isLoading ? (
                <div className="py-32 text-center">
                  <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4 text-primary opacity-50" />
                  <p className="text-xs font-black uppercase tracking-widest text-muted-foreground animate-pulse italic">Synchronizing with Oracle ADW...</p>
                </div>
              ) : risks.length === 0 ? (
                <div className="py-32 text-center space-y-4">
                  <div className="w-16 h-16 bg-secondary/30 rounded-full flex items-center justify-center mx-auto border border-dashed border-border/60">
                     <Inbox className="w-6 h-6 text-muted-foreground/30" />
                  </div>
                  <div>
                    <p className="text-sm font-black text-foreground uppercase italic tracking-tight">No Connected Risks</p>
                    <p className="text-[11px] text-muted-foreground mt-1 max-w-[200px] mx-auto leading-relaxed">
                       {assessmentId ? "This assessment cycle has no risks linked. Use the 'Connect Risk' button to start mapping." : "The enterprise risk ledger is currently empty."}
                    </p>
                  </div>
                </div>
              ) : (
                <table className="w-full text-left">
                  <thead className="bg-secondary/20 border-b border-border text-[9px] font-black uppercase tracking-widest text-muted-foreground">
                    {table.getHeaderGroups().map(headerGroup => (
                      <tr key={headerGroup.id}>
                        {headerGroup.headers.map(header => (
                          <th key={header.id} className="px-6 py-4">
                            {flexRender(header.column.columnDef.header, header.getContext())}
                          </th>
                        ))}
                      </tr>
                    ))}
                  </thead>
                  <tbody className="divide-y divide-border/40">
                    <AnimatePresence initial={false}>
                      {table.getRowModel().rows.map(row => (
                        <motion.tr
                          key={row.id}
                          layout
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          exit={{ opacity: 0 }}
                          className="group hover:bg-secondary/10 transition-colors"
                        >
                          {row.getVisibleCells().map(cell => (
                            <td key={cell.id} className="px-6 py-4 border-b border-border/5">
                              {flexRender(cell.column.columnDef.cell, cell.getContext())}
                            </td>
                          ))}
                        </motion.tr>
                      ))}
                    </AnimatePresence>
                  </tbody>
                </table>
              )}
           </div>
        </div>
      </div>
    </div>
  )
}
