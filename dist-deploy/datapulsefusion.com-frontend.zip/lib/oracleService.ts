import axios, { AxiosError } from 'axios'

// API Base URL — controlled via NEXT_PUBLIC_API_URL in .env
// For local dev: NEXT_PUBLIC_API_URL=http://localhost:5000
// For production: NEXT_PUBLIC_API_URL=https://api.datapulsefusion.com
const API_BASE_URL = (process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000').replace(/\/$/, '')

export const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
  // Bounded — the original 30s caused spinners that never resolved if the
  // backend was unreachable. The backend itself has an 8s upstream timeout
  // and an in-memory fallback, so 12s is plenty for any healthy round-trip.
  timeout: 12000,
})

// Attach user attribution to every request so the backend can log who did what.
// This satisfies REC-07 / SEC-04 from the QA report — every audit entry can now
// be tied to a specific user, not just "System".
api.interceptors.request.use(config => {
  if (typeof window !== 'undefined') {
    try {
      const raw = sessionStorage.getItem('pericope_current_user')
      if (raw) {
        const u = JSON.parse(raw)
        config.headers = config.headers || {}
        config.headers['X-User-Id'] = u.id || ''
        config.headers['X-User-Name'] = u.name || ''
        config.headers['X-User-Role'] = u.role || ''
      }
    } catch { /* ignore */ }
  }
  return config
})


/**
 * Cache management for GET requests
 */
class RequestCache {
  private cache = new Map<string, { data: any; timestamp: number }>()
  private cacheTTL = 5 * 60 * 1000 // 5 minutes default

  set(key: string, data: any, ttl?: number) {
    this.cache.set(key, { data, timestamp: Date.now() })
    if (ttl) {
      setTimeout(() => this.cache.delete(key), ttl)
    }
  }

  get(key: string): any | null {
    const entry = this.cache.get(key)
    if (!entry) return null
    
    const age = Date.now() - entry.timestamp
    if (age > this.cacheTTL) {
      this.cache.delete(key)
      return null
    }
    
    return entry.data
  }

  clear() {
    this.cache.clear()
  }

  has(key: string): boolean {
    return this.cache.has(key)
  }
}

/**
 * Request queue for managing concurrent requests
 */
class RequestQueue {
  private queue: Array<() => Promise<any>> = []
  private activeRequests = 0
  private maxConcurrent = 10

  async enqueue(request: () => Promise<any>): Promise<any> {
    return new Promise((resolve, reject) => {
      this.queue.push(async () => {
        try {
          const result = await request()
          resolve(result)
        } catch (error) {
          reject(error)
        }
      })
      this.process()
    })
  }

  private async process() {
    if (this.activeRequests >= this.maxConcurrent || this.queue.length === 0) return

    this.activeRequests++
    const request = this.queue.shift()

    try {
      await request?.()
    } finally {
      this.activeRequests--
      this.process()
    }
  }
}

/**
 * Retry logic with exponential backoff
 */
const retryWithBackoff = async (
  fn: () => Promise<any>,
  maxAttempts = 2,
  initialDelayMs = 500,
  backoffFactor = 2
): Promise<any> => {
  let lastError: any
  
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      return await fn()
    } catch (error: any) {
      lastError = error
      
      // Don't retry on 4xx errors (client errors)
      if (error.response?.status && error.response.status >= 400 && error.response.status < 500) {
        throw error
      }
      
      if (attempt < maxAttempts) {
        const delay = initialDelayMs * Math.pow(backoffFactor, attempt - 1)
        await new Promise(resolve => setTimeout(resolve, delay))
      }
    }
  }
  
  throw lastError
}

/**
 * Normalizes ORDS response items.
 */
const normalizeItems = (data: any) => {
  if (!data) return []
  
  // Extract the actual data array from the response structure
  // Handle { success, data, pagination } format
  let items: any[] = []
  
  if (data?.items && Array.isArray(data.items)) {
    items = data.items
  } else if (data?.data && Array.isArray(data.data)) {
    items = data.data
  } else if (data?.success === true && Array.isArray(data?.data)) {
    items = data.data
  } else if (Array.isArray(data)) {
    items = data
  } else if (data?.item) {
    items = [data.item]
  } else if (typeof data === 'object' && data !== null && !data.items && !data.data) {
    // If it's a single object (not a list), wrap it
    items = [data]
  }
  
  return items.map((item: any) => {
    if (!item || typeof item !== 'object') return item
    const normalized: any = {}
    Object.keys(item).forEach(key => {
      normalized[key.toLowerCase()] = item[key]
    })
    return normalized
  })
}

/**
 * Error handler for API errors
 * Suppresses expected errors: 404s and network errors for DELETE/PUT operations
 */
const handleApiError = (error: any, endpoint: string) => {
  const errorData: any = {
    endpoint,
    timestamp: new Date().toISOString(),
    message: 'API request failed',
  }

  const isDeleteOrUpdate = endpoint.includes('DELETE') || endpoint.includes('PUT')
  const isNetworkError = error.code === 'ERR_NETWORK' || error.code?.includes('ERR_') || (error.response?.status === 0)
  const is404 = error.response?.status === 404

  if (error.response) {
    errorData.status = error.response.status
    errorData.statusText = error.response.statusText
    errorData.data = error.response.data
    
    // Log as warning, not error, to avoid triggering Next.js error overlay
    console.warn(`[OracleService] ${endpoint}:`, errorData.status || 'Network Error')
  } else if (error.request) {
    errorData.message = 'No response from server'
    errorData.code = error.code
    
    console.warn(`[OracleService Warning] ${endpoint}: No response from server`)
  } else {
    errorData.message = error.message
    
    console.warn(`[OracleService Warning] ${endpoint}:`, errorData)
  }

  return errorData
}

const requestCache = new RequestCache()
const requestQueue = new RequestQueue()

export const oracleService = {
  // Generic Fetcher for React Query with retry and caching
  fetch: async (resource: string, params: any = {}, options: any = {}) => {
    // Inject pagination bypass to override ORDS default 25 limit block
    const fetchParams = { limit: 10000, ...params }
    const cacheKey = `${resource}?${JSON.stringify(fetchParams)}`
    
    // Check cache first for GET requests
    if (!options.skipCache) {
      const cached = requestCache.get(cacheKey)
      if (cached !== null) {
        return cached
      }
    }

    try {
      const result = await retryWithBackoff(async () => {
        const res = await api.get(resource, { params: fetchParams })
        return res.data
      }, options.maxRetries || 2)

      console.log(`[OracleService] Fetch OK: ${resource}`, result);
      const normalized = normalizeItems(result)
      console.log(`[OracleService] Normalized: ${resource}`, normalized);
      
      // Cache successful GET responses
      if (!options.skipCache) {
        requestCache.set(cacheKey, normalized, options.cacheTTL)
      }

      return normalized
    } catch (error: any) {
      handleApiError(error, resource)
      // Return empty array to prevent UI errors
      return []
    }
  },

  // Dashboard APIs — computed from real table data
  getDashboardSummary: async () => {
    try {
      const [risks, controls, monitoring] = await Promise.all([
        oracleService.fetch('api/per_trn_identify_risk', {}, { cacheTTL: 2 * 60 * 1000 }),
        oracleService.fetch('api/per_trn_control_implementation', {}, { cacheTTL: 2 * 60 * 1000 }),
        oracleService.fetch('api/per_trn_risk_monitoring', {}, { cacheTTL: 2 * 60 * 1000 }),
      ])
      return [{
        total_risks: risks.length,
        completed_risks: risks.filter((r: any) => r.is_stage_complted === 'Y').length,
        pending_risks: risks.filter((r: any) => r.is_stage_complted !== 'Y').length,
        total_controls: controls.length,
        total_monitoring: monitoring.length,
      }]
    } catch {
      return [{ total_risks: 0, completed_risks: 0, pending_risks: 0, total_controls: 0, total_monitoring: 0 }]
    }
  },
  getRiskTrend: async () => {
    try {
      const risks = await oracleService.fetch('api/per_trn_identify_risk', {}, { cacheTTL: 2 * 60 * 1000 })
      // Group risks by month for trend
      const grouped: Record<string, number> = {}
      risks.forEach((r: any) => {
        const date = r.assessment_registered_date?.split('T')[0]?.substring(0, 7) || 'Unknown'
        grouped[date] = (grouped[date] || 0) + 1
      })
      return Object.entries(grouped).sort().map(([d, c]) => ({ risk_date: d, total_risks: c }))
    } catch {
      return []
    }
  },
  getRiskDistribution: async () => {
    try {
      const risks = await oracleService.fetch('api/per_trn_identify_risk', {}, { cacheTTL: 2 * 60 * 1000 })
      const grouped: Record<string, number> = {}
      risks.forEach((r: any) => {
        const cat = r.risk_type || r.process_name || 'Uncategorized'
        grouped[cat] = (grouped[cat] || 0) + 1
      })
      return Object.entries(grouped).map(([category, value]) => ({ category, value }))
    } catch {
      return []
    }
  },
  getRiskByCategory: async () => {
    try {
      const categories = await oracleService.fetch('api/per_mst_risk_category', {}, { cacheTTL: 10 * 60 * 1000 })
      return categories.map((c: any) => ({ category: c.risk_category_name || c.name, count: 1 }))
    } catch {
      return []
    }
  },
  getRiskByProcess: async () => {
    try {
      const processes = await oracleService.fetch('api/per_mst_business_process', {}, { cacheTTL: 10 * 60 * 1000 })
      const risks = await oracleService.fetch('api/per_trn_identify_risk', {}, { cacheTTL: 2 * 60 * 1000 })
      return processes.map((p: any) => ({
        process: p.business_process_name || p.name || 'Unknown',
        count: risks.filter((r: any) => r.business_process_id === p.id || r.business_process_id === p.uuid).length || 1
      }))
    } catch {
      return []
    }
  },
  getControlEffectiveness: async () => {
    try {
      return await oracleService.fetch('api/per_trn_control_implementation', {}, { cacheTTL: 2 * 60 * 1000 })
    } catch {
      return []
    }
  },
  getMonitoringStatus: async () => {
    try {
      return await oracleService.fetch('api/per_trn_risk_monitoring', {}, { cacheTTL: 2 * 60 * 1000 })
    } catch {
      return []
    }
  },

  // Transactional APIs (CRUD)
  // Identify Risk
  getIdentifyRisks: (params = {}) => {
    return oracleService.fetch('api/per_trn_identify_risk', params)
  },
  createIdentifyRisk: async (data: any) => {
    try {
      return await retryWithBackoff(async () => {
        const res = await api.post('api/per_trn_identify_risk', data)
        // Invalidate cache after mutation
        requestCache.clear()
        return res.data
      }, 3)
    } catch (error: any) {
      handleApiError(error, 'POST api/per_trn_identify_risk')
      throw error
    }
  },
  updateIdentifyRisk: async (id: string | number, data: any) => {
    try {
      return await retryWithBackoff(async () => {
        const res = await api.put(`api/per_trn_identify_risk/${id}`, data)
        requestCache.clear()
        return res.data
      }, 3)
    } catch (error: any) {
      handleApiError(error, `PUT api/per_trn_identify_risk/${id}`)
      throw error
    }
  },
  deleteIdentifyRisk: async (id: string | number) => {
    try {
      return await retryWithBackoff(async () => {
        const res = await api.delete(`api/per_trn_identify_risk/${id}`)
        requestCache.clear()
        return res.data
      }, 3)
    } catch (error: any) {
      handleApiError(error, `DELETE api/per_trn_identify_risk/${id}`)
      throw error
    }
  },

  // Control Implementation
  getControlImplementations: () => oracleService.fetch('api/per_trn_control_implementation'),
  createControlImplementation: async (data: any) => {
    try {
      return await retryWithBackoff(async () => {
        const res = await api.post('api/per_trn_control_implementation', data)
        requestCache.clear()
        return res.data
      }, 3)
    } catch (error: any) {
      handleApiError(error, 'POST api/per_trn_control_implementation')
      throw error
    }
  },
  updateControlImplementation: async (id: string | number, data: any) => {
    try {
      return await retryWithBackoff(async () => {
        const res = await api.put(`api/per_trn_control_implementation/${id}`, data)
        requestCache.clear()
        return res.data
      }, 3)
    } catch (error: any) {
      handleApiError(error, `PUT api/per_trn_control_implementation/${id}`)
      throw error
    }
  },
  deleteControlImplementation: async (id: string | number) => {
    try {
      return await retryWithBackoff(async () => {
        const res = await api.delete(`api/per_trn_control_implementation/${id}`)
        requestCache.clear()
        return res.data
      }, 3)
    } catch (error: any) {
      handleApiError(error, `DELETE api/per_trn_control_implementation/${id}`)
      throw error
    }
  },

  // Inherent/Residual Assessments — mapped to per_trn_identify_risk
  getRiskAssessments: () => oracleService.fetch('api/per_trn_identify_risk'),
  createRiskAssessment: async (data: any) => {
    try {
      return await retryWithBackoff(async () => {
        const res = await api.post('api/per_trn_identify_risk', data)
        requestCache.clear()
        return res.data
      }, 3)
    } catch (error: any) {
      handleApiError(error, 'POST api/per_trn_identify_risk')
      throw error
    }
  },
  updateRiskAssessment: async (id: string | number, data: any) => {
    try {
      return await retryWithBackoff(async () => {
        const res = await api.put(`api/per_trn_identify_risk/${id}`, data)
        requestCache.clear()
        return res.data
      }, 3)
    } catch (error: any) {
      handleApiError(error, `PUT api/per_trn_identify_risk/${id}`)
      throw error
    }
  },
  deleteRiskAssessment: async (id: string | number) => {
    try {
      return await retryWithBackoff(async () => {
        const res = await api.delete(`api/per_trn_identify_risk/${id}`)
        requestCache.clear()
        return res.data
      }, 3)
    } catch (error: any) {
      handleApiError(error, `DELETE api/per_trn_identify_risk/${id}`)
      throw error
    }
  },

  // Mitigation Plans — mapped to per_trn_control_implementation
  getMitigationPlans: () => oracleService.fetch('api/per_trn_control_implementation'),
  createMitigationPlan: async (data: any) => {
    try {
      return await retryWithBackoff(async () => {
        const res = await api.post('api/per_trn_control_implementation', data)
        requestCache.clear()
        return res.data
      }, 3)
    } catch (error: any) {
      handleApiError(error, 'POST api/per_trn_control_implementation')
      throw error
    }
  },
  updateMitigationPlan: async (id: string | number, data: any) => {
    try {
      return await retryWithBackoff(async () => {
        const res = await api.put(`api/per_trn_control_implementation/${id}`, data)
        requestCache.clear()
        return res.data
      }, 3)
    } catch (error: any) {
      handleApiError(error, `PUT api/per_trn_control_implementation/${id}`)
      throw error
    }
  },
  deleteMitigationPlan: async (id: string | number) => {
    try {
      return await retryWithBackoff(async () => {
        const res = await api.delete(`api/per_trn_control_implementation/${id}`)
        requestCache.clear()
        return res.data
      }, 3)
    } catch (error: any) {
      handleApiError(error, `DELETE api/per_trn_control_implementation/${id}`)
      throw error
    }
  },

  // Risk Monitoring
  getRiskMonitoring: () => oracleService.fetch('api/per_trn_risk_monitoring'),
  createRiskMonitoring: async (data: any) => {
    try {
      return await retryWithBackoff(async () => {
        const res = await api.post('api/per_trn_risk_monitoring', data)
        requestCache.clear()
        return res.data
      }, 3)
    } catch (error: any) {
      handleApiError(error, 'POST per_trn_risk_monitoring')
      throw error
    }
  },
  updateRiskMonitoring: async (id: string | number, data: any) => {
    try {
      return await retryWithBackoff(async () => {
        const res = await api.put(`api/per_trn_risk_monitoring/${id}`, data)
        requestCache.clear()
        return res.data
      }, 3)
    } catch (error: any) {
      handleApiError(error, `PUT per_trn_risk_monitoring/${id}`)
      throw error
    }
  },
  deleteRiskMonitoring: async (id: string | number) => {
    try {
      return await retryWithBackoff(async () => {
        const res = await api.delete(`api/per_trn_risk_monitoring/${id}`)
        requestCache.clear()
        return res.data
      }, 3)
    } catch (error: any) {
      handleApiError(error, `DELETE per_trn_risk_monitoring/${id}`)
      throw error
    }
  },

  // Master Table APIs (with longer cache since they change infrequently)
  getBusinessProcesses: () => oracleService.fetch('api/per_mst_business_process', {}, { cacheTTL: 10 * 60 * 1000 }),
  getBusinessSubProcesses: () => oracleService.fetch('api/per_mst_business_sub_process', {}, { cacheTTL: 10 * 60 * 1000 }),
  getRiskStatements: () => oracleService.fetch('api/per_mst_risk_statement', {}, { cacheTTL: 10 * 60 * 1000 }),
  getRoles: () => oracleService.fetch('api/per_mst_roles', {}, { cacheTTL: 10 * 60 * 1000 }),
  getControlCategories: () => oracleService.fetch('api/per_mst_control_category', {}, { cacheTTL: 10 * 60 * 1000 }),
  getControlClasifications: () => oracleService.fetch('api/per_mst_control_clasification', {}, { cacheTTL: 10 * 60 * 1000 }),
  getControlDesignEffectiveness: () => oracleService.fetch('api/per_mst_control_design_effectiveness', {}, { cacheTTL: 10 * 60 * 1000 }),
  getControlFrequencies: () => oracleService.fetch('api/per_mst_control_frequency', {}, { cacheTTL: 10 * 60 * 1000 }),
  getControlRegisters: () => oracleService.fetch('api/per_mst_control_register', {}, { cacheTTL: 10 * 60 * 1000 }),
  getControlTypes: () => oracleService.fetch('api/per_mst_control_type', {}, { cacheTTL: 10 * 60 * 1000 }),
  getCurrencyTypes: () => oracleService.fetch('api/per_mst_currency_type', {}, { cacheTTL: 10 * 60 * 1000 }),
  getDesignations: () => oracleService.fetch('api/per_mst_designation', {}, { cacheTTL: 10 * 60 * 1000 }),
  getImpacts: () => oracleService.fetch('api/per_mst_impact', {}, { cacheTTL: 10 * 60 * 1000 }),
  getImpactCategories: () => oracleService.fetch('api/per_mst_impact_category', {}, { cacheTTL: 10 * 60 * 1000 }),
  getImpactParties: () => oracleService.fetch('api/per_mst_impact_parties', {}, { cacheTTL: 10 * 60 * 1000 }),
  getImpactSubCategories: () => oracleService.fetch('api/per_mst_impact_sub_category', {}, { cacheTTL: 10 * 60 * 1000 }),
  getLikelihoods: () => oracleService.fetch('api/per_mst_likelihood', {}, { cacheTTL: 10 * 60 * 1000 }),
  getOrgHierarchies: () => oracleService.fetch('api/per_mst_org_hierarchy', {}, { cacheTTL: 10 * 60 * 1000 }),
  getOrgLevels: () => oracleService.fetch('api/per_mst_org_level', {}, { cacheTTL: 10 * 60 * 1000 }),
  getRiskCategories: () => oracleService.fetch('api/per_mst_risk_category', {}, { cacheTTL: 10 * 60 * 1000 }),
  getRiskCausalFactors: () => oracleService.fetch('api/per_mst_risk_causal_factor', {}, { cacheTTL: 10 * 60 * 1000 }),
  getRiskCompuationLogic: () => oracleService.fetch('api/per_mst_risk_compuation_logic', {}, { cacheTTL: 10 * 60 * 1000 }),
  getRiskCycles: () => oracleService.fetch('api/per_mst_risk_cycle', {}, { cacheTTL: 10 * 60 * 1000 }),
  getRiskDataSources: () => oracleService.fetch('api/per_mst_risk_data_source', {}, { cacheTTL: 10 * 60 * 1000 }),
  getRiskRootCauses: () => oracleService.fetch('api/per_mst_risk_root_cause', {}, { cacheTTL: 10 * 60 * 1000 }),
  getRiskSubCategories: () => oracleService.fetch('api/per_mst_risk_sub_category', {}, { cacheTTL: 10 * 60 * 1000 }),
  getRiskTypes: () => oracleService.fetch('api/per_mst_risk_type', {}, { cacheTTL: 10 * 60 * 1000 }),
  getUserDetails: () => oracleService.fetch('api/per_mst_user_details', {}, { cacheTTL: 10 * 60 * 1000 }),
  getUserRolesMappings: () => oracleService.fetch('api/per_mst_user_roles_mapping', {}, { cacheTTL: 10 * 60 * 1000 }),

  // KPI APIs
  getKpiDefinitions: () => oracleService.fetch('api/erm_mst_kpi_definition', {}, { cacheTTL: 5 * 60 * 1000 }),
  createKpiDefinition: async (data: any) => {
    try {
      const res = await api.post('api/erm_mst_kpi_definition', data);
      requestCache.clear();
      return res.data;
    } catch (error: any) {
      handleApiError(error, 'POST erm_mst_kpi_definition');
      throw error;
    }
  },
  updateKpiDefinition: async (id: string | number, data: any) => {
    try {
      const res = await api.put(`api/erm_mst_kpi_definition/${id}`, data);
      requestCache.clear();
      return res.data;
    } catch (error: any) {
      handleApiError(error, `PUT erm_mst_kpi_definition/${id}`);
      throw error;
    }
  },
  deleteKpiDefinition: async (id: string | number) => {
    try {
      const res = await api.delete(`api/erm_mst_kpi_definition/${id}`);
      requestCache.clear();
      return res.data;
    } catch (error: any) {
      handleApiError(error, `DELETE erm_mst_kpi_definition/${id}`);
      throw error;
    }
  },
  getKpiActuals: () => oracleService.fetch('api/erm_trn_kpi_actuals', {}, { cacheTTL: 5 * 60 * 1000 }),

  // KRI APIs
  getKriMatrix: () => oracleService.fetch('api/erm_mst_kri_definition', {}, { cacheTTL: 5 * 60 * 1000 }),
  getKriConfiguration: () => oracleService.fetch('api/erm_mst_kri_definition', {}, { cacheTTL: 5 * 60 * 1000 }),
  createKriDefinition: async (data: any) => {
    try {
      const res = await api.post('api/erm_mst_kri_definition', data);
      requestCache.clear();
      return res.data;
    } catch (error: any) {
      handleApiError(error, 'POST erm_mst_kri_definition');
      throw error;
    }
  },
  updateKriDefinition: async (id: string | number, data: any) => {
    try {
      const res = await api.put(`api/erm_mst_kri_definition/${id}`, data);
      requestCache.clear();
      return res.data;
    } catch (error: any) {
      handleApiError(error, `PUT erm_mst_kri_definition/${id}`);
      throw error;
    }
  },
  deleteKriDefinition: async (id: string | number) => {
    try {
      const res = await api.delete(`api/erm_mst_kri_definition/${id}`);
      requestCache.clear();
      return res.data;
    } catch (error: any) {
      handleApiError(error, `DELETE erm_mst_kri_definition/${id}`);
      throw error;
    }
  },
  getKriReadings: () => oracleService.fetch('api/erm_trn_kri_readings', {}, { cacheTTL: 5 * 60 * 1000 }),
  createKriReading: async (data: any) => {
    try {
      return await retryWithBackoff(async () => {
        const res = await api.post('api/erm_trn_kri_readings', data)
        requestCache.clear()
        return res.data
      }, 3)
    } catch (error: any) {
      handleApiError(error, 'POST api/erm_trn_kri_readings')
      throw error
    }
  },

  // Inherent Risk Assessment — dedicated table
  getInherentRiskAssessments: () => oracleService.fetch('api/per_trn_inherent_risk_assessment', {}, { cacheTTL: 5 * 60 * 1000 }),
  createInherentRiskAssessment: async (data: any) => {
    try {
      return await retryWithBackoff(async () => {
        const res = await api.post('api/per_trn_inherent_risk_assessment', data)
        requestCache.clear()
        return res.data
      }, 3)
    } catch (error: any) {
      handleApiError(error, 'POST api/per_trn_inherent_risk_assessment')
      throw error
    }
  },
  updateInherentRiskAssessment: async (id: string | number, data: any) => {
    try {
      return await retryWithBackoff(async () => {
        const res = await api.put(`api/per_trn_inherent_risk_assessment/${id}`, data)
        requestCache.clear()
        return res.data
      }, 3)
    } catch (error: any) {
      handleApiError(error, `PUT api/per_trn_inherent_risk_assessment/${id}`)
      throw error
    }
  },

  // Mitigation Plans — dedicated table
  getMitigationPlansDedicated: () => oracleService.fetch('api/per_trn_mitigation_plans', {}, { cacheTTL: 5 * 60 * 1000 }),
  createMitigationPlanDedicated: async (data: any) => {
    try {
      return await retryWithBackoff(async () => {
        const res = await api.post('api/per_trn_mitigation_plans', data)
        requestCache.clear()
        return res.data
      }, 3)
    } catch (error: any) {
      handleApiError(error, 'POST api/per_trn_mitigation_plans')
      throw error
    }
  },
  updateMitigationPlanDedicated: async (id: string | number, data: any) => {
    try {
      return await retryWithBackoff(async () => {
        const res = await api.put(`api/per_trn_mitigation_plans/${id}`, data)
        requestCache.clear()
        return res.data
      }, 3)
    } catch (error: any) {
      handleApiError(error, `PUT api/per_trn_mitigation_plans/${id}`)
      throw error
    }
  },

  // Assessment Cycle
  getAssessmentCycles: () => oracleService.fetch('api/erm_trn_assessment_cycle', {}, { cacheTTL: 5 * 60 * 1000 }),
  createAssessmentCycle: async (data: any) => {
    try {
      return await retryWithBackoff(async () => {
        const res = await api.post('api/erm_trn_assessment_cycle', data)
        requestCache.clear()
        return res.data
      }, 3)
    } catch (error: any) {
      handleApiError(error, 'POST api/erm_trn_assessment_cycle')
      throw error
    }
  },

  // Assessment APIs — mapped to real tables
  getAppetiteFramework: () => oracleService.fetch('api/per_mst_risk_category', {}, { cacheTTL: 10 * 60 * 1000 }),
  getAppetiteRiskAppetite: () => oracleService.fetch('api/per_trn_identify_risk', {}, { cacheTTL: 10 * 60 * 1000 }),
  getAssessmentsAccess: () => oracleService.fetch('api/per_trn_identify_risk', {}, { cacheTTL: 5 * 60 * 1000 }),
  getAssessmentsControls: () => oracleService.fetch('api/per_trn_control_implementation', {}, { cacheTTL: 5 * 60 * 1000 }),
  updateControlAssessment: async (id: string | number, data: any) => {
    try {
      return await retryWithBackoff(async () => {
        const res = await api.put(`api/per_trn_control_implementation/${id}`, data)
        requestCache.clear()
        return res.data
      }, 3)
    } catch (error: any) {
      handleApiError(error, `PUT api/per_trn_control_implementation/${id}`)
      throw error
    }
  },
  getAssessmentsResidual: () => oracleService.fetch('api/per_trn_identify_risk', {}, { cacheTTL: 5 * 60 * 1000 }),

  // Asset Management and Audit APIs
  getAssets: () => oracleService.fetch('api/per_mst_business_process', {}, { cacheTTL: 10 * 60 * 1000 }),
  getAuditTrail: (params = {}) => oracleService.fetch('api/erm_trn_audit_log', params),

  // Monitoring Action Plans
  getMonitoringActionPlan: () => oracleService.fetch('api/per_trn_risk_monitoring', {}, { cacheTTL: 5 * 60 * 1000 }),
  getMonitoringActionsHierarchy: () => oracleService.fetch('api/per_trn_risk_monitoring', {}, { cacheTTL: 5 * 60 * 1000 }),

  // Reports API
  getReports: (params = {}) => oracleService.fetch('api/per_trn_identify_risk', params),

  // Utility functions
  clearCache: () => requestCache.clear(),
  getCacheStats: () => ({
    timestamp: new Date().toISOString(),
    message: 'Cache cleared. Next requests will be fresh from server.',
  }),

  // Compatibility Helpers
  getRiskAssessmentsList: () => oracleService.getIdentifyRisks(),
  getRiskPlanningIdentify: () => oracleService.getIdentifyRisks(),
  getMonitoringRiskMonitoring: () => oracleService.getRiskMonitoring(),
  getRiskAssessmentsDashboard: () => oracleService.getIdentifyRisks(),
}
