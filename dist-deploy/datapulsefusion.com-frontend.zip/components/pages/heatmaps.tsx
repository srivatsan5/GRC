'use client'

import React, { useMemo, useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { Flame, Layers } from 'lucide-react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'
import { oracleService } from '@/lib/oracleService'

type View = 'inherent' | 'residual' | 'velocity'

export function HeatmapsPage() {
  const [view, setView] = useState<View>('inherent')

  const { data: risks = [], isLoading } = useQuery({
    queryKey: ['heatmaps', 'risks'],
    queryFn: () => oracleService.getIdentifyRisks(),
  })

  const cells = useMemo(() => buildGrid(risks, view), [risks, view])

  const stats = useMemo(() => ({
    total: risks.length,
    critical: cells.filter(c => c.score >= 16).reduce((s, c) => s + c.count, 0),
    elevated: cells.filter(c => c.score >= 10 && c.score < 16).reduce((s, c) => s + c.count, 0),
    acceptable: cells.filter(c => c.score < 10).reduce((s, c) => s + c.count, 0),
  }), [cells, risks])

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Flame className="w-4 h-4 text-primary" />
            <span className="text-[10px] font-black uppercase tracking-[0.3em] text-primary">Risk Heatmaps</span>
          </div>
          <h1 className="text-3xl font-black tracking-tight">Risk Heatmaps</h1>
          <p className="text-muted-foreground mt-2 font-medium">Probability × impact distribution across enterprise risks.</p>
        </div>
        <div className="flex gap-2">
          {(['inherent', 'residual', 'velocity'] as const).map(v => (
            <Button key={v} variant={view === v ? 'primary' : 'ghost'} onClick={() => setView(v)} className="capitalize">{v}</Button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Stat label="Total risks" value={risks.length} tone="blue" />
        <Stat label="Critical risk zone" value={stats.critical} tone="red" />
        <Stat label="Elevated risk zone" value={stats.elevated} tone="amber" />
        <Stat label="Acceptable risk zone" value={stats.acceptable} tone="emerald" />
      </div>

      <Card className="p-8">
        <h2 className="text-base font-black uppercase tracking-widest text-foreground mb-6">{view} 5×5 Matrix</h2>
        {isLoading ? (
          <div className="py-20 text-center text-muted-foreground">Loading…</div>
        ) : (
          <div className="flex justify-center">
            <div className="flex flex-col items-center">
              <div className="flex">
                <div className="flex flex-col items-center justify-center mr-3 w-6">
                  <span className="text-[10px] font-black uppercase tracking-widest text-muted-foreground -rotate-90 whitespace-nowrap">Impact →</span>
                </div>
                <div>
                  <div className="grid grid-cols-5 gap-2">
                    {cells.map((cell, i) => {
                      const tone = cell.score >= 16 ? 'bg-red-100 border-red-300 text-red-700' : cell.score >= 10 ? 'bg-amber-100 border-amber-300 text-amber-700' : cell.score >= 6 ? 'bg-yellow-100 border-yellow-300 text-yellow-700' : 'bg-emerald-100 border-emerald-300 text-emerald-700'
                      return (
                        <div key={i} className={cn('w-20 h-20 rounded-2xl border-2 flex flex-col items-center justify-center', tone)}>
                          <span className="text-[10px] opacity-60">{cell.score}</span>
                          <span className="text-2xl font-black tabular-nums">{cell.count || ''}</span>
                        </div>
                      )
                    })}
                  </div>
                  <div className="text-center mt-3">
                    <span className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Likelihood →</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </Card>

      <Card className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Legend tone="red" label="Critical risk zone" desc="Immediate intervention required." />
          <Legend tone="amber" label="Elevated risk zone" desc="Senior oversight mandatory." />
          <Legend tone="yellow" label="Monitored zone" desc="Tracked via control monitoring." />
          <Legend tone="emerald" label="Acceptable risk zone" desc="Within enterprise appetite." />
        </div>
      </Card>
    </div>
  )
}

function buildGrid(risks: any[], view: 'inherent' | 'residual' | 'velocity') {
  return Array.from({ length: 25 }, (_, i) => {
    const row = Math.floor(i / 5)
    const col = i % 5
    const prob = 5 - row
    const impact = col + 1
    const matched = risks.filter((r: any) => {
      const sle = r.inherent_sle || 0
      let rProb = Math.min(5, Math.max(1, Math.ceil(sle / 20000)))
      let rImpact = Math.min(5, Math.max(1, Math.ceil((sle % 20000) / 4000) || 1))
      if (view === 'residual') { rProb = Math.max(1, rProb - 1); rImpact = Math.max(1, rImpact - 1) }
      if (view === 'velocity') { rProb = Math.min(5, rProb + 1) }
      return rProb === prob && rImpact === impact
    }).length
    return { prob, impact, score: prob * impact, count: matched }
  })
}

function Stat({ label, value, tone }: { label: string; value: number; tone: 'blue' | 'red' | 'amber' | 'emerald' }) {
  const colorMap = { blue: 'text-blue-600 bg-blue-50', red: 'text-red-600 bg-red-50', amber: 'text-amber-600 bg-amber-50', emerald: 'text-emerald-600 bg-emerald-50' }[tone]
  return (
    <Card className="p-5 flex items-center gap-4">
      <div className={cn('w-12 h-12 rounded-2xl flex items-center justify-center', colorMap)}><Layers className="w-5 h-5" /></div>
      <div>
        <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">{label}</p>
        <p className="text-2xl font-black tabular-nums text-foreground">{value}</p>
      </div>
    </Card>
  )
}

function Legend({ tone, label, desc }: { tone: 'red' | 'amber' | 'yellow' | 'emerald'; label: string; desc: string }) {
  const colorMap = { red: 'bg-red-500', amber: 'bg-amber-500', yellow: 'bg-yellow-500', emerald: 'bg-emerald-500' }[tone]
  return (
    <div className="flex items-start gap-3">
      <div className={cn('w-3 h-3 rounded-full mt-1.5', colorMap)} />
      <div>
        <p className="text-[11px] font-black uppercase tracking-widest">{label}</p>
        <p className="text-[10px] text-muted-foreground">{desc}</p>
      </div>
    </div>
  )
}
