'use client'

import React, { useState } from 'react'
import { Lock, User, ShieldCheck, ArrowRight, Loader2 } from 'lucide-react'
import { useAuth } from '@/components/providers/auth-provider'
import { useToast } from '@/hooks/use-toast'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { FadeIn } from '@/components/ui/fade-in'

export function LoginPage() {
  const { login, users } = useAuth()
  const { toast } = useToast()

  const [email, setEmail] = useState('srivatsan@pericope.local')
  const [password, setPassword] = useState('Demo123!')
  const [isLoading, setIsLoading] = useState(false)

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    setTimeout(() => {
      const matched = users.find(u => u.email.toLowerCase() === email.toLowerCase() && u.active)
      if (matched && password.length >= 6) {
        toast({
          title: 'Authentication Successful',
          description: `Welcome ${matched.name}.`,
          className: 'bg-emerald-600 text-white border-none'
        })
        login(matched.email)
      } else {
        toast({
          title: 'Authentication Failed',
          description: matched ? 'Invalid password.' : 'No active user with that email.',
          variant: 'destructive'
        })
        setIsLoading(false)
      }
    }, 600)
  }

  return (
    <div className="min-h-screen bg-background flex items-center justify-center relative overflow-hidden">

      <div className="absolute -top-40 -left-40 w-96 h-96 bg-blue-100/40 rounded-full blur-[100px] pointer-events-none" />
      <div className="absolute -bottom-40 -right-40 w-96 h-96 bg-blue-200/30 rounded-full blur-[100px] pointer-events-none" />

      <div className="w-full max-w-md p-6 z-10">
        <FadeIn delay={0.1}>
          <div className="glass-card p-10 rounded-3xl shadow-2xl border border-border/60 relative overflow-hidden group">

            <div className="absolute top-0 left-0 w-full h-1 bg-blue-500 opacity-80" />

            <div className="flex justify-center mb-8">
              <div className="w-16 h-16 rounded-2xl bg-secondary/80 flex items-center justify-center border border-border/50 shadow-inner group-hover:scale-105 transition-transform duration-500">
                <ShieldCheck className="w-8 h-8 text-primary" />
              </div>
            </div>

            <div className="text-center mb-10">
              <h1 className="text-2xl font-black text-foreground tracking-tight">Pericope ERM</h1>
              <p className="text-sm text-muted-foreground mt-2 font-medium tracking-wide">Enterprise Risk Management</p>
            </div>

            <form onSubmit={handleLogin} className="space-y-6">

              <div className="space-y-4">
                <div className="space-y-1.5 relative">
                  <label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground ml-1">Email</label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground/60" />
                    <Input
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="pl-10 h-12 bg-background/50 border-border/60 focus:ring-primary/30 rounded-xl text-sm font-semibold"
                      placeholder="name@company.com"
                      type="email"
                    />
                  </div>
                </div>

                <div className="space-y-1.5 relative">
                  <label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground ml-1">Password</label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground/60" />
                    <Input
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="pl-10 h-12 bg-background/50 border-border/60 focus:ring-primary/30 rounded-xl text-sm font-semibold"
                      placeholder="Enter password"
                    />
                  </div>
                </div>
              </div>

              <Button
                type="submit"
                disabled={isLoading || !email || !password}
                className="w-full h-12 rounded-xl text-sm font-black uppercase tracking-widest bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2 group/btn"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" /> Authenticating
                  </>
                ) : (
                  <>
                    Secure Login
                    <ArrowRight className="w-4 h-4 group-hover/btn:translate-x-1 transition-transform" />
                  </>
                )}
              </Button>
            </form>

            <div className="mt-8 text-center text-[10px] grid grid-cols-1 gap-1 text-muted-foreground font-medium uppercase tracking-widest">
              <p>Demo: srivatsan@pericope.local / Demo123!</p>
            </div>

          </div>
        </FadeIn>
      </div>

    </div>
  )
}
