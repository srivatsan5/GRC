'use client'

import React, { useMemo, useState } from 'react'
import { TrendingUp, Plus, Play, Trash2, Pencil, Activity } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'
import { createStore, useStoreSnapshot, genId } from '@/lib/localStore'
import { useToast } from '@/hooks/use-toast'
import { recordAudit } from '@/lib/auditLog'
import { useConfirm } from '@/components/ui/confirm-dialog'
import { useAuth } from '@/components/providers/auth-provider'

export interface Scenario {
  id: string
  name: string
  description: string
  type: 'Stress Test' | 'What-if' | 'Reverse Stress' | 'Tail Risk'
  category: string
  shockMagnitude: number // percent
  baselineLoss: number
  stressedLoss: number
  probability: number // 1-100
  owner: string
  lastRun?: string
}

const SEED: Scenario[] = [
  { id: 'SC-001', name: 'Severe FX devaluation', description: '20% INR depreciation against USD over 90 days.', type: 'Stress Test', category: 'Financial', shockMagnitude: 20, baselineLoss: 1200000, stressedLoss: 4800000, probability: 12, owner: 'CFO', lastRun: '2026-04-12' },
  { id: 'SC-002', name: 'Cloud region-wide outage', description: 'Primary AWS region offline for 24 hours.', type: 'What-if', category: 'IT & Cyber', shockMagnitude: 100, baselineLoss: 50000, stressedLoss: 920000, probability: 6, owner: 'CIO', lastRun: '2026-03-30' },
  { id: 'SC-003', name: 'Major customer concentration', description: 'Top-3 customer attrition within one quarter.', type: 'Tail Risk', category: 'Strategic', shockMagnitude: 30, baselineLoss: 0, stressedLoss: 6300000, probability: 4, owner: 'CEO', lastRun: '2026-02-15' },
  { id: 'SC-004', name: 'Regulatory penalty — data breach', description: 'Maximum statutory fine under GDPR.', type: 'Reverse Stress', category: 'Compliance', shockMagnitude: 4, baselineLoss: 0, stressedLoss: 20000000, probability: 2, owner: 'CCO' },
  { id: 'SC-005', name: 'Pandemic-style workforce loss', description: '25% of workforce unavailable for 6 weeks.', type: 'Stress Test', category: 'People', shockMagnitude: 25, baselineLoss: 0, stressedLoss: 2100000, probability: 8, owner: 'CHRO', lastRun: '2026-01-20' },
]

export const scenarioStore = createStore<Scenario>({ key: 'scenarios', seed: SEED })

export function ScenarioPage() {
  const items = useStoreSnapshot(scenarioStore)
  const { toast } = useToast()
  const confirm = useConfirm()
  const { hasPermission } = useAuth()
  const [editing, setEditing] = useState<Scenario | null>(null)

  const stats = useMemo(() => ({
    total: items.length,
    avgImpact: items.length ? Math.round(items.reduce((s, x) => s + (x.stressedLoss - x.baselineLoss), 0) / items.length) : 0,
    maxLoss: items.length ? Math.max(...items.map(x => x.stressedLoss)) : 0,
    runs: items.filter(x => x.lastRun).length,
  }), [items])

  const save = (s: Scenario) => {
    const isNew = !items.find(x => x.id === s.id)
    if (isNew) { scenarioStore.add(s); recordAudit({ action: 'CREATE', entity: 'Scenario', entity_id: s.id, description: `Created scenario ${s.name}`, after: s, result: 'SUCCESS' }); toast({ title: 'Scenario created' }) }
    else { scenarioStore.update(s.id, s); recordAudit({ action: 'UPDATE', entity: 'Scenario', entity_id: s.id, description: `Updated scenario ${s.name}`, after: s, result: 'SUCCESS' }); toast({ title: 'Scenario updated' }) }
    setEditing(null)
  }

  const remove = async (s: Scenario) => {
    const ok = await confirm({ title: `Delete ${s.id}?`, description: 'This action cannot be undone.', confirmLabel: 'Delete scenario', tone: 'danger' })
    if (!ok) return
    scenarioStore.remove(s.id)
    recordAudit({ action: 'DELETE', entity: 'Scenario', entity_id: s.id, description: `Deleted scenario ${s.name}`, before: s, result: 'SUCCESS' })
    toast({ title: 'Scenario deleted' })
  }

  const run = (s: Scenario) => {
    scenarioStore.update(s.id, { lastRun: new Date().toISOString().slice(0, 10) })
    recordAudit({ action: 'UPDATE', entity: 'Scenario', entity_id: s.id, description: `Ran scenario ${s.name}`, result: 'SUCCESS' })
    toast({ title: `Run complete`, description: `${s.name} executed.` })
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <TrendingUp className="w-4 h-4 text-primary" />
            <span className="text-[10px] font-black uppercase tracking-[0.3em] text-primary">Scenario Modelling</span>
          </div>
          <h1 className="text-3xl font-black tracking-tight">Scenario Analysis & Stress Testing</h1>
          <p className="text-muted-foreground mt-2 font-medium">Forward-looking stress tests across enterprise risk categories.</p>
        </div>
        {hasPermission('create') && <Button onClick={() => setEditing(blank())} className="rounded-2xl"><Plus className="w-4 h-4 mr-2" />New scenario</Button>}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Stat label="Total scenarios" value={stats.total} icon={TrendingUp} tone="blue" />
        <Stat label="Avg impact" value={`$${stats.avgImpact.toLocaleString()}`} icon={Activity} tone="amber" />
        <Stat label="Max stressed loss" value={`$${stats.maxLoss.toLocaleString()}`} icon={TrendingUp} tone="red" />
        <Stat label="Executed runs" value={stats.runs} icon={Play} tone="emerald" />
      </div>

      <div className="space-y-3">
        {items.map(s => (
          <Card key={s.id} className="p-5">
            <div className="flex items-start justify-between gap-4">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1 flex-wrap">
                  <code className="text-[10px] font-mono text-muted-foreground">{s.id}</code>
                  <Badge variant="outline" className="text-[9px] uppercase tracking-widest">{s.type}</Badge>
                  <Badge variant="outline" className="text-[9px] uppercase tracking-widest">{s.category}</Badge>
                </div>
                <h3 className="text-lg font-black">{s.name}</h3>
                <p className="text-[12px] text-muted-foreground mt-1">{s.description}</p>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-4">
                  <Metric label="Shock magnitude" value={`${s.shockMagnitude}%`} />
                  <Metric label="Baseline loss" value={`$${s.baselineLoss.toLocaleString()}`} />
                  <Metric label="Stressed loss" value={`$${s.stressedLoss.toLocaleString()}`} tone="red" />
                  <Metric label="Probability" value={`${s.probability}%`} />
                </div>
                <p className="text-[11px] text-muted-foreground mt-3">Owner: <span className="font-bold text-foreground">{s.owner}</span> · Last run: {s.lastRun || 'never'}</p>
              </div>
              <div className="flex items-center gap-1">
                {hasPermission('update') && <Button variant="outline" size="sm" onClick={() => run(s)}><Play className="w-3 h-3 mr-2" />Run</Button>}
                {hasPermission('update') && <Button variant="ghost" size="icon" onClick={() => setEditing(s)}><Pencil className="w-4 h-4" /></Button>}
                {hasPermission('delete') && <Button variant="ghost" size="icon" onClick={() => remove(s)} className="text-red-500 hover:bg-red-50"><Trash2 className="w-4 h-4" /></Button>}
              </div>
            </div>
          </Card>
        ))}
      </div>

      {editing && <ScEditor initial={editing} onCancel={() => setEditing(null)} onSave={save} />}
    </div>
  )
}

function blank(): Scenario {
  return { id: genId('SC'), name: '', description: '', type: 'Stress Test', category: 'Financial', shockMagnitude: 10, baselineLoss: 0, stressedLoss: 0, probability: 5, owner: '' }
}

function Stat({ label, value, icon: Icon, tone }: { label: string; value: number | string; icon: any; tone: 'blue' | 'emerald' | 'amber' | 'red' }) {
  const colorMap = { blue: 'text-blue-600 bg-blue-50', emerald: 'text-emerald-600 bg-emerald-50', amber: 'text-amber-600 bg-amber-50', red: 'text-red-600 bg-red-50' }[tone]
  return (
    <Card className="p-5 flex items-center gap-4">
      <div className={cn('w-12 h-12 rounded-2xl flex items-center justify-center', colorMap)}><Icon className="w-5 h-5" /></div>
      <div>
        <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">{label}</p>
        <p className="text-xl font-black tabular-nums text-foreground">{value}</p>
      </div>
    </Card>
  )
}

function Metric({ label, value, tone }: { label: string; value: string; tone?: 'red' }) {
  return (
    <div>
      <p className="text-[9px] font-black uppercase tracking-widest text-muted-foreground">{label}</p>
      <p className={cn('text-base font-black tabular-nums', tone === 'red' ? 'text-red-600' : 'text-foreground')}>{value}</p>
    </div>
  )
}

function ScEditor({ initial, onCancel, onSave }: { initial: Scenario; onCancel: () => void; onSave: (s: Scenario) => void }) {
  const [draft, setDraft] = useState<Scenario>(initial)
  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={onCancel}>
      <Card className="w-full max-w-2xl p-8 max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
        <h2 className="text-xl font-black mb-6">{initial.name ? 'Edit scenario' : 'New scenario'}</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <F label="Name" wide><Input value={draft.name} onChange={e => setDraft({ ...draft, name: e.target.value })} /></F>
          <F label="Description" wide><Input value={draft.description} onChange={e => setDraft({ ...draft, description: e.target.value })} /></F>
          <F label="Type">
            <select className="h-9 px-3 border border-border rounded-md text-sm w-full" value={draft.type} onChange={e => setDraft({ ...draft, type: e.target.value as Scenario['type'] })}>
              {['Stress Test', 'What-if', 'Reverse Stress', 'Tail Risk'].map(o => <option key={o}>{o}</option>)}
            </select>
          </F>
          <F label="Category"><Input value={draft.category} onChange={e => setDraft({ ...draft, category: e.target.value })} /></F>
          <F label="Shock magnitude (%)"><Input type="number" value={draft.shockMagnitude} onChange={e => setDraft({ ...draft, shockMagnitude: Number(e.target.value) })} /></F>
          <F label="Probability (%)"><Input type="number" min={1} max={100} value={draft.probability} onChange={e => setDraft({ ...draft, probability: Number(e.target.value) })} /></F>
          <F label="Baseline loss ($)"><Input type="number" value={draft.baselineLoss} onChange={e => setDraft({ ...draft, baselineLoss: Number(e.target.value) })} /></F>
          <F label="Stressed loss ($)"><Input type="number" value={draft.stressedLoss} onChange={e => setDraft({ ...draft, stressedLoss: Number(e.target.value) })} /></F>
          <F label="Owner"><Input value={draft.owner} onChange={e => setDraft({ ...draft, owner: e.target.value })} /></F>
        </div>
        <div className="flex justify-end gap-2 mt-6">
          <Button variant="ghost" onClick={onCancel}>Cancel</Button>
          <Button onClick={() => onSave(draft)}>Save</Button>
        </div>
      </Card>
    </div>
  )
}

function F({ label, children, wide }: { label: string; children: React.ReactNode; wide?: boolean }) {
  return (
    <div className={cn('space-y-1', wide && 'md:col-span-2')}>
      <label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">{label}</label>
      {children}
    </div>
  )
}
