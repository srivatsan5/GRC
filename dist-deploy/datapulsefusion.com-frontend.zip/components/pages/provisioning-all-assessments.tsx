'use client'

import React, { useMemo, useState } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card } from '@/components/ui/card'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Plus, ArrowRight, Loader2, Trash2, ChevronUp, ChevronDown, Search } from 'lucide-react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import * as z from 'zod'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import {
  useReactTable,
  getCoreRowModel,
  getSortedRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  flexRender,
  createColumnHelper,
  SortingState,
} from '@tanstack/react-table'
import { oracleService } from '@/lib/oracleService'
import { toast } from 'sonner'
import { recordAudit } from '@/lib/auditLog'
import { useConfirm } from '@/components/ui/confirm-dialog'
import { useAuth } from '@/components/providers/auth-provider'

const assessmentSchema = z.object({
  assessment_code: z.string(),
  department: z.string().min(1, 'Required'),
  estimated_start_date: z.string().min(1, 'Required'),
  estimated_end_date: z.string().min(1, 'Required'),
  status: z.string().min(1, 'Required'),
  risk_champion: z.string().min(2, 'Required').refine(v => !/^[bcdfghjklmnpqrstvwxyz]{6,}$/i.test(v), 'Looks like keyboard mash — please enter a real name'),
})

type AssessmentFormValues = z.infer<typeof assessmentSchema>

const DEPARTMENTS = ['Finance', 'Operations', 'Information Technology', 'Human Resources', 'Legal', 'Procurement', 'Marketing', 'Sales', 'Customer Service', 'Internal Audit', 'Compliance', 'Risk Management']

function isJunk(s: string | undefined | null) {
  if (!s) return false
  return /^[bcdfghjklmnpqrstvwxyz]{6,}$/i.test(s.trim()) || /^[^aeiouAEIOU\s\d]{8,}$/.test(s.trim())
}

function safeCode(code: string | undefined, fallbackId: string) {
  if (!code) return `RCSA-${fallbackId.slice(0, 6).toUpperCase()}`
  // Fix corrupted "-2026-002" style codes (no prefix)
  if (/^-\d{4}-\d+$/.test(code)) return `RCSA-DEFAULT${code}`
  return code
}

export function ProvisioningAllAssessmentsPage() {
  const router = useRouter()
  const queryClient = useQueryClient()
  const confirm = useConfirm()
  const { hasPermission, user } = useAuth()
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [globalFilter, setGlobalFilter] = useState('')
  const [sorting, setSorting] = useState<SortingState>([])

  const { data: assessments = [], isLoading } = useQuery({
    queryKey: ['assessments-list'],
    queryFn: () => oracleService.getIdentifyRisks(),
  })

  const sanitized = useMemo(() => assessments.filter((a: any) => !isJunk(a.risk_statement) && !isJunk(a.process_name)), [assessments])

  const { register, handleSubmit, reset, watch, setValue, formState: { errors } } = useForm<AssessmentFormValues>({
    resolver: zodResolver(assessmentSchema),
    defaultValues: {
      assessment_code: '',
      department: '',
      estimated_start_date: '',
      estimated_end_date: '',
      status: '',
      risk_champion: '',
    }
  })

  const watchDepartment = watch('department')

  React.useEffect(() => {
    const deptCode = (watchDepartment || '').split(' ').map(w => w[0]).join('').toUpperCase().substring(0, 3) || 'GEN'
    const yyyymm = new Date().toISOString().slice(0, 7).replace('-', '')
    const seq = Math.floor(100 + Math.random() * 900)
    setValue('assessment_code', `RCSA-${deptCode}-${yyyymm}-${seq}`)
  }, [watchDepartment, setValue])

  const createMutation = useMutation({
    mutationFn: (data: any) => oracleService.createIdentifyRisk({
      assessment_reference_number: data.assessment_code,
      process_name: data.department,
      start_date: new Date(data.estimated_start_date).toISOString(),
      end_date: new Date(data.estimated_end_date).toISOString(),
      risk_statement: `RCSA cycle for ${data.department}`,
      assessment_registered_date: new Date().toISOString(),
      is_stage_complted: data.status === 'Completed' ? 'Y' : 'N',
      hierarchy_level: 3,
      status: data.status === 'In Progress' ? 'Y' : 'N',
      risk_champion: data.risk_champion,
      approval_status: 'DRAFT',
    }),
    onSuccess: (result: any) => {
      queryClient.invalidateQueries({ queryKey: ['assessments-list'] })
      recordAudit({ action: 'CREATE', entity: 'Assessment', entity_id: result?.uuid || result?.id, description: `Created RCSA cycle for ${watch('department')}`, after: result, result: 'SUCCESS' })
      toast.success('Assessment created')
      setIsDialogOpen(false)
      reset()
    },
    onError: (err: any) => {
      recordAudit({ action: 'CREATE', entity: 'Assessment', description: `Failed to create assessment: ${err.message}`, result: 'FAILURE' })
      toast.error(`Failed to create assessment: ${err.message}`)
    },
  })

  const deleteMutation = useMutation({
    mutationFn: (id: string | number) => oracleService.deleteIdentifyRisk(id),
    onSuccess: (_, id) => {
      queryClient.invalidateQueries({ queryKey: ['assessments-list'] })
      recordAudit({ action: 'DELETE', entity: 'Assessment', entity_id: id, description: `Deleted assessment ${id}`, result: 'SUCCESS' })
      toast.success('Assessment deleted')
    },
    onError: (err: any, id) => {
      recordAudit({ action: 'DELETE', entity: 'Assessment', entity_id: id, description: `Failed to delete: ${err.message}`, result: 'FAILURE' })
      toast.error(`Failed to delete: ${err.message}`)
    },
  })

  const handleDelete = async (id: string, code: string) => {
    const ok = await confirm({
      title: `Delete ${code}?`,
      description: 'This will permanently delete the assessment and all associated risks. This action cannot be undone.',
      confirmLabel: 'Delete assessment',
      tone: 'danger',
    })
    if (!ok) return
    deleteMutation.mutate(id)
  }

  const onSubmit = (data: AssessmentFormValues) => {
    createMutation.mutate(data)
  }

  const columnHelper = createColumnHelper<any>()
  const columns = useMemo(() => [
    columnHelper.accessor('assessment_reference_number', {
      header: 'Code',
      cell: info => <span className="font-mono text-[12px] font-bold">{safeCode(info.getValue(), String(info.row.original.uuid || ''))}</span>,
    }),
    columnHelper.accessor((row: any) => row.process_name || row.risk_statement || '—', {
      id: 'department',
      header: 'Department',
      cell: info => <span>{info.getValue() as string}</span>,
    }),
    columnHelper.accessor('start_date', {
      header: 'Start',
      cell: info => info.getValue() ? new Date(info.getValue() as string).toLocaleDateString() : '—',
    }),
    columnHelper.accessor('end_date', {
      header: 'End',
      cell: info => info.getValue() ? new Date(info.getValue() as string).toLocaleDateString() : '—',
    }),
    columnHelper.accessor((row: any) => row.is_stage_complted === 'Y' ? 'Completed' : row.status === 'Y' ? 'In Progress' : 'Draft', {
      id: 'status',
      header: 'Status',
      cell: info => {
        const v = info.getValue() as string
        return (
          <span className={`px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-widest border ${v === 'Completed' ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : v === 'In Progress' ? 'bg-blue-50 text-blue-700 border-blue-200' : 'bg-amber-50 text-amber-700 border-amber-200'}`}>{v}</span>
        )
      },
    }),
    columnHelper.accessor((row: any) => row.risk_champion || row.risk_owner || '—', {
      id: 'risk_champion',
      header: 'Risk Champion',
      cell: info => <span className="text-[12px]">{info.getValue() as string}</span>,
    }),
    columnHelper.display({
      id: 'actions',
      header: '',
      cell: ({ row }) => (
        <div className="flex items-center justify-end gap-2">
          {hasPermission('delete') && (
            <Button variant="ghost" size="icon" className="text-destructive hover:bg-red-50" onClick={() => handleDelete(row.original.uuid, row.original.assessment_reference_number || row.original.uuid)} disabled={deleteMutation.isPending}>
              <Trash2 className="w-4 h-4" />
            </Button>
          )}
          <Button size="sm" onClick={() => router.push(`/rcsa/provisioning/${row.original.uuid}`)}>
            Details <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      ),
    }),
  ], [router, deleteMutation.isPending, hasPermission])

  const table = useReactTable({
    data: sanitized,
    columns,
    state: { globalFilter, sorting },
    onGlobalFilterChange: setGlobalFilter,
    onSortingChange: setSorting,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    initialState: { pagination: { pageSize: 10 } },
  })

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto p-8 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-black tracking-tight">Assessment Setup</h1>
            <p className="text-sm text-muted-foreground mt-1">All RCSA assessment cycles · {sanitized.length} record{sanitized.length === 1 ? '' : 's'}{sanitized.length !== assessments.length ? ` (${assessments.length - sanitized.length} junk records filtered)` : ''}</p>
          </div>
          {hasPermission('create') && (
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button><Plus className="w-4 h-4 mr-2" />New Assessment</Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>New Assessment</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Assessment Code (auto-generated)</label>
                    <Input {...register('assessment_code')} readOnly className="bg-muted" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Department</label>
                    <select {...register('department')} className="w-full h-10 px-3 border rounded-md">
                      <option value="">Select department</option>
                      {DEPARTMENTS.map(d => <option key={d} value={d}>{d}</option>)}
                    </select>
                    {errors.department && <span className="text-xs text-destructive">{errors.department.message}</span>}
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-1">Estimated Start Date</label>
                      <Input type="date" {...register('estimated_start_date')} />
                      {errors.estimated_start_date && <span className="text-xs text-destructive">{errors.estimated_start_date.message}</span>}
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">Estimated End Date</label>
                      <Input type="date" {...register('estimated_end_date')} />
                      {errors.estimated_end_date && <span className="text-xs text-destructive">{errors.estimated_end_date.message}</span>}
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Status</label>
                    <select {...register('status')} className="w-full h-10 px-3 border rounded-md">
                      <option value="">Select status</option>
                      <option value="Draft">Draft</option>
                      <option value="In Progress">In Progress</option>
                      <option value="Completed">Completed</option>
                    </select>
                    {errors.status && <span className="text-xs text-destructive">{errors.status.message}</span>}
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Risk Champion</label>
                    <Input {...register('risk_champion')} placeholder="Enter risk champion name" defaultValue={user?.name || ''} />
                    {errors.risk_champion && <span className="text-xs text-destructive">{errors.risk_champion.message}</span>}
                  </div>
                  <div className="flex justify-end gap-2 pt-4">
                    <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
                    <Button type="submit" disabled={createMutation.isPending}>
                      {createMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                      {createMutation.isPending ? 'Saving…' : 'Save'}
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          )}
        </div>

        <Card className="p-4">
          <div className="relative max-w-sm">
            <Search className="absolute left-3 top-2.5 w-4 h-4 text-muted-foreground" />
            <Input placeholder="Search assessments…" value={globalFilter} onChange={e => setGlobalFilter(e.target.value)} className="pl-9" />
          </div>
        </Card>

        <Card className="overflow-hidden">
          <table className="w-full">
            <thead className="bg-muted/50">
              {table.getHeaderGroups().map(hg => (
                <tr key={hg.id}>
                  {hg.headers.map(h => {
                    const sorted = h.column.getIsSorted()
                    return (
                      <th key={h.id} className="text-left p-4 font-bold text-[11px] uppercase tracking-widest text-muted-foreground">
                        <button onClick={h.column.getToggleSortingHandler()} className="flex items-center gap-1 hover:text-foreground">
                          {flexRender(h.column.columnDef.header, h.getContext())}
                          {sorted === 'asc' ? <ChevronUp className="w-3 h-3" /> : sorted === 'desc' ? <ChevronDown className="w-3 h-3" /> : null}
                        </button>
                      </th>
                    )
                  })}
                </tr>
              ))}
            </thead>
            <tbody>
              {isLoading ? (
                <tr><td colSpan={7} className="p-8 text-center"><Loader2 className="w-6 h-6 animate-spin mx-auto" /></td></tr>
              ) : table.getRowModel().rows.length === 0 ? (
                <tr><td colSpan={7} className="p-8 text-center text-muted-foreground italic">No assessments found.</td></tr>
              ) : (
                table.getRowModel().rows.map(row => (
                  <tr key={row.id} className="border-t hover:bg-secondary/20">
                    {row.getVisibleCells().map(cell => (
                      <td key={cell.id} className="p-4">{flexRender(cell.column.columnDef.cell, cell.getContext())}</td>
                    ))}
                  </tr>
                ))
              )}
            </tbody>
          </table>

          <div className="flex items-center justify-between p-4 border-t bg-muted/20">
            <span className="text-[11px] font-bold text-muted-foreground">
              Page {table.getState().pagination.pageIndex + 1} of {table.getPageCount() || 1} · {sanitized.length} total
            </span>
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="sm" onClick={() => table.previousPage()} disabled={!table.getCanPreviousPage()}>Previous</Button>
              <Button variant="ghost" size="sm" onClick={() => table.nextPage()} disabled={!table.getCanNextPage()}>Next</Button>
            </div>
          </div>
        </Card>
      </div>
    </div>
  )
}
