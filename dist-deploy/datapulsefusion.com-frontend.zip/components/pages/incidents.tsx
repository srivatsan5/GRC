'use client'

import React, { useMemo, useState } from 'react'
import { AlertOctagon, Plus, Trash2, Pencil, Activity, ShieldCheck, Clock } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'
import { createStore, useStoreSnapshot, genId } from '@/lib/localStore'
import { useToast } from '@/hooks/use-toast'
import { recordAudit } from '@/lib/auditLog'
import { useConfirm } from '@/components/ui/confirm-dialog'
import { useAuth } from '@/components/providers/auth-provider'

export type IncidentSeverity = 'Critical' | 'High' | 'Medium' | 'Low'
export type IncidentStatus = 'Open' | 'Investigating' | 'Mitigated' | 'Closed'

export interface Incident {
  id: string
  title: string
  description: string
  severity: IncidentSeverity
  status: IncidentStatus
  category: string
  reportedBy: string
  assignedTo: string
  reportedOn: string
  closedOn?: string
  linkedRisks: string[]
  rootCause?: string
  correctiveAction?: string
}

const SEED: Incident[] = [
  { id: 'INC-001', title: 'Brief access outage to payment gateway', description: 'Payment API returned 503 for ~12 minutes during EU peak.', severity: 'High', status: 'Mitigated', category: 'IT & Cyber', reportedBy: 'Anthony Muller', assignedTo: 'IT Operations', reportedOn: '2026-05-10', closedOn: '2026-05-10', linkedRisks: ['R-009'], rootCause: 'Auto-scaling lag during marketing campaign spike.', correctiveAction: 'Pre-warm capacity ahead of scheduled campaigns.' },
  { id: 'INC-002', title: 'Phishing campaign targeting finance team', description: 'Six employees received spear-phishing emails. None clicked.', severity: 'Medium', status: 'Closed', category: 'IT & Cyber', reportedBy: 'Lin Wei', assignedTo: 'IT Security', reportedOn: '2026-05-03', closedOn: '2026-05-07', linkedRisks: ['R-014'], rootCause: 'Targeted social engineering after vendor data leak.', correctiveAction: 'Re-issued phishing simulation and updated email filters.' },
  { id: 'INC-003', title: 'Missing daily reconciliation report', description: 'Treasury report not generated on 2026-05-08 due to ETL failure.', severity: 'Medium', status: 'Investigating', category: 'Financial', reportedBy: 'Priya Sharma', assignedTo: 'Data Engineering', reportedOn: '2026-05-08', linkedRisks: ['R-003'] },
  { id: 'INC-004', title: 'Vendor V-0005 data breach notification', description: 'Apex HR Outsourcing reported a contained breach affecting 1,200 records.', severity: 'Critical', status: 'Open', category: 'Vendor', reportedBy: 'Priya Sharma', assignedTo: 'CISO', reportedOn: '2026-05-15', linkedRisks: ['R-018'] },
  { id: 'INC-005', title: 'Office HVAC outage caused early closure', description: 'Mumbai office closed 4 hours early due to HVAC failure.', severity: 'Low', status: 'Closed', category: 'Operations', reportedBy: 'Anthony Muller', assignedTo: 'Facilities', reportedOn: '2026-04-22', closedOn: '2026-04-23', linkedRisks: ['R-024'], rootCause: 'Aging compressor.', correctiveAction: 'Scheduled replacement Q3 2026.' },
]

export const incidentStore = createStore<Incident>({ key: 'incidents', seed: SEED })

const SEVERITY_TONE: Record<IncidentSeverity, string> = {
  Critical: 'bg-red-50 text-red-700 border-red-200',
  High: 'bg-orange-50 text-orange-700 border-orange-200',
  Medium: 'bg-amber-50 text-amber-700 border-amber-200',
  Low: 'bg-blue-50 text-blue-700 border-blue-200',
}

const STATUS_TONE: Record<IncidentStatus, string> = {
  Open: 'bg-red-50 text-red-700 border-red-200',
  Investigating: 'bg-amber-50 text-amber-700 border-amber-200',
  Mitigated: 'bg-blue-50 text-blue-700 border-blue-200',
  Closed: 'bg-emerald-50 text-emerald-700 border-emerald-200',
}

export function IncidentsPage() {
  const items = useStoreSnapshot(incidentStore)
  const { toast } = useToast()
  const confirm = useConfirm()
  const { hasPermission } = useAuth()
  const [editing, setEditing] = useState<Incident | null>(null)
  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState<'All' | IncidentStatus>('All')

  const filtered = useMemo(() => items.filter(i => {
    if (statusFilter !== 'All' && i.status !== statusFilter) return false
    if (search && !`${i.title} ${i.category} ${i.id} ${i.assignedTo}`.toLowerCase().includes(search.toLowerCase())) return false
    return true
  }), [items, search, statusFilter])

  const stats = useMemo(() => ({
    open: items.filter(i => i.status === 'Open' || i.status === 'Investigating').length,
    critical: items.filter(i => i.severity === 'Critical').length,
    mttrDays: 1.6,
    closedThisQuarter: items.filter(i => i.status === 'Closed').length,
  }), [items])

  const save = (i: Incident) => {
    const isNew = !items.find(x => x.id === i.id)
    if (isNew) {
      incidentStore.add(i)
      recordAudit({ action: 'CREATE', entity: 'Incident', entity_id: i.id, description: `Reported incident: ${i.title}`, after: i, result: 'SUCCESS' })
      toast({ title: 'Incident reported' })
    } else {
      incidentStore.update(i.id, i)
      recordAudit({ action: 'UPDATE', entity: 'Incident', entity_id: i.id, description: `Updated incident: ${i.title}`, after: i, result: 'SUCCESS' })
      toast({ title: 'Incident updated' })
    }
    setEditing(null)
  }

  const remove = async (i: Incident) => {
    const ok = await confirm({ title: `Delete ${i.id}?`, description: 'This will permanently remove the incident record. This action cannot be undone.', confirmLabel: 'Delete incident', tone: 'danger' })
    if (!ok) return
    incidentStore.remove(i.id)
    recordAudit({ action: 'DELETE', entity: 'Incident', entity_id: i.id, description: `Deleted incident: ${i.title}`, before: i, result: 'SUCCESS' })
    toast({ title: 'Incident deleted' })
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <AlertOctagon className="w-4 h-4 text-primary" />
            <span className="text-[10px] font-black uppercase tracking-[0.3em] text-primary">Incident Tracking</span>
          </div>
          <h1 className="text-3xl font-black tracking-tight">Incident Management</h1>
          <p className="text-muted-foreground mt-2 font-medium">Capture, investigate, and close incidents linked to enterprise risks.</p>
        </div>
        {hasPermission('create') && <Button onClick={() => setEditing(blank())} className="rounded-2xl"><Plus className="w-4 h-4 mr-2" />Report incident</Button>}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Stat label="Open incidents" value={stats.open} icon={AlertOctagon} tone="red" />
        <Stat label="Critical severity" value={stats.critical} icon={Activity} tone="amber" />
        <Stat label="MTTR (days)" value={stats.mttrDays} icon={Clock} tone="blue" />
        <Stat label="Closed" value={stats.closedThisQuarter} icon={ShieldCheck} tone="emerald" />
      </div>

      <Card className="p-4">
        <div className="flex flex-col md:flex-row gap-3 items-stretch">
          <Input placeholder="Search incidents…" value={search} onChange={e => setSearch(e.target.value)} className="md:max-w-sm" />
          <div className="flex items-center gap-2">
            {(['All', 'Open', 'Investigating', 'Mitigated', 'Closed'] as const).map(s => (
              <Button key={s} variant={statusFilter === s ? 'primary' : 'ghost'} size="sm" onClick={() => setStatusFilter(s)}>{s}</Button>
            ))}
          </div>
        </div>
      </Card>

      <div className="space-y-3">
        {filtered.map(i => (
          <Card key={i.id} className="p-5">
            <div className="flex items-start justify-between gap-4">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1 flex-wrap">
                  <code className="text-[10px] font-mono text-muted-foreground">{i.id}</code>
                  <span className={cn('px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-widest border', SEVERITY_TONE[i.severity])}>{i.severity}</span>
                  <span className={cn('px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-widest border', STATUS_TONE[i.status])}>{i.status}</span>
                  <Badge variant="outline" className="text-[9px] uppercase tracking-widest">{i.category}</Badge>
                </div>
                <h3 className="text-lg font-black">{i.title}</h3>
                <p className="text-[12px] text-muted-foreground mt-1">{i.description}</p>
                <div className="flex flex-wrap gap-x-6 gap-y-1 text-[11px] mt-2 text-muted-foreground">
                  <span>Reported by <span className="font-bold text-foreground">{i.reportedBy}</span> on {i.reportedOn}</span>
                  <span>Assigned to <span className="font-bold text-foreground">{i.assignedTo}</span></span>
                  {i.closedOn && <span>Closed on <span className="font-bold text-foreground">{i.closedOn}</span></span>}
                </div>
                {i.rootCause && <p className="text-[11px] mt-2"><span className="font-black uppercase tracking-widest text-muted-foreground">Root cause:</span> {i.rootCause}</p>}
                {i.correctiveAction && <p className="text-[11px] mt-1"><span className="font-black uppercase tracking-widest text-muted-foreground">Action:</span> {i.correctiveAction}</p>}
              </div>
              <div className="flex items-center gap-1">
                {hasPermission('update') && <Button variant="ghost" size="icon" onClick={() => setEditing(i)}><Pencil className="w-4 h-4" /></Button>}
                {hasPermission('delete') && <Button variant="ghost" size="icon" onClick={() => remove(i)} className="text-red-500 hover:bg-red-50"><Trash2 className="w-4 h-4" /></Button>}
              </div>
            </div>
          </Card>
        ))}
        {filtered.length === 0 && <Card className="p-12 text-center text-muted-foreground italic">No incidents match.</Card>}
      </div>

      {editing && <IncidentEditor initial={editing} onCancel={() => setEditing(null)} onSave={save} />}
    </div>
  )
}

function blank(): Incident {
  return { id: genId('INC'), title: '', description: '', severity: 'Medium', status: 'Open', category: 'Operations', reportedBy: '', assignedTo: '', reportedOn: new Date().toISOString().slice(0, 10), linkedRisks: [] }
}

function Stat({ label, value, icon: Icon, tone }: { label: string; value: number; icon: any; tone: 'blue' | 'emerald' | 'amber' | 'red' }) {
  const colorMap = { blue: 'text-blue-600 bg-blue-50', emerald: 'text-emerald-600 bg-emerald-50', amber: 'text-amber-600 bg-amber-50', red: 'text-red-600 bg-red-50' }[tone]
  return (
    <Card className="p-5 flex items-center gap-4">
      <div className={cn('w-12 h-12 rounded-2xl flex items-center justify-center', colorMap)}><Icon className="w-5 h-5" /></div>
      <div>
        <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">{label}</p>
        <p className="text-2xl font-black tabular-nums text-foreground">{value}</p>
      </div>
    </Card>
  )
}

function IncidentEditor({ initial, onCancel, onSave }: { initial: Incident; onCancel: () => void; onSave: (i: Incident) => void }) {
  const [draft, setDraft] = useState<Incident>(initial)
  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={onCancel}>
      <Card className="w-full max-w-2xl p-8 max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
        <h2 className="text-xl font-black mb-6">{initial.title ? 'Edit incident' : 'Report incident'}</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <F label="Title" wide><Input value={draft.title} onChange={e => setDraft({ ...draft, title: e.target.value })} /></F>
          <F label="Description" wide><Input value={draft.description} onChange={e => setDraft({ ...draft, description: e.target.value })} /></F>
          <F label="Severity">
            <select className="h-9 px-3 border border-border rounded-md text-sm w-full" value={draft.severity} onChange={e => setDraft({ ...draft, severity: e.target.value as IncidentSeverity })}>
              {['Critical', 'High', 'Medium', 'Low'].map(o => <option key={o}>{o}</option>)}
            </select>
          </F>
          <F label="Status">
            <select className="h-9 px-3 border border-border rounded-md text-sm w-full" value={draft.status} onChange={e => setDraft({ ...draft, status: e.target.value as IncidentStatus })}>
              {['Open', 'Investigating', 'Mitigated', 'Closed'].map(o => <option key={o}>{o}</option>)}
            </select>
          </F>
          <F label="Category"><Input value={draft.category} onChange={e => setDraft({ ...draft, category: e.target.value })} /></F>
          <F label="Reported on"><Input type="date" value={draft.reportedOn} onChange={e => setDraft({ ...draft, reportedOn: e.target.value })} /></F>
          <F label="Reported by"><Input value={draft.reportedBy} onChange={e => setDraft({ ...draft, reportedBy: e.target.value })} /></F>
          <F label="Assigned to"><Input value={draft.assignedTo} onChange={e => setDraft({ ...draft, assignedTo: e.target.value })} /></F>
          <F label="Root cause" wide><Input value={draft.rootCause || ''} onChange={e => setDraft({ ...draft, rootCause: e.target.value })} /></F>
          <F label="Corrective action" wide><Input value={draft.correctiveAction || ''} onChange={e => setDraft({ ...draft, correctiveAction: e.target.value })} /></F>
        </div>
        <div className="flex justify-end gap-2 mt-6">
          <Button variant="ghost" onClick={onCancel}>Cancel</Button>
          <Button onClick={() => onSave(draft)}>Save</Button>
        </div>
      </Card>
    </div>
  )
}

function F({ label, children, wide }: { label: string; children: React.ReactNode; wide?: boolean }) {
  return (
    <div className={cn('space-y-1', wide && 'md:col-span-2')}>
      <label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">{label}</label>
      {children}
    </div>
  )
}
