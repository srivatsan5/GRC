'use client'

import React, { useMemo, useState } from 'react'
import { Layers, CheckCircle2, Clock, XCircle, Plus, ArrowRight, GitBranch } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'
import { createStore, useStoreSnapshot, genId } from '@/lib/localStore'
import { useToast } from '@/hooks/use-toast'
import { recordAudit } from '@/lib/auditLog'
import { useAuth } from '@/components/providers/auth-provider'

export type WorkflowStatus = 'Pending' | 'In Review' | 'Approved' | 'Rejected'

export interface WorkflowItem {
  id: string
  title: string
  type: 'Risk Assessment' | 'Mitigation Plan' | 'Control Change' | 'Policy Update' | 'Risk Acceptance'
  submittedBy: string
  submittedOn: string
  approvers: { name: string; role: string; decision?: 'Approved' | 'Rejected'; on?: string; comment?: string }[]
  status: WorkflowStatus
  amount?: number
  business: string
}

const SEED: WorkflowItem[] = [
  { id: 'WF-001', title: 'Q1 IT Risk Assessment Sign-off', type: 'Risk Assessment', submittedBy: 'Anthony Muller', submittedOn: '2026-05-12', approvers: [{ name: 'Priya Sharma', role: 'Risk Manager', decision: 'Approved', on: '2026-05-13' }, { name: 'Srivatsan B', role: 'Administrator' }], status: 'In Review', business: 'IT' },
  { id: 'WF-002', title: 'Mitigation plan — Data Loss Prevention', type: 'Mitigation Plan', submittedBy: 'Anthony Muller', submittedOn: '2026-05-10', approvers: [{ name: 'Priya Sharma', role: 'Risk Manager' }], status: 'Pending', business: 'IT', amount: 245000 },
  { id: 'WF-003', title: 'Policy update — Acceptable Use v3.2', type: 'Policy Update', submittedBy: 'Lin Wei', submittedOn: '2026-05-08', approvers: [{ name: 'Priya Sharma', role: 'Risk Manager', decision: 'Approved', on: '2026-05-09' }, { name: 'Srivatsan B', role: 'Administrator', decision: 'Approved', on: '2026-05-10' }], status: 'Approved', business: 'HR' },
  { id: 'WF-004', title: 'Risk acceptance — Vendor V-0042', type: 'Risk Acceptance', submittedBy: 'Priya Sharma', submittedOn: '2026-05-05', approvers: [{ name: 'Srivatsan B', role: 'Administrator', decision: 'Rejected', on: '2026-05-06', comment: 'Need additional compensating controls' }], status: 'Rejected', business: 'Procurement' },
  { id: 'WF-005', title: 'Control change — MFA grace period', type: 'Control Change', submittedBy: 'Anthony Muller', submittedOn: '2026-05-15', approvers: [{ name: 'Priya Sharma', role: 'Risk Manager' }, { name: 'Srivatsan B', role: 'Administrator' }], status: 'Pending', business: 'IT' },
]

export const workflowStore = createStore<WorkflowItem>({ key: 'workflow', seed: SEED })

const STATUS_TONE: Record<WorkflowStatus, string> = {
  Pending: 'bg-amber-50 text-amber-700 border-amber-200',
  'In Review': 'bg-blue-50 text-blue-700 border-blue-200',
  Approved: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  Rejected: 'bg-red-50 text-red-700 border-red-200',
}

export function WorkflowPage() {
  const items = useStoreSnapshot(workflowStore)
  const { toast } = useToast()
  const { hasPermission, user } = useAuth()
  const [filter, setFilter] = useState<'All' | WorkflowStatus>('All')
  const [adding, setAdding] = useState(false)
  const [draft, setDraft] = useState<Partial<WorkflowItem>>({ type: 'Risk Assessment', business: 'IT' })

  const filtered = useMemo(() => filter === 'All' ? items : items.filter(i => i.status === filter), [items, filter])

  const stats = useMemo(() => ({
    pending: items.filter(i => i.status === 'Pending' || i.status === 'In Review').length,
    approved: items.filter(i => i.status === 'Approved').length,
    rejected: items.filter(i => i.status === 'Rejected').length,
    avgCycle: 1.8,
  }), [items])

  const decide = (id: string, decision: 'Approved' | 'Rejected') => {
    const it = items.find(x => x.id === id)
    if (!it) return
    const idx = it.approvers.findIndex(a => !a.decision)
    if (idx === -1) return
    const updated = { ...it }
    updated.approvers = [...it.approvers]
    updated.approvers[idx] = {
      ...updated.approvers[idx],
      name: user?.name || updated.approvers[idx].name,
      role: user?.role || updated.approvers[idx].role,
      decision,
      on: new Date().toISOString().slice(0, 10),
    }
    const allApproved = updated.approvers.every(a => a.decision === 'Approved')
    const anyReject = updated.approvers.some(a => a.decision === 'Rejected')
    updated.status = anyReject ? 'Rejected' : allApproved ? 'Approved' : 'In Review'
    workflowStore.update(id, updated)
    recordAudit({ action: decision === 'Approved' ? 'APPROVE' : 'REJECT', entity: 'Workflow', entity_id: id, description: `${decision} – ${it.title}`, after: updated, result: 'SUCCESS' })
    toast({ title: `${decision}`, description: it.title })
  }

  const submit = () => {
    if (!draft.title || !draft.type || !draft.business) return
    const item: WorkflowItem = {
      id: genId('WF'),
      title: draft.title!,
      type: draft.type as WorkflowItem['type'],
      submittedBy: user?.name || 'Unknown',
      submittedOn: new Date().toISOString().slice(0, 10),
      approvers: [{ name: 'Priya Sharma', role: 'Risk Manager' }, { name: 'Srivatsan B', role: 'Administrator' }],
      status: 'Pending',
      business: draft.business!,
    }
    workflowStore.add(item)
    recordAudit({ action: 'CREATE', entity: 'Workflow', entity_id: item.id, description: `Submitted ${item.type}: ${item.title}`, after: item, result: 'SUCCESS' })
    toast({ title: 'Submitted for approval', description: item.title })
    setAdding(false)
    setDraft({ type: 'Risk Assessment', business: 'IT' })
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <GitBranch className="w-4 h-4 text-primary" />
            <span className="text-[10px] font-black uppercase tracking-[0.3em] text-primary">Approval Workflow</span>
          </div>
          <h1 className="text-3xl font-black tracking-tight">Workflow & Approvals</h1>
          <p className="text-muted-foreground mt-2 font-medium">Multi-step approvals with maker–checker discipline.</p>
        </div>
        {hasPermission('create') && <Button onClick={() => setAdding(true)} className="rounded-2xl"><Plus className="w-4 h-4 mr-2" />Submit for approval</Button>}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Stat label="Pending decisions" value={stats.pending} icon={Clock} tone="amber" />
        <Stat label="Approved" value={stats.approved} icon={CheckCircle2} tone="emerald" />
        <Stat label="Rejected" value={stats.rejected} icon={XCircle} tone="red" />
        <Stat label="Avg cycle (days)" value={stats.avgCycle} icon={Layers} tone="blue" />
      </div>

      <div className="flex items-center gap-2">
        {(['All', 'Pending', 'In Review', 'Approved', 'Rejected'] as const).map(s => (
          <Button key={s} variant={filter === s ? 'primary' : 'ghost'} size="sm" onClick={() => setFilter(s)}>{s}</Button>
        ))}
      </div>

      <div className="space-y-3">
        {filtered.map(it => {
          const canAct = hasPermission('admin') || (hasPermission('update') && user && it.approvers.some(a => !a.decision && a.name === user.name))
          return (
            <Card key={it.id} className="p-5">
              <div className="flex items-start justify-between gap-4 mb-3">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <code className="text-[10px] font-mono text-muted-foreground">{it.id}</code>
                    <Badge variant="outline" className="text-[9px] uppercase tracking-widest">{it.type}</Badge>
                    <Badge variant="outline" className="text-[9px] uppercase tracking-widest">{it.business}</Badge>
                  </div>
                  <h3 className="text-lg font-black">{it.title}</h3>
                  <p className="text-[11px] text-muted-foreground">Submitted by <span className="font-bold">{it.submittedBy}</span> on {it.submittedOn}</p>
                </div>
                <span className={cn('px-3 py-1 rounded-full border text-[10px] font-black uppercase tracking-widest h-fit', STATUS_TONE[it.status])}>
                  {it.status}
                </span>
              </div>

              <div className="flex items-center gap-2 flex-wrap">
                {it.approvers.map((a, i) => (
                  <React.Fragment key={i}>
                    <div className={cn(
                      'flex items-center gap-2 px-3 py-1.5 rounded-full border text-[11px]',
                      a.decision === 'Approved' && 'bg-emerald-50 text-emerald-700 border-emerald-200',
                      a.decision === 'Rejected' && 'bg-red-50 text-red-700 border-red-200',
                      !a.decision && 'bg-muted text-muted-foreground border-border'
                    )}>
                      <div className="w-5 h-5 rounded-full bg-white border flex items-center justify-center text-[9px] font-black">{a.name.split(' ').map(p => p[0]).slice(0, 2).join('').toUpperCase()}</div>
                      <span className="font-bold">{a.name}</span>
                      <span className="opacity-60">· {a.role}</span>
                      {a.decision && <span className="text-[9px] uppercase tracking-widest">· {a.decision} {a.on}</span>}
                    </div>
                    {i < it.approvers.length - 1 && <ArrowRight className="w-3 h-3 text-muted-foreground" />}
                  </React.Fragment>
                ))}

                {canAct && it.status !== 'Approved' && it.status !== 'Rejected' && (
                  <div className="ml-auto flex gap-2">
                    <Button size="sm" variant="outline" onClick={() => decide(it.id, 'Rejected')} className="text-red-600 hover:bg-red-50">Reject</Button>
                    <Button size="sm" onClick={() => decide(it.id, 'Approved')}>Approve</Button>
                  </div>
                )}
              </div>
            </Card>
          )
        })}
        {filtered.length === 0 && <Card className="p-12 text-center text-muted-foreground italic">No workflow items match.</Card>}
      </div>

      {adding && (
        <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={() => setAdding(false)}>
          <Card className="w-full max-w-lg p-8" onClick={e => e.stopPropagation()}>
            <h2 className="text-xl font-black mb-6">Submit for approval</h2>
            <div className="space-y-4">
              <div>
                <label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Title</label>
                <Input value={draft.title || ''} onChange={e => setDraft({ ...draft, title: e.target.value })} />
              </div>
              <div>
                <label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Type</label>
                <select className="w-full h-9 px-3 border border-border rounded-md text-sm" value={draft.type} onChange={e => setDraft({ ...draft, type: e.target.value as WorkflowItem['type'] })}>
                  {['Risk Assessment', 'Mitigation Plan', 'Control Change', 'Policy Update', 'Risk Acceptance'].map(o => <option key={o}>{o}</option>)}
                </select>
              </div>
              <div>
                <label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Business unit</label>
                <Input value={draft.business || ''} onChange={e => setDraft({ ...draft, business: e.target.value })} />
              </div>
            </div>
            <div className="flex justify-end gap-2 mt-6">
              <Button variant="ghost" onClick={() => setAdding(false)}>Cancel</Button>
              <Button onClick={submit}>Submit</Button>
            </div>
          </Card>
        </div>
      )}
    </div>
  )
}

function Stat({ label, value, icon: Icon, tone }: { label: string; value: number | string; icon: any; tone: 'blue' | 'emerald' | 'amber' | 'red' }) {
  const colorMap = { blue: 'text-blue-600 bg-blue-50', emerald: 'text-emerald-600 bg-emerald-50', amber: 'text-amber-600 bg-amber-50', red: 'text-red-600 bg-red-50' }[tone]
  return (
    <Card className="p-5 flex items-center gap-4">
      <div className={cn('w-12 h-12 rounded-2xl flex items-center justify-center', colorMap)}><Icon className="w-5 h-5" /></div>
      <div>
        <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">{label}</p>
        <p className="text-2xl font-black tabular-nums text-foreground">{value}</p>
      </div>
    </Card>
  )
}
