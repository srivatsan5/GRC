'use client'

import * as React from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { cn } from '@/lib/utils'
import { AnimatePresence, motion } from 'framer-motion'
import {
  LayoutDashboard,
  Shield,
  Eye,
  BarChart3,
  History,
  Settings,
  ChevronDown,
  Activity,
  LogOut,
  Zap,
  X,
  ClipboardCheck,
  Layers,
  Users,
  Target,
  AlertOctagon,
  Briefcase,
  FileText,
  GitBranch,
  TrendingUp,
  BookOpen,
  ShieldAlert
} from 'lucide-react'
import { useAuth } from '@/components/providers/auth-provider'
import { useSidebar } from './pericope-layout'

const navigationItems = [
  {
    group: 'CORE',
    items: [
      { name: 'Dashboard', href: '/dashboard', icon: LayoutDashboard },
    ]
  },
  {
    group: 'RCSA WORKFLOW',
    items: [
      { name: 'RCSA Hub', href: '/rcsa', icon: Shield },
      {
        name: 'Assessment Stages',
        icon: GitBranch,
        submenu: [
          { name: '01 Assessment Setup', href: '/rcsa/provisioning' },
          { name: '02 Risk Identification', href: '/rcsa/identification' },
          { name: '03 Risk Mitigation', href: '/rcsa/mitigation' },
          { name: '04 Risk Monitoring', href: '/rcsa/monitoring' },
        ]
      },
    ]
  },
  {
    group: 'RISK ANALYTICS',
    items: [
      {
        name: 'Risk Explorer',
        icon: Eye,
        submenu: [
          { name: 'Inherent Analysis', href: '/assessments/inherent' },
          { name: 'Residual Mapping', href: '/assessments/residual' },
          { name: 'Risk Heatmaps', href: '/heatmaps' },
        ]
      },
      { name: 'KRI Intelligence', href: '/kri', icon: Activity },
      { name: 'Control Monitoring', href: '/monitoring/risk-monitoring', icon: ShieldAlert },
      { name: 'Risk Reports', href: '/reports', icon: BarChart3 },
    ]
  },
  {
    group: 'GRC MANAGEMENT',
    items: [
      { name: 'Control Library', href: '/control-library', icon: ClipboardCheck },
      { name: 'Risk Appetite', href: '/risk-appetite', icon: Target },
      { name: 'Workflow & Approvals', href: '/workflow', icon: Layers },
      { name: 'Policy Management', href: '/policy', icon: BookOpen },
    ]
  },
  {
    group: 'ENTERPRISE RISK',
    items: [
      { name: 'Vendor Risk (TPRM)', href: '/vendor-risk', icon: Briefcase },
      { name: 'Incident Management', href: '/incidents', icon: AlertOctagon },
      { name: 'Business Continuity', href: '/bcp', icon: Shield },
      { name: 'Scenario Analysis', href: '/scenario', icon: TrendingUp },
    ]
  },
  {
    group: 'ADMINISTRATION',
    items: [
      { name: 'Audit Trail', href: '/audit-trail', icon: History },
      { name: 'User Management', href: '/users', icon: Users },
      { name: 'Settings', href: '/settings', icon: Settings },
    ]
  }
]

export function PericopeSidebar() {
  const pathname = usePathname()
  const { logout, user } = useAuth()
  const { isOpen, close } = useSidebar()
  const [expandedGroups, setExpandedGroups] = React.useState<string[]>(['Assessment Stages'])

  const toggleGroup = (name: string) => {
    setExpandedGroups(prev =>
      prev.includes(name) ? prev.filter(g => g !== name) : [...prev, name]
    )
  }

  const initials = (user?.name || 'User').split(' ').map(n => n[0]).slice(0, 2).join('').toUpperCase()

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.aside
          initial={{ x: -300, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          exit={{ x: -300, opacity: 0 }}
          transition={{ type: 'spring', stiffness: 300, damping: 30 }}
          className="w-72 bg-white border-r border-blue-100 h-screen fixed left-0 top-0 flex flex-col z-50 shadow-xl shadow-blue-100/50"
        >
          {/* Header with close button */}
          <div className="px-6 h-20 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-600 rounded-2xl flex items-center justify-center">
                <Activity className="w-6 h-6 text-white" />
              </div>
              <div className="flex flex-col">
                <span className="text-sm font-black text-blue-800 tracking-tight leading-none uppercase">Pericope</span>
                <span className="text-[9px] font-black uppercase text-blue-400 tracking-[0.3em] mt-1.5">ERM Platform</span>
              </div>
            </div>
            <button
              onClick={close}
              className="p-2 rounded-xl hover:bg-blue-50 text-blue-400 hover:text-blue-600 transition-all"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Navigation */}
          <nav className="flex-1 px-4 space-y-6 overflow-y-auto pt-2 pb-4">
            {navigationItems.map((group) => (
              <div key={group.group} className="space-y-2">
                <h3 className="px-3 text-[9px] font-black text-blue-300 tracking-[0.4em] uppercase">
                  {group.group}
                </h3>
                <div className="space-y-1">
                  {group.items.map((item) => {
                    const isActive = pathname === item.href || (item.submenu && item.submenu.some(sub => pathname === sub.href))
                    const isExpanded = expandedGroups.includes(item.name)

                    return (
                      <div key={item.name} className="space-y-1">
                        <button
                          onClick={() => {
                            if (item.submenu) {
                              toggleGroup(item.name)
                            } else if (item.href) {
                              close()
                            }
                          }}
                          className={cn(
                            "w-full flex items-center gap-3.5 px-3.5 py-2.5 rounded-xl text-[12px] font-bold transition-all duration-200 group relative",
                            isActive && !item.submenu
                              ? "bg-blue-50 text-blue-600 border border-blue-100"
                              : "text-blue-400 hover:text-blue-600 hover:bg-blue-50/60"
                          )}
                        >
                          {item.href && !item.submenu ? (
                            <Link href={item.href} onClick={close} className="absolute inset-0 z-10" />
                          ) : null}

                          <item.icon className={cn(
                            "w-4 h-4",
                            isActive ? "text-blue-600" : "text-blue-300 group-hover:text-blue-500"
                          )} />
                          <span className="flex-1 text-left">{item.name}</span>

                          {item.submenu && (
                            <ChevronDown className={cn(
                              "w-3 h-3 transition-transform duration-300",
                              isExpanded && "rotate-180"
                            )} />
                          )}

                          {isActive && !item.submenu && (
                            <div className="absolute left-0 w-1 h-6 bg-blue-600 rounded-r-full" />
                          )}
                        </button>

                        <AnimatePresence>
                          {item.submenu && isExpanded && (
                            <motion.div
                              initial={{ opacity: 0, height: 0 }}
                              animate={{ opacity: 1, height: 'auto' }}
                              exit={{ opacity: 0, height: 0 }}
                              className="ml-5 pl-4 border-l-2 border-blue-100 space-y-1 overflow-hidden"
                            >
                              {item.submenu.map((sub) => {
                                const isSubActive = pathname === sub.href
                                return (
                                  <Link
                                    key={sub.name}
                                    href={sub.href}
                                    onClick={close}
                                    className={cn(
                                      "flex items-center gap-3 px-3 py-2 rounded-lg text-[11px] font-bold transition-all duration-200",
                                      isSubActive
                                        ? "text-blue-600 bg-blue-50 border border-blue-100"
                                        : "text-blue-300 hover:text-blue-600 hover:bg-blue-50/50"
                                    )}
                                  >
                                    <div className={cn(
                                      "w-1.5 h-1.5 rounded-full",
                                      isSubActive ? "bg-blue-600" : "bg-blue-200"
                                    )} />
                                    {sub.name}
                                  </Link>
                                )
                              })}
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </div>
                    )
                  })}
                </div>
              </div>
            ))}
          </nav>

          {/* Profile Section */}
          <div className="p-4 mt-auto border-t border-blue-100 mx-3 mb-3">
            <div className="flex items-center justify-between p-2">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center text-[10px] font-black">
                  {initials}
                </div>
                <div className="flex flex-col">
                  <span className="text-[11px] font-black text-blue-800 truncate max-w-[120px] leading-tight">{user?.name || 'User'}</span>
                  <span className="text-[8px] font-black uppercase text-blue-400 tracking-widest">{user?.role || 'Viewer'}</span>
                </div>
              </div>
              <button
                onClick={logout}
                className="p-2.5 text-blue-300 hover:text-red-500 hover:bg-red-50 rounded-xl transition-all duration-200"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          </div>
        </motion.aside>
      )}
    </AnimatePresence>
  )
}
