// Production-grade Express backend with Oracle ORDS database
require('dotenv').config({ path: require('path').join(__dirname, '..', '.env') })
const express = require('express')
const axios = require('axios')

const app = express()
app.use(express.json())

// Oracle ORDS Configuration
const ORDS_BASE_URL = process.env.ORDS_BASE_URL || 'https://ga8231f10084da5-pericopeai.adb.us-chicago-1.oraclecloudapps.com/ords/pericope_ai'
const ORDS_TOKEN_URL = process.env.ORDS_TOKEN_URL || 'https://ga8231f10084da5-pericopeai.adb.us-chicago-1.oraclecloudapps.com/ords/pericope_ai/oauth/token'
const CLIENT_ID = process.env.CLIENT_ID || 'C3hX6vbjm4sgnWveZvhYlw..'
const CLIENT_SECRET = process.env.CLIENT_SECRET || 'iMKeCcJJEadoq0oYCFJtlw..'

// In-memory token cache
let tokenCache = { token: null, expiresAt: 0 }

// Get OAuth2 token from Oracle
async function getORDSToken() {
  if (tokenCache.token && Date.now() < tokenCache.expiresAt) {
    return tokenCache.token
  }
  
  try {
    const response = await axios.post(ORDS_TOKEN_URL, 
      'grant_type=client_credentials',
      {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        auth: {
          username: CLIENT_ID,
          password: CLIENT_SECRET,
        },
      }
    )
    
    tokenCache.token = response.data.access_token
    tokenCache.expiresAt = Date.now() + (response.data.expires_in - 60) * 1000
    
    return tokenCache.token
  } catch (error) {
    console.error('Failed to get ORDS token:', error.message)
    throw new Error('Authentication failed')
  }
}

// Make authenticated ORDS request
async function ordsRequest(method, path, data = null) {
  const token = await getORDSToken()
  
  const config = {
    method,
    url: `${ORDS_BASE_URL}${path}`,
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
  }
  
  if (data) {
    config.data = data
  }
  
  const response = await axios(config)
  return response.data
}

// Simple RBAC middleware
function authorizeRole(roles) {
  return (req, res, next) => {
    const auth = req.headers['authorization'] || ''
    const token = auth.split(' ')[1] || ''
    const role = token
    
    if (!token || !roles.includes(role)) {
      return res.status(403).json({ success: false, error: { code: 'FORBIDDEN', message: 'Access denied' } })
    }
    
    req.user = { role }
    next()
  }
}

// Health endpoint
app.get('/health', async (req, res) => {
  try {
    const token = await getORDSToken()
    res.json({ status: 'OK', database: 'Oracle ORDS', time: new Date().toISOString() })
  } catch (error) {
    res.status(503).json({ status: 'ERROR', message: error.message })
  }
})

// Auth login (returns token = role)
app.post('/auth/login', (req, res) => {
  const { role } = req.body || {}
  if (!['admin', 'risk_manager', 'viewer'].includes(role)) {
    return res.status(400).json({ success: false, error: { code: 'BAD_REQUEST', message: 'Invalid role' } })
  }
  res.json({ success: true, token: role })
})

// List risks from Oracle
app.get('/api/risks', authorizeRole(['admin', 'risk_manager', 'viewer']), async (req, res) => {
  try {
    const page = Math.max(1, parseInt(req.query.page) || 1)
    const limit = Math.max(1, parseInt(req.query.limit) || 10)
    const offset = (page - 1) * limit
    
    const data = await ordsRequest('GET', `/risk/per_trn_identify_risk?offset=${offset}&limit=${limit}`)
    
    const items = data.items || []
    const total = data.total || items.length
    
    res.json({ success: true, total, page, limit, data: items })
  } catch (error) {
    console.error('List risks error:', error.message)
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: error.message } })
  }
})

// Create risk in Oracle
app.post('/api/risks', authorizeRole(['admin', 'risk_manager']), async (req, res) => {
  try {
    const { name, description } = req.body
    
    if (!name) {
      return res.status(400).json({ success: false, error: { code: 'BAD_REQUEST', message: 'Invalid risk payload' } })
    }
    
    const payload = {
      risk_statement: name,
      description: description || '',
      hierarchy_level: 1,
      hierarchy_name: name,
      is_sop_available: 'Y',
    }
    
    const data = await ordsRequest('POST', '/risk/per_trn_identify_risk', payload)
    
    res.status(201).json({ success: true, data })
  } catch (error) {
    console.error('Create risk error:', error.message)
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: error.message } })
  }
})

// Get risk by ID from Oracle
app.get('/api/risks/:id', authorizeRole(['admin', 'risk_manager', 'viewer']), async (req, res) => {
  try {
    const id = parseInt(req.params.id)
    
    const data = await ordsRequest('GET', `/risk/per_trn_identify_risk/${id}`)
    
    if (!data.id) {
      return res.status(404).json({ success: false, error: { code: 'NOT_FOUND', message: 'Risk not found' } })
    }
    
    res.json({ success: true, data })
  } catch (error) {
    if (error.response && error.response.status === 404) {
      return res.status(404).json({ success: false, error: { code: 'NOT_FOUND', message: 'Risk not found' } })
    }
    console.error('Get risk error:', error.message)
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: error.message } })
  }
})

// Update risk in Oracle
app.put('/api/risks/:id', authorizeRole(['admin', 'risk_manager']), async (req, res) => {
  try {
    const id = parseInt(req.params.id)
    const { name, description } = req.body
    
    if (!name) {
      return res.status(400).json({ success: false, error: { code: 'BAD_REQUEST', message: 'Invalid risk payload' } })
    }
    
    const payload = {
      risk_statement: name,
      description: description || '',
    }
    
    const data = await ordsRequest('PUT', `/risk/per_trn_identify_risk/${id}`, payload)
    
    res.json({ success: true, data })
  } catch (error) {
    if (error.response && error.response.status === 404) {
      return res.status(404).json({ success: false, error: { code: 'NOT_FOUND', message: 'Risk not found' } })
    }
    console.error('Update risk error:', error.message)
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: error.message } })
  }
})

// Delete risk from Oracle
app.delete('/api/risks/:id', authorizeRole(['admin']), async (req, res) => {
  try {
    const id = parseInt(req.params.id)
    
    await ordsRequest('DELETE', `/risk/per_trn_identify_risk/${id}`)
    
    res.json({ success: true, data: { id, deleted: true } })
  } catch (error) {
    if (error.response && error.response.status === 404) {
      return res.status(404).json({ success: false, error: { code: 'NOT_FOUND', message: 'Risk not found' } })
    }
    console.error('Delete risk error:', error.message)
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: error.message } })
  }
})

const PORT = process.env.PORT || 5000
app.listen(PORT, () => {
  console.log(`API (Oracle backend) running on http://localhost:${PORT}`)
  console.log(`Connected to: ${ORDS_BASE_URL}`)
})
