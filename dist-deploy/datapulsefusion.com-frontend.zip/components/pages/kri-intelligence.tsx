'use client'

import React, { useMemo, useState } from 'react'
import { Activity, Plus, AlertTriangle, TrendingUp, TrendingDown, Pencil, Trash2, ShieldCheck, Bell, BarChart3 } from 'lucide-react'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'
import { createStore, useStoreSnapshot, genId } from '@/lib/localStore'
import { useToast } from '@/hooks/use-toast'
import { recordAudit } from '@/lib/auditLog'
import { useConfirm } from '@/components/ui/confirm-dialog'
import { useAuth } from '@/components/providers/auth-provider'

export interface KRI {
  id: string
  code: string
  name: string
  category: string
  owner: string
  unit: string
  greenThreshold: number
  amberThreshold: number
  redThreshold: number
  currentValue: number
  direction: 'higher-worse' | 'lower-worse'
  history: { date: string; value: number }[]
  active: boolean
}

const SEED: KRI[] = [
  {
    id: 'KRI-001', code: 'KRI-IT-001', name: 'Unplanned IT Outage Hours', category: 'IT & Cyber',
    owner: 'CIO', unit: 'hrs/month', greenThreshold: 4, amberThreshold: 8, redThreshold: 12, currentValue: 7.2,
    direction: 'higher-worse',
    history: monthly(2.1, 3.4, 4.8, 5.2, 6.9, 7.2), active: true,
  },
  {
    id: 'KRI-002', code: 'KRI-OPS-002', name: 'Customer Complaints', category: 'Operations',
    owner: 'COO', unit: 'count/week', greenThreshold: 10, amberThreshold: 25, redThreshold: 40, currentValue: 22,
    direction: 'higher-worse',
    history: monthly(8, 12, 15, 19, 24, 22), active: true,
  },
  {
    id: 'KRI-003', code: 'KRI-FIN-003', name: 'Operating Margin', category: 'Financial',
    owner: 'CFO', unit: '%', greenThreshold: 20, amberThreshold: 15, redThreshold: 10, currentValue: 17.5,
    direction: 'lower-worse',
    history: monthly(22, 21, 19.5, 18, 17, 17.5), active: true,
  },
  {
    id: 'KRI-004', code: 'KRI-COMP-004', name: 'Overdue Audit Findings', category: 'Compliance',
    owner: 'Chief Compliance Officer', unit: 'count', greenThreshold: 5, amberThreshold: 12, redThreshold: 20, currentValue: 14,
    direction: 'higher-worse',
    history: monthly(3, 5, 7, 10, 11, 14), active: true,
  },
  {
    id: 'KRI-005', code: 'KRI-HR-005', name: 'Voluntary Attrition Rate', category: 'People',
    owner: 'CHRO', unit: '%', greenThreshold: 8, amberThreshold: 14, redThreshold: 20, currentValue: 11.4,
    direction: 'higher-worse',
    history: monthly(7.2, 8.1, 9.4, 10.2, 10.9, 11.4), active: true,
  },
  {
    id: 'KRI-006', code: 'KRI-VEN-006', name: 'Critical Vendor SLA Breaches', category: 'Vendor',
    owner: 'Head of Procurement', unit: 'count', greenThreshold: 0, amberThreshold: 2, redThreshold: 5, currentValue: 1,
    direction: 'higher-worse',
    history: monthly(0, 0, 1, 2, 1, 1), active: true,
  },
]

function monthly(...vals: number[]) {
  const months = ['Dec', 'Jan', 'Feb', 'Mar', 'Apr', 'May']
  return vals.map((value, i) => ({ date: months[i], value }))
}

export const kriStore = createStore<KRI>({ key: 'kri', seed: SEED })

function statusOf(kri: KRI): 'green' | 'amber' | 'red' {
  const v = kri.currentValue
  if (kri.direction === 'higher-worse') {
    if (v >= kri.redThreshold) return 'red'
    if (v >= kri.amberThreshold) return 'amber'
    return 'green'
  } else {
    if (v <= kri.redThreshold) return 'red'
    if (v <= kri.amberThreshold) return 'amber'
    return 'green'
  }
}

export function KriIntelligencePage() {
  const items = useStoreSnapshot(kriStore)
  const { toast } = useToast()
  const confirm = useConfirm()
  const { hasPermission, user } = useAuth()
  const [editing, setEditing] = useState<KRI | null>(null)
  const [filter, setFilter] = useState('')
  const [statusFilter, setStatusFilter] = useState<'all' | 'green' | 'amber' | 'red'>('all')

  const filtered = useMemo(() => {
    return items.filter(k => {
      if (statusFilter !== 'all' && statusOf(k) !== statusFilter) return false
      if (filter && !`${k.name} ${k.code} ${k.owner} ${k.category}`.toLowerCase().includes(filter.toLowerCase())) return false
      return true
    })
  }, [items, filter, statusFilter])

  const totals = useMemo(() => ({
    total: items.length,
    breaches: items.filter(k => statusOf(k) === 'red').length,
    warnings: items.filter(k => statusOf(k) === 'amber').length,
    healthy: items.filter(k => statusOf(k) === 'green').length,
  }), [items])

  const handleSave = (kri: KRI) => {
    const isNew = !items.find(x => x.id === kri.id)
    if (isNew) {
      kriStore.add(kri)
      recordAudit({ action: 'CREATE', entity: 'KRI', entity_id: kri.id, description: `Created KRI ${kri.code} – ${kri.name}`, after: kri, result: 'SUCCESS' })
      toast({ title: 'KRI created', description: kri.name })
    } else {
      kriStore.update(kri.id, kri)
      recordAudit({ action: 'UPDATE', entity: 'KRI', entity_id: kri.id, description: `Updated KRI ${kri.code}`, after: kri, result: 'SUCCESS' })
      toast({ title: 'KRI updated', description: kri.name })
    }
    setEditing(null)
  }

  const handleDelete = async (kri: KRI) => {
    const ok = await confirm({
      title: `Delete ${kri.code}?`,
      description: `This will remove "${kri.name}" and its history. This action cannot be undone.`,
      confirmLabel: 'Delete KRI',
      tone: 'danger',
    })
    if (!ok) return
    kriStore.remove(kri.id)
    recordAudit({ action: 'DELETE', entity: 'KRI', entity_id: kri.id, description: `Deleted KRI ${kri.code} – ${kri.name}`, before: kri, result: 'SUCCESS' })
    toast({ title: 'KRI deleted', description: kri.name })
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Activity className="w-4 h-4 text-primary" />
            <span className="text-[10px] font-black uppercase tracking-[0.3em] text-primary">KRI Intelligence</span>
          </div>
          <h1 className="text-3xl font-black text-foreground tracking-tight">Key Risk Indicators</h1>
          <p className="text-muted-foreground mt-2 font-medium">Threshold-based monitoring with trend and breach alerts.</p>
        </div>
        {hasPermission('create') && (
          <Button onClick={() => setEditing(blankKri(user?.name))} className="rounded-2xl"><Plus className="w-4 h-4 mr-2" />New KRI</Button>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <KpiCard label="Total KRIs" value={totals.total} icon={BarChart3} tone="blue" />
        <KpiCard label="Healthy" value={totals.healthy} icon={ShieldCheck} tone="emerald" />
        <KpiCard label="Amber" value={totals.warnings} icon={Bell} tone="amber" />
        <KpiCard label="Red — breach" value={totals.breaches} icon={AlertTriangle} tone="red" />
      </div>

      <Card className="p-4">
        <div className="flex flex-col md:flex-row gap-3 items-stretch">
          <Input placeholder="Search KRIs…" value={filter} onChange={e => setFilter(e.target.value)} className="md:max-w-sm" />
          <div className="flex items-center gap-2">
            {(['all', 'green', 'amber', 'red'] as const).map(s => (
              <Button key={s} variant={statusFilter === s ? 'primary' : 'ghost'} size="sm" onClick={() => setStatusFilter(s)} className="capitalize">
                {s === 'all' ? 'All' : s}
              </Button>
            ))}
          </div>
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filtered.map(kri => <KriCard key={kri.id} kri={kri} onEdit={() => setEditing(kri)} onDelete={() => handleDelete(kri)} canEdit={hasPermission('update')} canDelete={hasPermission('delete')} />)}
        {filtered.length === 0 && (
          <div className="col-span-full p-12 text-center text-muted-foreground italic">No KRIs match your filters.</div>
        )}
      </div>

      {editing && (
        <KriEditor
          initial={editing}
          onCancel={() => setEditing(null)}
          onSave={handleSave}
        />
      )}
    </div>
  )
}

function blankKri(owner?: string): KRI {
  return {
    id: genId('KRI'),
    code: '',
    name: '',
    category: 'Operations',
    owner: owner || '',
    unit: '%',
    greenThreshold: 0,
    amberThreshold: 0,
    redThreshold: 0,
    currentValue: 0,
    direction: 'higher-worse',
    history: monthly(0, 0, 0, 0, 0, 0),
    active: true,
  }
}

function KpiCard({ label, value, icon: Icon, tone }: { label: string; value: number; icon: any; tone: 'blue' | 'emerald' | 'amber' | 'red' }) {
  const colorMap = {
    blue: 'text-blue-600 bg-blue-50',
    emerald: 'text-emerald-600 bg-emerald-50',
    amber: 'text-amber-600 bg-amber-50',
    red: 'text-red-600 bg-red-50',
  }[tone]
  return (
    <Card className="p-5 flex items-center gap-4">
      <div className={cn('w-12 h-12 rounded-2xl flex items-center justify-center', colorMap)}>
        <Icon className="w-5 h-5" />
      </div>
      <div>
        <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">{label}</p>
        <p className="text-3xl font-black tabular-nums text-foreground">{value}</p>
      </div>
    </Card>
  )
}

function KriCard({ kri, onEdit, onDelete, canEdit, canDelete }: { kri: KRI; onEdit: () => void; onDelete: () => void; canEdit: boolean; canDelete: boolean }) {
  const status = statusOf(kri)
  const last = kri.history.length > 1 ? kri.history[kri.history.length - 2].value : kri.currentValue
  const trendingUp = kri.currentValue > last
  const isBreach = status === 'red'

  const toneBadge = status === 'red' ? 'bg-red-100 text-red-700 border-red-200'
    : status === 'amber' ? 'bg-amber-100 text-amber-700 border-amber-200'
    : 'bg-emerald-100 text-emerald-700 border-emerald-200'

  const chartColor = status === 'red' ? '#dc2626' : status === 'amber' ? '#f59e0b' : '#10b981'

  return (
    <Card className={cn('p-6 transition-all', isBreach && 'border-red-200')}>
      <div className="flex items-start justify-between mb-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <code className="text-[10px] font-mono text-muted-foreground">{kri.code}</code>
            <Badge variant="outline" className="text-[9px] uppercase tracking-widest">{kri.category}</Badge>
          </div>
          <h3 className="text-lg font-black text-foreground tracking-tight">{kri.name}</h3>
          <p className="text-[11px] text-muted-foreground mt-1">Owner: <span className="font-bold">{kri.owner || '—'}</span></p>
        </div>
        <div className="flex items-center gap-1">
          {canEdit && <Button variant="ghost" size="icon" onClick={onEdit}><Pencil className="w-4 h-4" /></Button>}
          {canDelete && <Button variant="ghost" size="icon" onClick={onDelete} className="text-red-500 hover:bg-red-50"><Trash2 className="w-4 h-4" /></Button>}
        </div>
      </div>

      <div className="flex items-end justify-between mb-6">
        <div>
          <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Current</p>
          <div className="flex items-baseline gap-2">
            <span className="text-4xl font-black tabular-nums">{kri.currentValue}</span>
            <span className="text-sm text-muted-foreground">{kri.unit}</span>
            {trendingUp ? <TrendingUp className="w-4 h-4 text-muted-foreground" /> : <TrendingDown className="w-4 h-4 text-muted-foreground" />}
          </div>
        </div>
        <span className={cn('px-3 py-1 rounded-full border text-[10px] font-black uppercase tracking-widest', toneBadge)}>
          {status === 'red' ? 'Breach' : status === 'amber' ? 'Warning' : 'Healthy'}
        </span>
      </div>

      <div className="h-32 -mx-2">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={kri.history} margin={{ top: 4, right: 4, left: 4, bottom: 4 }}>
            <CartesianGrid stroke="#e5e7eb" strokeDasharray="3 3" />
            <XAxis dataKey="date" tick={{ fontSize: 10 }} stroke="#9ca3af" axisLine={false} tickLine={false} />
            <YAxis tick={{ fontSize: 10 }} stroke="#9ca3af" axisLine={false} tickLine={false} width={36} />
            <Tooltip contentStyle={{ fontSize: '11px', borderRadius: '8px' }} />
            <ReferenceLine y={kri.amberThreshold} stroke="#f59e0b" strokeDasharray="4 4" label={{ value: 'Amber', fontSize: 9, fill: '#f59e0b' }} />
            <ReferenceLine y={kri.redThreshold} stroke="#dc2626" strokeDasharray="4 4" label={{ value: 'Red', fontSize: 9, fill: '#dc2626' }} />
            <Line type="monotone" dataKey="value" stroke={chartColor} strokeWidth={2.5} dot={{ r: 3, fill: chartColor }} />
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div className="mt-4 grid grid-cols-3 gap-2 text-[10px] font-bold">
        <div className="text-emerald-600">Green ≤ {kri.greenThreshold}</div>
        <div className="text-amber-600">Amber ≤ {kri.amberThreshold}</div>
        <div className="text-red-600">Red ≥ {kri.redThreshold}</div>
      </div>
    </Card>
  )
}

function KriEditor({ initial, onCancel, onSave }: { initial: KRI; onCancel: () => void; onSave: (kri: KRI) => void }) {
  const [draft, setDraft] = useState<KRI>(initial)

  const submit = () => {
    if (!draft.code || !draft.name) return
    onSave({ ...draft, currentValue: Number(draft.currentValue) })
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={onCancel}>
      <Card className="w-full max-w-2xl p-8" onClick={e => e.stopPropagation()}>
        <h2 className="text-xl font-black mb-6">{initial.code ? 'Edit KRI' : 'New KRI'}</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField label="Code"><Input value={draft.code} onChange={e => setDraft({ ...draft, code: e.target.value })} placeholder="KRI-XX-NNN" /></FormField>
          <FormField label="Name"><Input value={draft.name} onChange={e => setDraft({ ...draft, name: e.target.value })} /></FormField>
          <FormField label="Category">
            <select className="h-9 px-3 border border-border rounded-md text-sm w-full" value={draft.category} onChange={e => setDraft({ ...draft, category: e.target.value })}>
              {['IT & Cyber', 'Operations', 'Financial', 'Compliance', 'People', 'Vendor', 'Strategic'].map(c => <option key={c}>{c}</option>)}
            </select>
          </FormField>
          <FormField label="Owner"><Input value={draft.owner} onChange={e => setDraft({ ...draft, owner: e.target.value })} /></FormField>
          <FormField label="Unit"><Input value={draft.unit} onChange={e => setDraft({ ...draft, unit: e.target.value })} /></FormField>
          <FormField label="Direction">
            <select className="h-9 px-3 border border-border rounded-md text-sm w-full" value={draft.direction} onChange={e => setDraft({ ...draft, direction: e.target.value as KRI['direction'] })}>
              <option value="higher-worse">Higher is worse</option>
              <option value="lower-worse">Lower is worse</option>
            </select>
          </FormField>
          <FormField label="Green threshold"><Input type="number" value={draft.greenThreshold} onChange={e => setDraft({ ...draft, greenThreshold: Number(e.target.value) })} /></FormField>
          <FormField label="Amber threshold"><Input type="number" value={draft.amberThreshold} onChange={e => setDraft({ ...draft, amberThreshold: Number(e.target.value) })} /></FormField>
          <FormField label="Red threshold"><Input type="number" value={draft.redThreshold} onChange={e => setDraft({ ...draft, redThreshold: Number(e.target.value) })} /></FormField>
          <FormField label="Current value"><Input type="number" value={draft.currentValue} onChange={e => setDraft({ ...draft, currentValue: Number(e.target.value) })} /></FormField>
        </div>

        <div className="flex justify-end gap-2 mt-6">
          <Button variant="ghost" onClick={onCancel}>Cancel</Button>
          <Button onClick={submit}>Save</Button>
        </div>
      </Card>
    </div>
  )
}

function FormField({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1">
      <label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">{label}</label>
      {children}
    </div>
  )
}
