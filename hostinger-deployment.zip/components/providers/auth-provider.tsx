'use client'

import React, { createContext, useContext, useState, useEffect } from 'react'
import { LoginPage } from '@/components/pages/login'

interface AuthContextType {
  isAuthenticated: boolean
  login: () => void
  logout: () => void
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null)

  useEffect(() => {
    const stored = sessionStorage.getItem('pericope_auth')
    if (stored === 'true') {
      setIsAuthenticated(true)
    } else {
      setIsAuthenticated(false)
    }
  }, [])

  const login = () => {
    sessionStorage.setItem('pericope_auth', 'true')
    setIsAuthenticated(true)
  }

  const logout = () => {
    sessionStorage.removeItem('pericope_auth')
    setIsAuthenticated(false)
  }

  if (isAuthenticated === null) return null // Avoid hydration mismatch

  if (!isAuthenticated) {
    return (
      <AuthContext.Provider value={{ isAuthenticated, login, logout }}>
        <LoginPage />
      </AuthContext.Provider>
    )
  }

  return (
    <AuthContext.Provider value={{ isAuthenticated, login, logout }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}
