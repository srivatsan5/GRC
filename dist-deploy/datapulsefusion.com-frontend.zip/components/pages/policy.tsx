'use client'

import React, { useMemo, useState } from 'react'
import { BookOpen, Plus, Trash2, Pencil, ShieldCheck, FileText } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'
import { createStore, useStoreSnapshot, genId } from '@/lib/localStore'
import { useToast } from '@/hooks/use-toast'
import { recordAudit } from '@/lib/auditLog'
import { useConfirm } from '@/components/ui/confirm-dialog'
import { useAuth } from '@/components/providers/auth-provider'

export interface Policy {
  id: string
  code: string
  title: string
  category: string
  version: string
  owner: string
  effectiveDate: string
  nextReview: string
  acknowledgmentPct: number
  status: 'Active' | 'Draft' | 'Retired'
  linkedControls: string[]
}

const SEED: Policy[] = [
  { id: 'POL-001', code: 'POL-IT-001', title: 'Acceptable Use Policy', category: 'IT & Cyber', version: '3.2', owner: 'CISO', effectiveDate: '2026-01-01', nextReview: '2027-01-01', acknowledgmentPct: 96, status: 'Active', linkedControls: ['CTL-001'] },
  { id: 'POL-002', code: 'POL-FIN-002', title: 'Treasury & Payments Policy', category: 'Financial', version: '4.1', owner: 'CFO', effectiveDate: '2025-10-01', nextReview: '2026-10-01', acknowledgmentPct: 91, status: 'Active', linkedControls: ['CTL-002', 'CTL-007'] },
  { id: 'POL-003', code: 'POL-PRIV-003', title: 'Personal Data Protection Policy (GDPR)', category: 'Compliance', version: '2.5', owner: 'CCO', effectiveDate: '2025-05-25', nextReview: '2026-05-25', acknowledgmentPct: 88, status: 'Active', linkedControls: ['CTL-004'] },
  { id: 'POL-004', code: 'POL-HR-004', title: 'Code of Conduct', category: 'People', version: '5.0', owner: 'CHRO', effectiveDate: '2026-01-15', nextReview: '2027-01-15', acknowledgmentPct: 99, status: 'Active', linkedControls: [] },
  { id: 'POL-005', code: 'POL-VEN-005', title: 'Third-party Risk Management Policy', category: 'Vendor', version: '1.3', owner: 'Head of Procurement', effectiveDate: '2025-11-01', nextReview: '2026-11-01', acknowledgmentPct: 82, status: 'Active', linkedControls: ['CTL-006'] },
  { id: 'POL-006', code: 'POL-BCP-006', title: 'Business Continuity Policy', category: 'Operations', version: '2.0', owner: 'COO', effectiveDate: '2026-02-01', nextReview: '2027-02-01', acknowledgmentPct: 76, status: 'Draft', linkedControls: [] },
]

export const policyStore = createStore<Policy>({ key: 'policy', seed: SEED })

export function PolicyPage() {
  const items = useStoreSnapshot(policyStore)
  const { toast } = useToast()
  const confirm = useConfirm()
  const { hasPermission } = useAuth()
  const [editing, setEditing] = useState<Policy | null>(null)

  const stats = useMemo(() => ({
    total: items.length,
    active: items.filter(p => p.status === 'Active').length,
    avgAck: items.length ? Math.round(items.reduce((s, p) => s + p.acknowledgmentPct, 0) / items.length) : 0,
    overdue: items.filter(p => new Date(p.nextReview) < new Date()).length,
  }), [items])

  const save = (p: Policy) => {
    const isNew = !items.find(x => x.id === p.id)
    if (isNew) { policyStore.add(p); recordAudit({ action: 'CREATE', entity: 'Policy', entity_id: p.id, description: `Created policy ${p.title}`, after: p, result: 'SUCCESS' }); toast({ title: 'Policy created' }) }
    else { policyStore.update(p.id, p); recordAudit({ action: 'UPDATE', entity: 'Policy', entity_id: p.id, description: `Updated policy ${p.title}`, after: p, result: 'SUCCESS' }); toast({ title: 'Policy updated' }) }
    setEditing(null)
  }

  const remove = async (p: Policy) => {
    const ok = await confirm({ title: `Delete ${p.code}?`, description: 'This action cannot be undone.', confirmLabel: 'Delete policy', tone: 'danger' })
    if (!ok) return
    policyStore.remove(p.id)
    recordAudit({ action: 'DELETE', entity: 'Policy', entity_id: p.id, description: `Deleted policy ${p.title}`, before: p, result: 'SUCCESS' })
    toast({ title: 'Policy deleted' })
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <BookOpen className="w-4 h-4 text-primary" />
            <span className="text-[10px] font-black uppercase tracking-[0.3em] text-primary">Policy Library</span>
          </div>
          <h1 className="text-3xl font-black tracking-tight">Policy Management</h1>
          <p className="text-muted-foreground mt-2 font-medium">Policy library with version control, acknowledgment tracking, and control linkage.</p>
        </div>
        {hasPermission('create') && <Button onClick={() => setEditing(blank())} className="rounded-2xl"><Plus className="w-4 h-4 mr-2" />New policy</Button>}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Stat label="Total policies" value={stats.total} icon={FileText} tone="blue" />
        <Stat label="Active" value={stats.active} icon={ShieldCheck} tone="emerald" />
        <Stat label="Avg acknowledgment" value={`${stats.avgAck}%`} icon={BookOpen} tone="amber" />
        <Stat label="Reviews overdue" value={stats.overdue} icon={BookOpen} tone="red" />
      </div>

      <Card className="overflow-hidden">
        <table className="w-full text-[13px]">
          <thead className="bg-secondary/40">
            <tr className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">
              <th className="px-4 py-3 text-left">Code</th>
              <th className="px-4 py-3 text-left">Title</th>
              <th className="px-4 py-3 text-left">Category</th>
              <th className="px-4 py-3 text-left">Version</th>
              <th className="px-4 py-3 text-left">Owner</th>
              <th className="px-4 py-3 text-left">Acknowledged</th>
              <th className="px-4 py-3 text-left">Next review</th>
              <th className="px-4 py-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border/30">
            {items.map(p => (
              <tr key={p.id} className="hover:bg-secondary/20">
                <td className="px-4 py-3 font-mono text-[11px] text-muted-foreground">{p.code}</td>
                <td className="px-4 py-3 font-bold">{p.title}</td>
                <td className="px-4 py-3"><Badge variant="outline" className="text-[9px] uppercase">{p.category}</Badge></td>
                <td className="px-4 py-3 font-mono text-[11px]">{p.version}</td>
                <td className="px-4 py-3 text-muted-foreground">{p.owner}</td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2">
                    <div className="w-20 h-1.5 bg-muted rounded-full overflow-hidden">
                      <div className={cn('h-full rounded-full', p.acknowledgmentPct > 90 ? 'bg-emerald-500' : p.acknowledgmentPct > 75 ? 'bg-amber-500' : 'bg-red-500')} style={{ width: `${p.acknowledgmentPct}%` }} />
                    </div>
                    <span className="text-[11px] font-bold tabular-nums">{p.acknowledgmentPct}%</span>
                  </div>
                </td>
                <td className="px-4 py-3 text-muted-foreground">{p.nextReview}</td>
                <td className="px-4 py-3 text-right">
                  {hasPermission('update') && <Button variant="ghost" size="icon" onClick={() => setEditing(p)}><Pencil className="w-4 h-4" /></Button>}
                  {hasPermission('delete') && <Button variant="ghost" size="icon" onClick={() => remove(p)} className="text-red-500 hover:bg-red-50"><Trash2 className="w-4 h-4" /></Button>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>

      {editing && <PolicyEditor initial={editing} onCancel={() => setEditing(null)} onSave={save} />}
    </div>
  )
}

function blank(): Policy {
  const next = new Date(); next.setFullYear(next.getFullYear() + 1)
  return { id: genId('POL'), code: '', title: '', category: 'Operations', version: '1.0', owner: '', effectiveDate: new Date().toISOString().slice(0, 10), nextReview: next.toISOString().slice(0, 10), acknowledgmentPct: 0, status: 'Draft', linkedControls: [] }
}

function Stat({ label, value, icon: Icon, tone }: { label: string; value: number | string; icon: any; tone: 'blue' | 'emerald' | 'amber' | 'red' }) {
  const colorMap = { blue: 'text-blue-600 bg-blue-50', emerald: 'text-emerald-600 bg-emerald-50', amber: 'text-amber-600 bg-amber-50', red: 'text-red-600 bg-red-50' }[tone]
  return (
    <Card className="p-5 flex items-center gap-4">
      <div className={cn('w-12 h-12 rounded-2xl flex items-center justify-center', colorMap)}><Icon className="w-5 h-5" /></div>
      <div>
        <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">{label}</p>
        <p className="text-2xl font-black tabular-nums text-foreground">{value}</p>
      </div>
    </Card>
  )
}

function PolicyEditor({ initial, onCancel, onSave }: { initial: Policy; onCancel: () => void; onSave: (p: Policy) => void }) {
  const [draft, setDraft] = useState<Policy>(initial)
  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={onCancel}>
      <Card className="w-full max-w-xl p-8" onClick={e => e.stopPropagation()}>
        <h2 className="text-xl font-black mb-6">{initial.title ? 'Edit policy' : 'New policy'}</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <F label="Code"><Input value={draft.code} onChange={e => setDraft({ ...draft, code: e.target.value })} /></F>
          <F label="Title"><Input value={draft.title} onChange={e => setDraft({ ...draft, title: e.target.value })} /></F>
          <F label="Category"><Input value={draft.category} onChange={e => setDraft({ ...draft, category: e.target.value })} /></F>
          <F label="Version"><Input value={draft.version} onChange={e => setDraft({ ...draft, version: e.target.value })} /></F>
          <F label="Owner"><Input value={draft.owner} onChange={e => setDraft({ ...draft, owner: e.target.value })} /></F>
          <F label="Effective date"><Input type="date" value={draft.effectiveDate} onChange={e => setDraft({ ...draft, effectiveDate: e.target.value })} /></F>
          <F label="Next review"><Input type="date" value={draft.nextReview} onChange={e => setDraft({ ...draft, nextReview: e.target.value })} /></F>
          <F label="Acknowledged %"><Input type="number" min={0} max={100} value={draft.acknowledgmentPct} onChange={e => setDraft({ ...draft, acknowledgmentPct: Number(e.target.value) })} /></F>
          <F label="Status">
            <select className="h-9 px-3 border border-border rounded-md text-sm w-full" value={draft.status} onChange={e => setDraft({ ...draft, status: e.target.value as Policy['status'] })}>
              {['Active', 'Draft', 'Retired'].map(o => <option key={o}>{o}</option>)}
            </select>
          </F>
        </div>
        <div className="flex justify-end gap-2 mt-6">
          <Button variant="ghost" onClick={onCancel}>Cancel</Button>
          <Button onClick={() => onSave(draft)}>Save</Button>
        </div>
      </Card>
    </div>
  )
}

function F({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1">
      <label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">{label}</label>
      {children}
    </div>
  )
}
