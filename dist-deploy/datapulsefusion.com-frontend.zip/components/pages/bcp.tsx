'use client'

import React, { useMemo, useState } from 'react'
import { Shield, Plus, Pencil, Trash2, Clock, Activity } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'
import { createStore, useStoreSnapshot, genId } from '@/lib/localStore'
import { useToast } from '@/hooks/use-toast'
import { recordAudit } from '@/lib/auditLog'
import { useConfirm } from '@/components/ui/confirm-dialog'
import { useAuth } from '@/components/providers/auth-provider'

export interface BcpPlan {
  id: string
  name: string
  scope: string
  rto: number // hours
  rpo: number // hours
  owner: string
  lastTested?: string
  nextTest: string
  status: 'Current' | 'Overdue' | 'Draft'
}

const SEED: BcpPlan[] = [
  { id: 'BCP-001', name: 'Core Banking Continuity', scope: 'Payment & treasury platforms', rto: 4, rpo: 1, owner: 'CTO', lastTested: '2026-03-15', nextTest: '2026-09-15', status: 'Current' },
  { id: 'BCP-002', name: 'Customer Service Failover', scope: 'Contact centre operations', rto: 8, rpo: 4, owner: 'COO', lastTested: '2026-04-01', nextTest: '2026-10-01', status: 'Current' },
  { id: 'BCP-003', name: 'HQ Site Loss Plan', scope: 'Mumbai headquarters', rto: 48, rpo: 24, owner: 'CHRO', lastTested: '2025-09-20', nextTest: '2026-03-20', status: 'Overdue' },
  { id: 'BCP-004', name: 'Cyber Incident Recovery', scope: 'Ransomware containment', rto: 12, rpo: 4, owner: 'CISO', lastTested: '2026-02-10', nextTest: '2026-08-10', status: 'Current' },
  { id: 'BCP-005', name: 'Critical Vendor Outage Plan', scope: 'Cloudbase hosting outage', rto: 6, rpo: 2, owner: 'CIO', nextTest: '2026-07-15', status: 'Draft' },
]

export const bcpStore = createStore<BcpPlan>({ key: 'bcp', seed: SEED })

const STATUS_TONE: Record<BcpPlan['status'], string> = {
  Current: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  Overdue: 'bg-red-50 text-red-700 border-red-200',
  Draft: 'bg-amber-50 text-amber-700 border-amber-200',
}

export function BcpPage() {
  const items = useStoreSnapshot(bcpStore)
  const { toast } = useToast()
  const confirm = useConfirm()
  const { hasPermission } = useAuth()
  const [editing, setEditing] = useState<BcpPlan | null>(null)

  const stats = useMemo(() => ({
    total: items.length,
    current: items.filter(p => p.status === 'Current').length,
    overdue: items.filter(p => p.status === 'Overdue').length,
    avgRto: items.length ? (items.reduce((s, p) => s + p.rto, 0) / items.length).toFixed(1) : '0',
  }), [items])

  const save = (p: BcpPlan) => {
    const isNew = !items.find(x => x.id === p.id)
    if (isNew) { bcpStore.add(p); recordAudit({ action: 'CREATE', entity: 'BCP Plan', entity_id: p.id, description: `Created plan ${p.name}`, after: p, result: 'SUCCESS' }); toast({ title: 'Plan created' }) }
    else { bcpStore.update(p.id, p); recordAudit({ action: 'UPDATE', entity: 'BCP Plan', entity_id: p.id, description: `Updated plan ${p.name}`, after: p, result: 'SUCCESS' }); toast({ title: 'Plan updated' }) }
    setEditing(null)
  }

  const remove = async (p: BcpPlan) => {
    const ok = await confirm({ title: `Delete ${p.id}?`, description: 'This will permanently delete the BCP plan. This action cannot be undone.', confirmLabel: 'Delete plan', tone: 'danger' })
    if (!ok) return
    bcpStore.remove(p.id)
    recordAudit({ action: 'DELETE', entity: 'BCP Plan', entity_id: p.id, description: `Deleted plan ${p.name}`, before: p, result: 'SUCCESS' })
    toast({ title: 'Plan deleted' })
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Shield className="w-4 h-4 text-primary" />
            <span className="text-[10px] font-black uppercase tracking-[0.3em] text-primary">Business Continuity</span>
          </div>
          <h1 className="text-3xl font-black tracking-tight">Business Continuity Planning</h1>
          <p className="text-muted-foreground mt-2 font-medium">BCP/DRP plans with RTO, RPO, and test cadence.</p>
        </div>
        {hasPermission('create') && <Button onClick={() => setEditing(blank())} className="rounded-2xl"><Plus className="w-4 h-4 mr-2" />New plan</Button>}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Stat label="Total plans" value={stats.total} icon={Shield} tone="blue" />
        <Stat label="Current" value={stats.current} icon={Activity} tone="emerald" />
        <Stat label="Overdue tests" value={stats.overdue} icon={Clock} tone="red" />
        <Stat label="Avg RTO (hrs)" value={stats.avgRto} icon={Clock} tone="amber" />
      </div>

      <Card className="overflow-hidden">
        <table className="w-full text-[13px]">
          <thead className="bg-secondary/40">
            <tr className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">
              <th className="px-4 py-3 text-left">ID</th>
              <th className="px-4 py-3 text-left">Plan</th>
              <th className="px-4 py-3 text-right">RTO (hrs)</th>
              <th className="px-4 py-3 text-right">RPO (hrs)</th>
              <th className="px-4 py-3 text-left">Owner</th>
              <th className="px-4 py-3 text-left">Next test</th>
              <th className="px-4 py-3 text-left">Status</th>
              <th className="px-4 py-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border/30">
            {items.map(p => (
              <tr key={p.id} className="hover:bg-secondary/20">
                <td className="px-4 py-3 font-mono text-[11px] text-muted-foreground">{p.id}</td>
                <td className="px-4 py-3">
                  <div className="font-bold">{p.name}</div>
                  <div className="text-[11px] text-muted-foreground">{p.scope}</div>
                </td>
                <td className="px-4 py-3 text-right tabular-nums">{p.rto}</td>
                <td className="px-4 py-3 text-right tabular-nums">{p.rpo}</td>
                <td className="px-4 py-3 text-muted-foreground">{p.owner}</td>
                <td className="px-4 py-3 text-muted-foreground">{p.nextTest}</td>
                <td className="px-4 py-3"><span className={cn('px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-widest border', STATUS_TONE[p.status])}>{p.status}</span></td>
                <td className="px-4 py-3 text-right">
                  {hasPermission('update') && <Button variant="ghost" size="icon" onClick={() => setEditing(p)}><Pencil className="w-4 h-4" /></Button>}
                  {hasPermission('delete') && <Button variant="ghost" size="icon" onClick={() => remove(p)} className="text-red-500 hover:bg-red-50"><Trash2 className="w-4 h-4" /></Button>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>

      {editing && <BcpEditor initial={editing} onCancel={() => setEditing(null)} onSave={save} />}
    </div>
  )
}

function blank(): BcpPlan {
  const next = new Date(); next.setMonth(next.getMonth() + 6)
  return { id: genId('BCP'), name: '', scope: '', rto: 4, rpo: 1, owner: '', nextTest: next.toISOString().slice(0, 10), status: 'Draft' }
}

function Stat({ label, value, icon: Icon, tone }: { label: string; value: number | string; icon: any; tone: 'blue' | 'emerald' | 'amber' | 'red' }) {
  const colorMap = { blue: 'text-blue-600 bg-blue-50', emerald: 'text-emerald-600 bg-emerald-50', amber: 'text-amber-600 bg-amber-50', red: 'text-red-600 bg-red-50' }[tone]
  return (
    <Card className="p-5 flex items-center gap-4">
      <div className={cn('w-12 h-12 rounded-2xl flex items-center justify-center', colorMap)}><Icon className="w-5 h-5" /></div>
      <div>
        <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">{label}</p>
        <p className="text-2xl font-black tabular-nums text-foreground">{value}</p>
      </div>
    </Card>
  )
}

function BcpEditor({ initial, onCancel, onSave }: { initial: BcpPlan; onCancel: () => void; onSave: (p: BcpPlan) => void }) {
  const [draft, setDraft] = useState<BcpPlan>(initial)
  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={onCancel}>
      <Card className="w-full max-w-xl p-8" onClick={e => e.stopPropagation()}>
        <h2 className="text-xl font-black mb-6">{initial.name ? 'Edit plan' : 'New BCP plan'}</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <F label="Name" wide><Input value={draft.name} onChange={e => setDraft({ ...draft, name: e.target.value })} /></F>
          <F label="Scope" wide><Input value={draft.scope} onChange={e => setDraft({ ...draft, scope: e.target.value })} /></F>
          <F label="RTO (hours)"><Input type="number" value={draft.rto} onChange={e => setDraft({ ...draft, rto: Number(e.target.value) })} /></F>
          <F label="RPO (hours)"><Input type="number" value={draft.rpo} onChange={e => setDraft({ ...draft, rpo: Number(e.target.value) })} /></F>
          <F label="Owner"><Input value={draft.owner} onChange={e => setDraft({ ...draft, owner: e.target.value })} /></F>
          <F label="Next test"><Input type="date" value={draft.nextTest} onChange={e => setDraft({ ...draft, nextTest: e.target.value })} /></F>
          <F label="Status">
            <select className="h-9 px-3 border border-border rounded-md text-sm w-full" value={draft.status} onChange={e => setDraft({ ...draft, status: e.target.value as BcpPlan['status'] })}>
              {['Current', 'Overdue', 'Draft'].map(o => <option key={o}>{o}</option>)}
            </select>
          </F>
        </div>
        <div className="flex justify-end gap-2 mt-6">
          <Button variant="ghost" onClick={onCancel}>Cancel</Button>
          <Button onClick={() => onSave(draft)}>Save</Button>
        </div>
      </Card>
    </div>
  )
}

function F({ label, children, wide }: { label: string; children: React.ReactNode; wide?: boolean }) {
  return (
    <div className={cn('space-y-1', wide && 'md:col-span-2')}>
      <label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">{label}</label>
      {children}
    </div>
  )
}
