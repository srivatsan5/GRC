'use client'

import { PericopeLayout } from '@/components/pericope-layout'
import { RiskAssessmentsListPage } from '@/components/pages/risk-assessments-list'

export default function IdentificationRoute() {
  return (
    <PericopeLayout>
      <RiskAssessmentsListPage />
    </PericopeLayout>
  )
}
